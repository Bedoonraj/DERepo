# Databricks notebook source
from utils.config import DEV_FLAG

# COMMAND ----------

import glob

if DEV_FLAG:
    standardized_sa = 'sthdrstdzonedevtest'
else:
    standardized_sa = 'sthdrstdzoneprd'

# COMMAND ----------

# enable change data feed in psz and sz
for path in glob.glob(f"/dbfs/mnt/{standardized_sa}/*/*/*/*/*/", recursive=True): # /dbfs required for local code
    enableChangeDataFeed = spark.sql(f"SHOW TBLPROPERTIES delta.`{path[5:]}` (delta.enableChangeDataFeed)").first()['value']
    logRetentionDuration = spark.sql(f"SHOW TBLPROPERTIES delta.`{path[5:]}` (delta.logRetentionDuration)").first()['value']

    if not enableChangeDataFeed == 'true':
        print(f"{path=}, {enableChangeDataFeed=}")
        spark.sql(f"ALTER TABLE delta.`{path[5:]}` SET TBLPROPERTIES(delta.enableChangeDataFeed = true)")
        
    if not logRetentionDuration == 'interval 730 days':
        print(f"{path=}, {logRetentionDuration=}")
        spark.sql(f"ALTER TABLE delta.`{path[5:]}` SET TBLPROPERTIES(delta.logRetentionDuration = 'interval 730 days')")