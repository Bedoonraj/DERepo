# Databricks notebook source
@udf(returnType=StringType())
def intelligent_capitalization_udf(val):
    '''
    Input: 
        - String (val)
    Output: 
        - Converts the string to a titlecased format
    '''
    try:
        result = titlecase(val)
    except:
        return val # must be a null value, let's not touch it
    
    return result

def intelligent_capitalization_child(df, column_names_list):
    '''
    Input: 
        - Spark dataframe (df)
        - List of string-type columns (column_names_list)
    Output: 
        - Converts the string-type columns data to an all titlecased format
    '''
    for column_name in column_names_list:
        try:
            df = df.withColumn(f"{column_name}", intelligent_capitalization_udf(col(f"{column_name}")))
        except:
            pass
    
    return df

# COMMAND ----------

def string_character_removal_child(df, column_names_list, pattern_list):
    '''
    Input: 
        - Spark dataframe (df)
        - List of string-type columns (column_names_list)
        - List of regex character patterns to be removed (pattern_list)
    Output:
        - Applies a regex removal to each of the columns based on the pattern
    '''

    for i in range(len(column_names_list)):
        try: 
            pattern = r'{}'.format(pattern_list[i]) # convert to raw string for regex
            column_name = column_names_list[i]
            df = df.withColumn(f"{column_name}", regexp_replace(col(f"{column_name}"), pattern, ""))
        except:
            pass

    return df

# COMMAND ----------

def string_character_replacement_child(df, column_names_list, pattern_list, replacement_list):
    '''
    Input: 
        - Spark dataframe (df)
        - List of string-type columns (column_names_list)
        - List of regex character patterns to be replaced (pattern_list)
        - List of regex character patterns to replace with (replacement_list)
    Output:
        - Applies a regex replacement to each of the columns based on the patterns
    '''

    for i in range(len(column_names_list)):
        try:
            pattern = r'{}'.format(pattern_list[i]) # convert to raw string for regex
            replacement = r'{}'.format(replacement_list[i]) # convert to raw string for regex
            column_name = column_names_list[i]
            df = df.withColumn(f"{column_name}", regexp_replace(col(f"{column_name}"), pattern, replacement))
        except:
            pass

    return df

# COMMAND ----------

def string_to_boolean_child(df, column_names_list):
    '''
    Input: 
        - Spark dataframe (df)
        - List of string-type columns (column_names_list)
    Output: 
        - Converts the string-type columns to boolean-types
    '''
    for column_name in column_names_list:
        try:
            df = df.withColumn(f"{column_name}", col(f"{column_name}").cast(BooleanType()))
        except:
            pass
    
    return df

# COMMAND ----------

def string_to_uppercase_child(df, column_names_list):
    '''
    Input: 
        - Spark dataframe (df)
        - List of string-type columns (column_names_list)
    Output: 
        - Converts the string-type columns data to all uppercased format
    '''
    for column_name in column_names_list:
        try:
            df = df.withColumn(f"{column_name}", upper(col(f"{column_name}")))
        except:
            pass
    
    return df

# COMMAND ----------

def strip_phone_numbers_child(df, column_names_list):
    '''
    Input: 
        - Spark dataframe (df)
        - List of string-type columns (column_names_list) representing phone numbers
    Output: 
        - Transforms the string-type columns data to retain only numeric characters
    '''
    for column_name in column_names_list:
        try:
            pattern = "[^0-9]" # non-numeric characters
            df = df.withColumn(f"{column_name}", regexp_replace(col(f"{column_name}"), pattern, ""))
        except:
            pass
    
    return df

# COMMAND ----------

def validate_postal_codes_child(df, column_names_list):
    '''
    Input: 
        - Spark dataframe (df)
        - List of string-type columns (column_names_list) representing postal codes
    Output: 
        - Creates a new column (prefixed with "dqc_") for each of the postal code columns with the following:
            - Uppercase
            - Remove non-alphanumeric characters
            - Validated Canadian format (A9A9A9)
    '''
    for column_name in column_names_list:
        try:
            dqc_column_name = f"dqc_{column_name}"
            postal_code_pattern = r"^[A-Z]\d[A-Z]\d[A-Z]\d$" # A9A9A9 - convert to raw string for regex
            non_alphanumeric_pattern = "[^A-Z0-9]"
            df = df.withColumn(dqc_column_name, regexp_extract(regexp_replace(upper(col(column_name)), non_alphanumeric_pattern, ""), postal_code_pattern, 0))
        except:
            pass
    
    return df

# COMMAND ----------

# HCVALID
@udf(returnType=StringType())
def udf_hcn_pad10(cardnumber: str) -> str:
    '''
    Input: 
        - Health Card Number (str)
    Output: 
        - left pads the cardnumber with 0s to ensure it is ten digits long.
    '''
    
    if not isinstance(cardnumber, str):
        cardnumber = str(cardnumber)
    
    if cardnumber is not None:
        return cardnumber.zfill(10)

@udf(returnType=BooleanType())
def udf_mod_ten_check(cardnumber: str) -> bool:
    '''
    Input:
        - Health Card Number (str)
    Output: 
        - Boolean that indicates if this cardnumber passes a mod10 check
        
    MOD 10 calculation 
    Add together these values: 
      - Rightmost digit of HCN (excluding the check digit) times 2
      - Next rightmost digit of HCN (excluding the check digit) times 1
      - Next rightmost digit of HCN (excluding the check digit) times 2
      - Next rightmost digit of HCN (excluding the check digit) times 1
      - Next rightmost digit of HCN (excluding the check digit) times 2
      - And so on until all digits are accounted for
    Where the result of the multiplication is more than one digit, add the digits together. 
    Add the results of each multiplication together. 
    Divide the total by 10, giving a remainder. 
    The check digit of the HCN must = 10 − the remainder.

    '''
    if not cardnumber:
        return False
    
    cardnumber = str(cardnumber)
        
    # strings with numbers only
    if not cardnumber.isdigit():
        return False
    
    # all zeroes is invalid
    if all(c == '0' for c in cardnumber):
        return False
    
    # greater than 10 digits is invalid
    if len(cardnumber) > 10:
        return False

    total = 0
    i = 2
    
    for char in cardnumber[-2::-1]:
        x = int(char) * i
        if x > 9:
            total += x % 10 + 1
        else:
            total += x % 10
            
        # toggle beteween 2 and 1
        i = 3 - i
        
    # if total is a multiple of 10, need to accept 0 check digit    
    return cardnumber[-1] == str(10 - (total % 10))[-1]


def validate_hcn_child(df, column_names_list, id_type_col_list, id_type_map_list):
    '''
    Input: 
        - Spark dataframe (df)
        - List of health card number containing columns (column_names_list)
        - List of columns containing identifier types (id_type_col_list)
        - List of province to identifier code value mappings in JSON (id_type_map_list)
    Output:
        - Spark dataframe with two columns added:
            - dqc_{column_name}: HCN Left Padded to 10 digits. Contains the HCN if passes the mod 10 check, NULL if doesn't pass the mod 10 check 
              OR if the routine was not applied to this row.
            - dqc_valid_ind_{column_name_type}: True if the HCN contained in dqc_{column_name} passes the mod 10 check, False otherwise

    Note:
        - The mod_10_check can be applied directly to the column value instead of the left padded column value as it doesn't change the output.
    '''
    
    # because this adds columns, need to enable this specific setting
    spark.conf.set("spark.databricks.delta.schema.autoMerge.enabled", True)
    
    print(f"validate_hcn_child: {column_names_list=}, {id_type_col_list=}, {id_type_map_list=}")

    for i in range(len(column_names_list)):
        # variables for this table
        id_val_column_name = column_names_list[i]
        id_type_column_name = id_type_col_list[i] if id_type_col_list else None
        id_type_map = id_type_map_list[i] if id_type_map_list else None

        # added column name formats
        hcn_padded_name = f"dqc_{id_val_column_name}"
        hcn_valid_name = f"dqc_valid_ind_{id_val_column_name}"

        # if id_type_column_name is not provided, cleanse every record in id_val_col
        if id_type_column_name is None:
            
            df = df \
                .withColumn(hcn_padded_name, when(udf_mod_ten_check(df[id_val_column_name]) == True, udf_hcn_pad10(df[id_val_column_name])) \
                                            .otherwise(None)) \
                .withColumn(hcn_valid_name, udf_mod_ten_check(df[id_val_column_name]))

        # else only clean records where id_type_col = the NS value in the id_type_map
        else:
            # convert the mapping json string to a python dict
            type_map =  json.loads(id_type_map)
            
            df = df \
                .withColumn(hcn_padded_name, when((df[id_type_column_name] == type_map['NS']) & (udf_mod_ten_check(df[id_val_column_name]) == True), udf_hcn_pad10(df[id_val_column_name])) \
                                            .otherwise(None)) \
                .withColumn(hcn_valid_name, when(df[id_type_column_name] == type_map['NS'], udf_mod_ten_check(df[id_val_column_name])) \
                                            .otherwise(None))
        
    return df
 
                       
# for future types, create new udfs to clean the specific type and
# include them in the in the following format:  
#
# udf_df = df \
#   .withColumn(hcn_padded_name, when(df[id_type_col] == province_map['NS'], udf_hcn_pad10(df[id_val_col])) \
#                               .when(df[id_type_col] == province_map['BC'], <BC cleansing function>(df[id_val_col]))
#                               .otherwise(None)) \
#   .withColumn(hcn_valid_name, when(df[id_type_col] == province_map['NS'], udf_mod_ten_check(udf_hcn_pad10(df[id_val_col]))) \
#                               .when(df[id_type_col] == province_map['BC'], <BC validation function>(df[id_val_col])) \
#                               .when(df[id_type_col] == province_map['ON'], <ON validation function>(df[id_val_col])) \
#                               .otherwise(None))


# COMMAND ----------

def convert_dates_child(df, column_names_list):
    '''
    Input: 
        - Spark dataframe (df)
        - List of string-type columns (column_names_list) representing dates in one of the following formats:
            (i) xxxx-xx-xx
            (ii) xxxx-xx-xx xx:xx:xx
            (iii) xxxxxxxx
            where x is a digit
    Output: 
        - Transforms the string-type columns data to dates
        If there is an invalid date or a missing date, they will be assigned a NULL value by this transformation
    '''
    for column_name in column_names_list:
        try:
            df = df.withColumn(
                'iso8601_timestamp',
                when(
                    col(column_name).rlike('^\d{4}-\d{2}-\d{2}$'),
                    to_timestamp(col(column_name), 'yyyy-MM-dd')
                ).when(
                    col(column_name).rlike('^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$'),
                    to_timestamp(col(column_name), 'yyyy-MM-dd HH:mm:ss')
                ).when(
                    col(column_name).rlike('^\d{8}$'),
                    to_timestamp(col(column_name), 'yyyyMMdd')
                ).otherwise(None)
            ).drop(column_name).withColumnRenamed('iso8601_timestamp', column_name)
        except:
            pass
    
    return df