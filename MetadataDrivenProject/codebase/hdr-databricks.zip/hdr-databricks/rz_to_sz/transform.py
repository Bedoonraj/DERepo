# Databricks notebook source
# MAGIC %md
# MAGIC #### Perform the light data cleaning on the Spark dataframe
# MAGIC ###### Trimming and double-space removal

# COMMAND ----------

import pyspark.sql.functions as F

# COMMAND ----------

string_columns = [col[0] for col in df.dtypes if col[1] == 'string']

print(f"Processing string columns: {string_columns}")
try:
    for column in string_columns:

        # trim and double-space removal in one step
        df = df.withColumn(column, regexp_replace(trim(column), ' +', ' '))

except Exception as e:
    error_handling(e, f"Error with light data cleansing: {column=}", rz_in_folder=rz_in_folder, rz_in_filepath=rz_in_filepath)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Query dbo.ADF_GNS_DynamicDataCleaning 
# MAGIC ###### Retrieve and process the necessary variables

# COMMAND ----------

# get JDBC connection string from key vault
if DEV_FLAG:
    kv_scope = "azurekvhdr-scope"
    con_secret = "jdbc-sqldb-hdr-datalandingzone-health-connection-string"
else:
    kv_scope = "scope-kv-hdr-app-prd-001"
    con_secret = "jdbc-sqldb-hdr-datazonehealth-config-connection-string-prd"
    
try:
    jdbcUrl = dbutils.secrets.get(scope=kv_scope, key=con_secret)
except Exception as e:
    error_handling(e, "The Key Vault connection string key cannot be read", rz_in_folder=rz_in_folder, rz_in_filepath=rz_in_filepath)

# COMMAND ----------

# retrieve ADF_GNS_DynamicDataCleaning table
ddc_df = spark.read.jdbc(url=jdbcUrl, table='dbo.ADF_GNS_DynamicDataCleaning')

# register the df as a SQL temporary view
ddc_df.createOrReplaceTempView("ddc")

# COMMAND ----------

# parse useful parameters for a SQL query against ddc
src_folder_list = src_folder.split("/")
org_name = src_folder_list[0]
sys_name = src_folder_list[1]
schema_name = src_folder_list[2]
table_name = src_folder_list[3]

print(f"Parameters parsed as: {org_name=}, {sys_name=}, {schema_name=}, {table_name=}.")

# define SQL query to get information for the relevant table/file
sql_query = f"""
SELECT * FROM ddc
WHERE org_name = '{org_name}'
AND sys_name = '{sys_name}'
AND schema_name = '{schema_name}'
AND table_name = '{table_name}'
ORDER BY routine_name
"""

# query against our `ddc` temp view
try:
    sql_df = spark.sql(sql_query)
except Exception as e:
    error_handling(e, "DDC table inaccessible", rz_in_folder=rz_in_folder, rz_in_filepath=rz_in_filepath)

sql_df.show()

# maintain lists based on the `sql_query` to organize each table
# we'll create a central dictionary
'''
i.e.
routines_dict =
{
    '<routine_name 1>': [<column_names_list>, <routine_inputs_1_list>, <routine_inputs_2_list>],
    '<routine_name 2>': [<column_names_list>, <routine_inputs_1_list>, <routine_inputs_2_list>],
    ... and so on
}
'''

routines_dict = sql_df.groupBy('routine_name') \
    .agg(
        F.collect_list('column_name').alias('column_name'),
        F.collect_list('routine_input_1').alias('routine_input_1'),
        F.collect_list('routine_input_2').alias('routine_input_2')
    )\
    .withColumn("vals", F.array(['column_name', 'routine_input_1', 'routine_input_2']))\
    .select('routine_name', 'vals').rdd.collectAsMap()

print(f"{routines_dict}")

# COMMAND ----------

# MAGIC %md
# MAGIC #### Begin the Actual Orchestration
# MAGIC ###### Where the fun happens

# COMMAND ----------

# MAGIC %md
# MAGIC ###### Import the orchestration child functions

# COMMAND ----------

# MAGIC %run "../rz_to_sz/transform_helper"

# COMMAND ----------

class orchestrator:
    def __init__(self, df):
        self.df = df
    
    def intelligent_capitalization(self): # udf time
        self.df = intelligent_capitalization_child(self.df, self.column_names)

    def string_character_removal(self):
        self.df = string_character_removal_child(self.df, self.column_names, self.routine_inputs_1)
    
    def string_character_replacement(self):
        self.df = string_character_replacement_child(self.df, self.column_names, self.routine_inputs_1, self.routine_inputs_2)
    
    def string_to_boolean(self):
        self.df = string_to_boolean_child(self.df, self.column_names)
    
    def string_to_uppercase(self):
        self.df = string_to_uppercase_child(self.df, self.column_names)
    
    def strip_phone_numbers(self):
        self.df = strip_phone_numbers_child(self.df, self.column_names)
    
    def validate_postal_codes(self):
        self.df = validate_postal_codes_child(self.df, self.column_names)

    def validate_hcn(self):
        self.df = validate_hcn_child(self.df, self.column_names, self.routine_inputs_1, self.routine_inputs_2)
    
    def convert_dates(self):
        self.df = convert_dates_child(self.df, self.column_names)
        
    def set_routines(self, routine_details):
        self.column_names = routine_details[0]
        self.routine_inputs_1 = routine_details[1]
        self.routine_inputs_2 = routine_details[2]
    
    def orchestrator_logic(self, routine_name):
        self.routine_name = routine_name
        
        if routine_name == 'INTELLCAP':
            self.intelligent_capitalization()
        elif routine_name == 'CHARREMOVE':
            self.string_character_removal()
        elif routine_name == 'CHARREP':
            self.string_character_replacement()
        elif routine_name == 'STRINGBOOL':
            self.string_to_boolean()
        elif routine_name == 'UPPERCASE':
            self.string_to_uppercase()
        elif routine_name == 'PHONE':
            self.strip_phone_numbers()
        elif routine_name == 'PCODE':
            self.validate_postal_codes()
        elif routine_name == 'HCVALID':
            self.validate_hcn()
        elif routine_name == 'DATECONV':
            self.convert_dates()
        else:
            error_output = f"The {routine_name} routine does not exist. Why is this here?"
            print(error_output)
            raise Exception(error_output) # exit notebook here with logging

# COMMAND ----------

# MAGIC %md
# MAGIC ###### Initialize an orchestrator object for the table

# COMMAND ----------

# init orchestrator object for each table. Note: only one table at a time in CMO so we're good
transform_df = orchestrator(df)

# COMMAND ----------

# MAGIC %md
# MAGIC ###### Now we determine how to apply each of the necessary transformations
# MAGIC ###### Let's use `routines_dict` and our new `transform_df`

# COMMAND ----------

for routine_name, routine_details in routines_dict.items():
    try:
        transform_df.set_routines(routine_details)
        transform_df.orchestrator_logic(routine_name)
    except Exception as e:
        error_handling(
            e,
            "Error performing data cleansing, {routine_name=}, {routine_details=}",
            rz_in_folder=rz_in_folder,
            rz_in_filepath=rz_in_filepath
        )