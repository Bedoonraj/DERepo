# Databricks notebook source
# ensure parameters fit the bill. For internal debugging purposes
# none of these errors should ever occur
assert len(src_folder) > 0, "p_src_folder is required"
assert src_folder.count('/') > 4, "incorrect src folder path"
assert len(src_file) > 0, "p_src_file is required"
assert src_file.endswith('.parquet'), ".parquet src file is required"
assert src_file.count('.parquet') == 1, "incorrect src file name"
assert src_file != '.parquet', "nice try"
assert len(rz_st_name) > 0, "p_rz_st_name is required"
assert len(sz_st_name) > 0, "p_sz_st_name is required"

# calculate sink folder for the standardized zone
sink_folder = "/".join(src_folder.split("/", 3)[:3]) # to get format as <org>/<sys>/<schema>. Note that <table> is missing
# sink_file = src_file.replace(".parquet", ".delta") # old code but keep it for now
assert len(sink_folder) > 0, "p_src_folder must have been in an incorrect format"

# build mounted folder paths
rz_in_folder       = f"/mnt/{rz_st_name}/{src_folder}"
rz_in_filepath     = f"{rz_in_folder}/{src_file}"
sz_out_folder      = f"/mnt/{sz_st_name}/standardized/{sink_folder}" # everything but /<table>
# sz_out_filepath    = f"{sz_out_folder}/{sink_file}" # old code but keep it for now

# build mountpoint to see if needs to be mounted
mountpoint = f"/mnt/{sz_st_name}/standardized"

# COMMAND ----------

print(f"{rz_in_folder}")
print(f"{rz_in_filepath}")
print(f"{sz_out_folder}")

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Mount containers if required

# COMMAND ----------

# mounts std zone container if it is not mounted already
if not any(mount.mountPoint == mountpoint for mount in dbutils.fs.mounts()):
    args = {
        "orgname": 'standardized', # always 'standardized' in this storage account
        "accountname": sz_st_name,
        "systemname": None 
    }
    try:
        run_with_retry("../op_to_lz/configuration", 60, args, max_retries = 1)
    except Exception as e:
        error_handling(e, f"Error mounting std zone, {args=}", rz_in_folder=rz_in_folder, rz_in_filepath=rz_in_filepath)

# COMMAND ----------

#mount raw zone container if it is not mounted already
orgname = src_folder.split("/", 1)[0]
rawmountpoint = f"/mnt/{rz_st_name}/{orgname}"

# mounts raw zone container if it is not mounted already
if not any(mount.mountPoint == rawmountpoint for mount in dbutils.fs.mounts()):
    
    print(f"{rawmountpoint} not found in {dbutils.fs.mounts()}")

    args = {
        "orgname": orgname,
        "accountname": rz_st_name,
        "systemname": None
    }
    try:
        run_with_retry("../op_to_lz/configuration", 60, args, max_retries = 1)
    except Exception as e:
        error_handling(e, f"Error mounting raw zone, {args=}", rz_in_folder=rz_in_folder, rz_in_filepath=rz_in_filepath)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Read in the raw file as a Spark dataframe

# COMMAND ----------

try:
    print(f"Loading {rz_in_filepath}...", end="")
    df = spark.read.parquet(rz_in_filepath)
    print("done.")
except Exception as e:
    error_handling(e, "Rawzone Parquet file cannot be read", rz_in_folder=rz_in_folder, rz_in_filepath=rz_in_filepath)