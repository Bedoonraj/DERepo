# Databricks notebook source
# MAGIC %md
# MAGIC ### Main Orchestrator for DDC (Dynamic Data Cleaning)
# MAGIC
# MAGIC # TODO:
# MAGIC - Bring the main, extract, transform, load back into one notbook; OR,
# MAGIC - Parameterize each notebook to enable testing of individual notebooks. Currently notebooks refer to variables from other notebooks directly which makes testing difficult and should be avoided.

# COMMAND ----------

# MAGIC %md
# MAGIC ###### Import the useful stuff we'll need

# COMMAND ----------

# MAGIC %run "../utils/libraries"

# COMMAND ----------

from utils.config import DEV_FLAG, ENVIRONMENT_MODE

# COMMAND ----------

# MAGIC %md
# MAGIC #### Let's read the pipeline parameters
# MAGIC ###### More specific assertions these days

# COMMAND ----------

# read in parameters
dbutils.widgets.text("p_src_folder", "")
dbutils.widgets.text("p_src_file", "")
dbutils.widgets.text("p_rz_st_name", "")
dbutils.widgets.text("p_sz_st_name", "")

src_folder = dbutils.widgets.get("p_src_folder")
src_file = dbutils.widgets.get("p_src_file")
rz_st_name = dbutils.widgets.get("p_rz_st_name")
sz_st_name = dbutils.widgets.get("p_sz_st_name")

# COMMAND ----------

def run_with_retry(notebook: str, timeout: int, args: dict = {}, max_retries: int = 3) -> None:
    '''Tries running a notebook and retries on failure.

    Args:
        notebook: the path to the databricks notebook.
        timeout: time in seconds to wait for timeout for the notebook running.
        args: arguments passed to the notebook.
        max_retries: number of retries before an exception is raised

    Returns:
        Nothing
    '''
    num_retries = 0
    while True:
        try:
            return dbutils.notebook.run(notebook, timeout, args)
        except Exception as e:
            if num_retries > max_retries:
                raise e
            else:
                print("Retrying error", e)
                num_retries += 1

# COMMAND ----------

def error_handling(error: Exception, message: str, rz_in_folder: str, rz_in_filepath: str) -> None:
    
    # modify the folder hierarchy to work with dbfs
    rz_in_filepath = "/dbfs" + rz_in_filepath
    rz_reject_folder = "/dbfs" + rz_in_folder.replace("/out/", "/reject/") 
    rz_reject_filepath = rz_in_filepath.replace("/out/", "/reject/")

    # create the reject directory in case it does not exist yet
    if not os.path.exists(rz_reject_folder):
        os.makedirs(rz_reject_folder)
    
    # move original file to the reject folder
    dbutils.fs.mv(rz_in_filepath[5:], rz_reject_filepath[5:] + 'reject')
    print(f"Error: {message}, Exception Text:{str(error)}")
    raise Exception(message) from error

# COMMAND ----------

# MAGIC %md
# MAGIC #### ETL Process

# COMMAND ----------

# MAGIC %run "../rz_to_sz/extract"

# COMMAND ----------

# MAGIC %run "../rz_to_sz/transform"

# COMMAND ----------

# MAGIC %run "../rz_to_sz/load"