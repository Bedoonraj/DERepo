# Databricks notebook source
# MAGIC %md
# MAGIC #### Incremental vs. Full Load
# MAGIC ###### Which one to use? Let's query dbo.ADF_GNS_ControlMapping table

# COMMAND ----------

full_load_flag = False # set as default. If True then we do a full load, otherwise incremental load

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Full Load Logic
# MAGIC For a full load, simply use the .mode("overwrite") function. This will atomically replace all the data in a table.
# MAGIC
# MAGIC ###### Schema Validation
# MAGIC * All DataFrame columns must exist in the target table. If there are columns in the DataFrame not present in the table, an exception is raised. Columns present in the table but not in the DataFrame are set to null.
# MAGIC * DataFrame column data types must match the column data types in the target table. If they don’t match, an exception is raised.
# MAGIC * If we want to automatically add new columns to our delta table, we can include the option .option("mergeschema", "true"). This will automatically add any new columns to the delta table. This is different than .option("overwriteSchema", "true") which will replace the delta table schema with the dataframe schema.
# MAGIC
# MAGIC ###### Partitioning? Nope
# MAGIC * Because of built-in features and optimizations, most tables with less than 1 TB of data do not require partitions. 
# MAGIC * Refer to https://learn.microsoft.com/en-us/azure/databricks/tables/partitions.

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Incremental Load Logic
# MAGIC https://learn.microsoft.com/en-us/azure/databricks/delta/merge
# MAGIC
# MAGIC https://docs.delta.io/latest/api/python/index.html#delta.tables.DeltaTable.merge
# MAGIC
# MAGIC
# MAGIC For an incremental load, need to perform a merge operation.
# MAGIC
# MAGIC **INSERTS:**
# MAGIC If the PRIMARY_KEY in the source table is not present in the target table, the record will be inserted as a new record.
# MAGIC
# MAGIC **UPDATES:**
# MAGIC If the PRIMARY_KEY in the source table is present in the target table, all values will be overwritten with the new values
# MAGIC
# MAGIC **DELETES:**
# MAGIC As this is an incremental load we do not want to do the when not matched by target: delete operation. Deletes will be handled using the PRIMARY_KEY_DELETED flag added in the source to ingestion zone pipeline (soft deletes)
# MAGIC
# MAGIC ###### Automatic Schema Evolution
# MAGIC https://docs.delta.io/latest/delta-update.html#automatic-schema-evolution
# MAGIC
# MAGIC If we want to insert new columns from the df that are not present in the delta table, need to set spark.databricks.delta.schema.autoMerge.enables to true before running the merge operation.
# MAGIC
# MAGIC ###### Performance Tuning
# MAGIC https://docs.delta.io/latest/delta-update.html#performance-tuning
# MAGIC
# MAGIC * Control the shuffle partitions for writes: The merge operation shuffles data multiple times to compute and write the updated data. The number of tasks used to shuffle is controlled by the Spark session configuration spark.sql.shuffle.partitions. Setting this parameter not only controls the parallelism but also determines the number of output files. Increasing the value increases parallelism but also generates a larger number of smaller data files.
# MAGIC
# MAGIC * Repartition output data before write: For partitioned tables, merge can produce a much larger number of small files than the number of shuffle partitions. This is because every shuffle task can write multiple files in multiple partitions, and can become a performance bottleneck. In many cases, it helps to repartition the output data by the table’s partition columns before writing it. You enable this by setting the Spark session configuration spark.databricks.delta.merge.repartitionBeforeWrite.enabled to true.

# COMMAND ----------

# get WatermarkColumn and FullLoad

# retrieve ADF_GNS_ControlMapping table
cm_df = spark.read.jdbc(url=jdbcUrl, table='dbo.ADF_GNS_ControlMapping')

# register the df as a SQL temporary view
cm_df.createOrReplaceTempView("cm")

# COMMAND ----------

# define SQL query to get information for the relevant table/file
sql_query = f"""
SELECT * FROM cm
WHERE SchemaName = '{schema_name}'
AND TableName = '{table_name}'
AND Environment = '{ENVIRONMENT_MODE}'
"""

# query against our cm temp view
try:
    sql_df = spark.sql(sql_query)
except Exception as e:
    error_handling(e, "ControlMapping table inaccessible", rz_in_folder=rz_in_folder, rz_in_filepath=rz_in_filepath)

sql_df.show()

try:
    full_load_flag = sql_df.first()['FullLoad'] == 'Y'
except Exception as e:
    msg = "Can not retrieve FullLoad column for this table."
    error_handling(e, msg, rz_in_folder=rz_in_folder, rz_in_filepath=rz_in_filepath)

# COMMAND ----------

print(f"The full load flag for this table is {full_load_flag}")

# COMMAND ----------

# MAGIC  %md
# MAGIC #### Set delta table parameters
# MAGIC
# MAGIC ##### Should investigate the following, especially if we turn on partitioning
# MAGIC
# MAGIC `set spark.databricks.delta.properties.defaults.autoOptimize.optimizeWrite = true;`
# MAGIC
# MAGIC `set spark.databricks.delta.properties.defaults.autoOptimize.autoCompact = true;`

# COMMAND ----------

# MAGIC %sql
# MAGIC set spark.databricks.delta.properties.defaults.enableChangeDataFeed = true;
# MAGIC set spark.databricks.delta.properties.defaults.logRetentionDuration = interval 730 days;

# COMMAND ----------

# MAGIC %md
# MAGIC #### Write to Standardized Zone in Delta File Format (Multi-file)
# MAGIC ###### Let the Spark engine do its thing

# COMMAND ----------

from pyspark.sql import DataFrame
def check_golden_record_code(df: DataFrame) -> bool:
    ''' Checks to see if there is a golden record column in the table.
    If there is, merge will fail unless it is accounted for.

    Args:
      df: the dataframe you will check

    Returns:
      True if a golden record code column is present
    '''
    return any('_golden_record_code' in col for col in df.columns)


# COMMAND ----------

def merge_incremental_soft_deletes(target_table: DeltaTable, source_table: DataFrame, target_key: str, source_key: str):
    '''
    Raw/source table has two "types" of data: 
        Inserts/updates, which have the format:
            HDR_PRIMARY_KEY, HDR_LASTLOADDATE, HDR_DELETED_FLAG , <src table columns>
            <src pks>      , <last load date>, <always "0">     , <src data>
    
        Deletes, which have the format:
            HDR_PRIMARY_KEY, HDR_LASTLOADDATE, HDR_DELETED_FLAG, <src table columns>
            <src pks>      , <last load date>, <always "1">    , <always NULL for all fields>

    The column HDR_DELETED_FLAG is always present in the source table. 
    Full load tables will never have delete rows.
    Incremental tables may include delete rows.

    Expected behaviour:
        1. Inserts and updates where the HDR_DELETED_FLAG = 0 upsert all data as is
        2. Soft deletes (HDR_DELETED_FLAG = 1) update the target columns:
            HDR_DELETED_FLAG: set to 1
            HDR_LASTLOADDATE: set to time of last load (when the soft delete was noticed)
            
        This update will ensure if delta time-travel is used, data as of that time is correctly
        represented, as well as still showing what the data was at the time it was deleted in the
        current dataset.
    '''
    target_table.alias("t").merge(
            source = source_table.alias("s"),
            condition = f"t.{target_key} = s.{source_key}"
        ).whenMatchedUpdate(
            condition = "s.HDR_DELETED_FLAG = true",
            set = { # set deleted flag and update timestamp but leave all other data
                "HDR_LASTLOADDATE": "s.HDR_LASTLOADDATE",
                "HDR_DELETED_FLAG": "s.HDR_DELETED_FLAG"
            }
        ).whenMatchedUpdateAll( # if HDR_DELETED_FLAG is not true then update
        ).whenNotMatchedInsertAll(
        ).execute()

# COMMAND ----------

df_final = transform_df.df

# create the directory in case it does not exist yet
sz_out_folder_dbfs = "/dbfs" + sz_out_folder
os.makedirs(sz_out_folder_dbfs, exist_ok=True)

# add a .delta extension with the table name
sz_out_filepath = f"{sz_out_folder}/{table_name}.delta"

# if the delta table doesn't exist or the table is a full load, overwrite the table
if not DeltaTable.isDeltaTable(spark, sz_out_filepath) or full_load_flag:
    print(f"Full load: {DeltaTable.isDeltaTable(spark, sz_out_filepath)=}, {full_load_flag=}")

    try:
        df_final.write.format("delta").mode("overwrite").save(sz_out_filepath)

    except Exception as e:
        error_handling(e, f"Full load of table {sz_out_filepath} failed.", rz_in_folder=rz_in_folder, rz_in_filepath=rz_in_filepath)

# if the delta table does exist or it is incremental, merge
else:
    # check to see if target is a sz table with a golden_record_code column
    if check_golden_record_code(spark.read.format('delta').load(sz_out_filepath)):
        print("Golden record column found in target: setting autoMerge to True")
        spark.conf.set("spark.databricks.delta.schema.autoMerge.enabled", "true")

    print(f"Incremental load: {DeltaTable.isDeltaTable(spark, sz_out_filepath)=}, {full_load_flag=}")
    try:
        merge_incremental_soft_deletes(DeltaTable.forPath(spark, sz_out_filepath), df_final, "HDR_PRIMARY_KEY", "HDR_PRIMARY_KEY")

    except Exception as e:
        error_handling(e, f"Merge of table {sz_out_filepath} failed.", rz_in_folder=rz_in_folder, rz_in_filepath=rz_in_filepath)
    finally:
        spark.conf.set("spark.databricks.delta.schema.autoMerge.enabled", "false")