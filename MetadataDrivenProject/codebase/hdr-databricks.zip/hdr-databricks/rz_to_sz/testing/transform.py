# Databricks notebook source
# MAGIC %run "/Repos/repo/hdr-databricks/utils/libraries"

# COMMAND ----------

# MAGIC %run "../transform_helper"

# COMMAND ----------

def compare_dfs(df1, df2):
    df2.show()

    compare_df = df1.exceptAll(df2)

    if compare_df.isEmpty():
        print("The testing is successful and is working as expected.")
    else:
        print("The testing has failed and is not working as expected.")

# COMMAND ----------

# MAGIC %md
# MAGIC #### Intelligent Capitalization
# MAGIC ##### Input: 
# MAGIC     - Spark dataframe (df)
# MAGIC     - List of string-type columns (column_names_list)
# MAGIC ##### Output: 
# MAGIC     - Converts the string-type columns data to an all titlecased format

# COMMAND ----------

strings = [("hello there",), ("lord of the rings",), (None,), ("title",)]
column_name = "strings"
schema = StructType([StructField(column_name, StringType(), nullable=True)])
df = spark.createDataFrame(strings, schema)

expected_strings = [("Hello There",), ("Lord of the Rings",), (None,), ("Title",)]
expected_df = spark.createDataFrame(expected_strings, schema)

actual_df = intelligent_capitalization_child(df, [column_name])

compare_dfs(expected_df, actual_df)

# COMMAND ----------

# MAGIC %md
# MAGIC #### String Character Removal
# MAGIC ##### Input: 
# MAGIC     - Spark dataframe (df)
# MAGIC     - List of string-type columns (column_names_list)
# MAGIC     - List of regex character patterns to be removed (pattern_list)
# MAGIC ##### Output:
# MAGIC     - Applies a regex removal to each of the columns based on the pattern

# COMMAND ----------

strings = [("hello there",), ("lord of the rings",), (None,), ("title",)]
column_name = "strings"
schema = StructType([StructField(column_name, StringType(), nullable=True)])
df = spark.createDataFrame(strings, schema)

expected_strings = [("hll thr",), ("lrd f th rngs",), (None,), ("ttl",)]
expected_df = spark.createDataFrame(expected_strings, schema)

actual_df = string_character_removal_child(df, [column_name], ['[aeiou]']) # remove vowels

compare_dfs(expected_df, actual_df)

# COMMAND ----------

# MAGIC %md
# MAGIC #### String Character Replacement
# MAGIC ##### Input: 
# MAGIC     - Spark dataframe (df)
# MAGIC     - List of string-type columns (column_names_list)
# MAGIC     - List of regex character patterns to be replaced (pattern_list)
# MAGIC     - List of regex character patterns to replace with (replacement_list)
# MAGIC ##### Output:
# MAGIC     - Applies a regex replacement to each of the columns based on the patterns

# COMMAND ----------

strings = [("hello there",), ("lord of the rings",), (None,), ("title",)]
column_name = "strings"
schema = StructType([StructField(column_name, StringType(), nullable=True)])
df = spark.createDataFrame(strings, schema)

expected_strings = [("hAllA thArA",), ("lArd Af thA rAngs",), (None,), ("tAtlA",)]
expected_df = spark.createDataFrame(expected_strings, schema)

actual_df = string_character_replacement_child(df, [column_name], ['[aeiou]'], ['A']) # replace vowels with 'A'

compare_dfs(expected_df, actual_df)

# COMMAND ----------

# MAGIC %md
# MAGIC #### String to Boolean
# MAGIC ##### Input: 
# MAGIC     - Spark dataframe (df)
# MAGIC     - List of string-type columns (column_names_list)
# MAGIC ##### Output: 
# MAGIC     - Converts the string-type columns to boolean-types

# COMMAND ----------

strings = [("true",), ("false",), (None,), ("True",), ("Yes",), ("no",)]
column_name = "strings"
schema = StructType([StructField(column_name, StringType(), nullable=True)])
df = spark.createDataFrame(strings, schema)

expected_strings = [(True,), (False,), (None,), (True,), (True,), (False,)]
boolean_schema = StructType([StructField(column_name, BooleanType(), nullable=True)])
expected_df = spark.createDataFrame(expected_strings, boolean_schema)

actual_df = string_to_boolean_child(df, [column_name])

compare_dfs(expected_df, actual_df)

# COMMAND ----------

# MAGIC %md
# MAGIC #### String to Uppercase
# MAGIC ##### Input: 
# MAGIC     - Spark dataframe (df)
# MAGIC     - List of string-type columns (column_names_list)
# MAGIC ##### Output: 
# MAGIC     - Converts the string-type columns data to all uppercased format

# COMMAND ----------

strings = [("hello there",), ("lord of the rings",), (None,), ("title",)]
column_name = "strings"
schema = StructType([StructField(column_name, StringType(), nullable=True)])
df = spark.createDataFrame(strings, schema)

expected_strings = [("HELLO THERE",), ("LORD OF THE RINGS",), (None,), ("TITLE",)]
expected_df = spark.createDataFrame(expected_strings, schema)

actual_df = string_to_uppercase_child(df, [column_name])

compare_dfs(expected_df, actual_df)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Strip Phone Numbers
# MAGIC ##### Input: 
# MAGIC     - Spark dataframe (df)
# MAGIC     - List of string-type columns (column_names_list) representing phone numbers
# MAGIC ##### Output: 
# MAGIC     - Transforms the string-type columns data to retain only numeric characters

# COMMAND ----------

strings = [("123-456-7890",), ("2223334444",), (None,), ("Crazy long 555-555-5555 Blah blah Blah",)]
column_name = "strings"
schema = StructType([StructField(column_name, StringType(), nullable=True)])
df = spark.createDataFrame(strings, schema)

expected_strings = [("1234567890",), ("2223334444",), (None,), ("5555555555",)]
expected_df = spark.createDataFrame(expected_strings, schema)

actual_df = strip_phone_numbers_child(df, [column_name])

compare_dfs(expected_df, actual_df)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Validate Postal Codes
# MAGIC ##### Input: 
# MAGIC     - Spark dataframe (df)
# MAGIC     - List of string-type columns (column_names_list) representing postal codes
# MAGIC ##### Output: 
# MAGIC     - Creates a new column (prefixed with "dqc_") for each of the postal code columns with the following:
# MAGIC         - Uppercase
# MAGIC         - Remove non-alphanumeric characters
# MAGIC         - Validated Canadian format (A9A9A9)

# COMMAND ----------

strings = [("n2p2V5",), ("lord of the rings",), (None,), ("l9t 5e2",), ("L9T     5E2",)]
column_name = "postal_code"
schema = StructType([StructField(column_name, StringType(), nullable=True)])
df = spark.createDataFrame(strings, schema)

expected_strings = [("n2p2V5", "N2P2V5"), ("lord of the rings", ""), (None, None), ("l9t 5e2", "L9T5E2"), ("L9T     5E2", "L9T5E2")]
dqc_schema = StructType([StructField(column_name, StringType(), nullable=True),
                         StructField(f"dqc_{column_name}", StringType(), nullable=True)])
expected_df = spark.createDataFrame(expected_strings, dqc_schema)

actual_df = validate_postal_codes_child(df, [column_name])

compare_dfs(expected_df, actual_df)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Validate Health Card Numbers

# COMMAND ----------

# TODO

# COMMAND ----------

# MAGIC %md
# MAGIC #### Convert Dates
# MAGIC ##### Input: 
# MAGIC     - Spark dataframe (df)
# MAGIC     - List of string-type columns (column_names_list) representing dates in one of the following formats:
# MAGIC         (i) xxxx-xx-xx
# MAGIC         (ii) xxxx-xx-xx xx:xx:xx
# MAGIC         (iii) xxxxxxxx
# MAGIC         where x is a digit
# MAGIC ##### Output: 
# MAGIC     - Transforms the string-type columns data to dates

# COMMAND ----------

strings = [("20230101",), ("1996-06-15",), (None,), ("1989-12-31 13:33:37",), ("2023",)]
column_name = "strings"
schema = StructType([StructField(column_name, StringType(), nullable=True)])
df = spark.createDataFrame(strings, schema)

expected_dates = [(datetime(2023, 1, 1),), (datetime(1996, 6, 15),), (None,), (datetime(1989, 12, 31, 13, 33, 37),), (None,)]
dates_schema = StructType([StructField(column_name, TimestampType(), nullable=True)])
expected_df = spark.createDataFrame(expected_dates, dates_schema)

actual_df = convert_dates_child(df, [column_name])

compare_dfs(expected_df, actual_df)