# Databricks notebook source
# MAGIC %run "/Repos/repo/hdr-databricks/utils/libraries"

# COMMAND ----------

# MAGIC %md
# MAGIC #### Extract(ing the Data)
# MAGIC ##### Input: 
# MAGIC - `src_folder`
# MAGIC - `src_file`
# MAGIC - `rz_st_name`
# MAGIC - `sz_st_name`
# MAGIC ##### Output: 
# MAGIC A printed statement of whether or not the extraction is working as expected for the given inputs

# COMMAND ----------

src_folder = "dhw/hap/dad/DAD_RESTRAINT_ICD10/out/2023/06/06"
src_file = "20230606-153930_DAD_RESTRAINT_ICD10.parquet"
rz_st_name = "sthdrrawzonedevtest"
sz_st_name = "sthdrstdzonedevtest"

# COMMAND ----------

# MAGIC %run "../extract"

# COMMAND ----------

if 'df' in globals() and df.isEmpty():
    print("The testing has failed and not working as expected.")
else:
    print("The testing is successful and working as expected.")