# Databricks notebook source
from utils.config import DEV_FLAG, ENVIRONMENT_MODE

# COMMAND ----------

# MAGIC %run "./extract"

# COMMAND ----------

# MAGIC %run "../transform"

# COMMAND ----------

# MAGIC %run "../load"

# COMMAND ----------

# MAGIC %md
# MAGIC #### Let's ensure that the file was correctly written to the standardized zone

# COMMAND ----------

import time
from datetime import timedelta

current_time = datetime.now()
time_threshold = current_time - timedelta(minutes=1)
timestamp_threshold = int(time.mktime(time_threshold.timetuple()))

file_list = dbutils.fs.ls(sz_out_filepath)

TEST_FLAG = False
for file_partition in file_list:
    file_path = file_partition.path
    file_info = dbutils.fs.ls(file_path)

    if file_path.endswith('.snappy.parquet'):
        creation_time = file_info[0].modificationTime / 1000

        if creation_time > timestamp_threshold: 
            TEST_FLAG = True # loading was successful
            dbutils.fs.rm(file_path) # clean up file

# COMMAND ----------

if TEST_FLAG:
    print("The testing is successful and is working as expected. Cleaning up now.")
else:
    print("The testing has failed and is not working as expected.")