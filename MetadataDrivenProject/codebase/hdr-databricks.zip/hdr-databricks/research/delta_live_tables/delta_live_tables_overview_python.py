# Databricks notebook source
import dlt
from pyspark.sql.functions import * # test
from pyspark.sql.types import *

# COMMAND ----------

# MAGIC %md
# MAGIC ### Pipelines
# MAGIC Pipelines are defined in the **Workflows** tab in databricks. They are not defined in notebooks. To start this DLT pipeline go to *Workflows > Delta Live Tables* and select *weather_example*.
# MAGIC
# MAGIC Pipelines are the main unit in Delta Live Tables (DLT). A pipeline is a DAG that connects data sources to target **datasets**. 
# MAGIC
# MAGIC This DAG is composed of connected **datasets** that are created by **queries**.
# MAGIC
# MAGIC These queries can be in Python and SQL, and can be in a single notebook or spread across many notebooks. A single notebook must either be all SQL or all Python but a single pipeline can execute a mix of SQL and Python notebooks.
# MAGIC
# MAGIC **All notebooks in a pipeline share a single output location**. This has the format:
# MAGIC ```
# MAGIC {output folder}/
# MAGIC ├─ tables/ # stores the tables that are used in the pipeline. All tables are stored here, not just the final output
# MAGIC │  ├─ {table 1}/
# MAGIC │  │  ├─ {delta table info}
# MAGIC │  ├─ {table 2}/
# MAGIC │  │  ├─ {delta table info}
# MAGIC ├─ system/ # information used by databricks to manage the DLT pipeline
# MAGIC │  ├─ events/ # where information you want to monitor is stored, including failed Expectations, Lineage, PL events, etc.
# MAGIC ├─ autoloader/ # only if auto loader is used
# MAGIC │  ├─ {folders/files used to manage DLT}/
# MAGIC ├─ checkpoints/ # only if auto loader is used
# MAGIC │  ├─ {folders/files used to manage DLT}/
# MAGIC ```
# MAGIC
# MAGIC Pipelines can be either continuous or triggered, this is independent of the table type being used (*live* or *streaming live*):
# MAGIC   - **triggered**: update each table with whatever data is available at trigger time and then stops the cluster running the pipeline. DLT ensures table dependencies in the pipeline are followed.
# MAGIC   - **continuous**: update tables continuously as the input data changes. Once started, it will run on a continuously running cluster until it is manually stops. 
# MAGIC     - If the source is a Delta table, the pipeline only updates when it detects an update. If the source is not a Delta table, the table is still updated regularily but with a higher default trigger interval (10 minutes) (*pipelines.trigger.interval* configuration)
# MAGIC
# MAGIC To monitor your pipeline, use the `{output folder}\system\events` folder. For more information see: [this link from Microsoft](https://learn.microsoft.com/en-us/azure/databricks/workflows/delta-live-tables/delta-live-tables-event-log)
# MAGIC ### The pipeline creation UI is:
# MAGIC
# MAGIC ![dlt create ui](files/tables/weather_example/dlt_create_pl.PNG)
# MAGIC
# MAGIC ### The pipeline created by this notebook is:
# MAGIC
# MAGIC ![dlt pipeline](files/tables/weather_example/dlt_pipeline.PNG)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Queries
# MAGIC Queries are python functions or SQL statements that implement data transformations by defining a source and target **dataset**. The `@dlt.table` or `@dlt.view` decorator is used to indicate this function will output a dataset that will be used in the pipeline.
# MAGIC
# MAGIC The name of the function will be used as the name of the dataset it creates. You can also add a parameter in the `dlt.table` decorator in the format `@dlt.table(name="table_name")` that will be used if present:
# MAGIC
# MAGIC The format of these queries is generally :
# MAGIC ```
# MAGIC @dlt.table
# MAGIC def <output_table_name>():
# MAGIC     return (
# MAGIC        dlt.read / spark.read (<input table>)
# MAGIC          .<transformations>
# MAGIC          .select(<columns>)
# MAGIC     )
# MAGIC ```
# MAGIC You don't have to follow this convention, the following also works:
# MAGIC ```
# MAGIC @dlt.table
# MAGIC def <output_table_name>():
# MAGIC     df = dlt.read / spark.read (<input table>)
# MAGIC     df = df.<transformations>
# MAGIC     df = df.select(<columns)
# MAGIC     
# MAGIC     return df
# MAGIC ```
# MAGIC This can be used to impliment our DDC pipeline for example.
# MAGIC
# MAGIC If the query is using an *external data source* as its source, use either **Auto Loader** `spark.readStream` or PySpark's `spark.read` to read the data.
# MAGIC
# MAGIC If the query is using the *output of a previous query in the pipeline* as its source, use `dlt.read` to read the data.
# MAGIC
# MAGIC #### Auto Loader TL:DR
# MAGIC Auto Loader continuously monitors folders and automatically reads newly created files. It is recommended when files are immutable and new data results in new files being created, not recommended when files get updated. It creates the `\autoloader` and `\checkpoints` folders in the pipeline folder.

# COMMAND ----------

# MAGIC %md
# MAGIC ### Datasets
# MAGIC There are two types of datasets:
# MAGIC - **views**: which are like a view in SQL. This allows you to break up complex queries, or save the result of a query for use in multiple other queries.
# MAGIC - **tables**: which are like a table/materialized view in sql. These create delta tables in the pipeline's `/tables` folder.
# MAGIC
# MAGIC To determine which is appropriate to use, see [these best practices from databricks](https://docs.databricks.com/workflows/delta-live-tables/delta-live-tables-best-practices.html#choosing-between-tables-and-views.)
# MAGIC
# MAGIC You can define a live or streaming live view or table.
# MAGIC - **live**: always reflects the results of the query that defines it. Will recompute data if the query changes.
# MAGIC - **streaming live**: if the query changes, only newly processed data since the last update uses the new query, old data is not recomputed.
# MAGIC
# MAGIC #### Change Data Capture
# MAGIC Your Destination files can capture changes in the sources by using CDC in DLT. See [the databricks documentation for CDC](https://docs.databricks.com/workflows/delta-live-tables/delta-live-tables-cdc.html for more details as this is quite a large topic.)

# COMMAND ----------

# simple query that doesn't change the data
# creates a live table
@dlt.table
def weather_high_raw():
    return (
     # first time this data is in the pipeline, using spark.read()
        spark.read \
          .format("csv") \
          .option("header", True) \
          .load("/databricks-datasets/weather/high_temps")
  )

# COMMAND ----------

# MAGIC %md
# MAGIC ### Expectations
# MAGIC Expectations can be used to specify quality checks that are applied on columns. It is up to you how you want to treat values that fail these checks. You can either let them through, drop them, or halt the pipeline.
# MAGIC
# MAGIC You define expectations with a decorator before the query function.
# MAGIC
# MAGIC When a row fails an expectation, it is logged in the *DLT event log*.

# COMMAND ----------

@dlt.view #using a view, no need to save this as a table in the pl
@dlt.expect("valid_date_min", "date >= '2016-01-01'") # can use python or SQL here
@dlt.expect_or_drop("date_not_null", "date IS NOT NULL")
def weather_high_cleaned():
    # depends on another dataset already created, using dlt.read
    df = dlt.read("weather_high_raw")
    
    return df

# COMMAND ----------

# MAGIC %md
# MAGIC ### Publishing Data
# MAGIC DLT can publish data to the dataricks metastore. Adding a *target schema* when creating the pipeline will publish to that schema in the metastore. 
# MAGIC
# MAGIC To prevent a table from being published to the metastore, add the option `temporary=True` to the `@dlt.table` decorator.
# MAGIC
# MAGIC These can be accessed in notebooks using the *target schema* like:
# MAGIC ```
# MAGIC SELECT * from weather_example.weather_joined
# MAGIC ```
# MAGIC You can also browse the metastore by using the **Data** tab, ensuring a cluster is selected to use to browse the metastore, and selecting the schema you defined in *target schema* (note *weather_low_raw_streaming* is not present beacuse we set `temporary=True`):
# MAGIC
# MAGIC ![Showing Columns](files/tables/weather_example/dbricks_publish_table-3.PNG)

# COMMAND ----------

# create a table using Auto Loader
# creates a streaming live table
@dlt.table(
  temporary=True # prevents publishing to metastore
)
def weather_low_raw_streaming():
    return (
        spark.readStream \
          .format("cloudFiles") \
          .option("cloudFiles.format", "csv") \
          .load("/databricks-datasets/weather/low_*")
  )

# cleaning the low data using where instead of expectations
# this won't result in an event in the dlt event log
# creates a view
@dlt.view
def weather_low_cleaned_streaming():
    return(
        dlt.read_stream("weather_low_raw_streaming")\
          .where("date >= '2016-01-01'")
    )    
    
#joining the two sets together
@dlt.table(
  name="weather_joined",
  comment="joining the high and low weather data")
def join_weather_data_together():
    df_low = dlt.read_stream("weather_low_cleaned_streaming").alias("df_low")
    df_high = dlt.read("weather_high_cleaned").alias("df_high")
    
    return(
        df_low.join(df_high, df_low.date == df_high.date, how="inner") \
          .select(df_low.date, df_low.temp.alias('low'), df_high.temp.alias('high'))
    )