# Databricks notebook source
# MAGIC %md
# MAGIC # NO LONGER USED AS OF 2023-03-27

# COMMAND ----------

# MAGIC %run "../op_to_lz/configuration"

# COMMAND ----------

from cryptography.fernet import Fernet

# COMMAND ----------

def encrypt(filename, key):
    """
    Given a filename (str) and key (bytes), it encrypts the file and write it
    """
    f = Fernet(key)

# COMMAND ----------

#adlsAccountName="sthdringestzonedevtest"
#filename="20230109-090051_CLIENT_REGISTRY_IDENTIFIERS.parquet"
#tempfilename="20230109-090051_CLIENT_REGISTRY_IDENTIFIERS.tempparquet"
#orgname="nsha"
#schemaname="cr"
#systemname="hap"

# COMMAND ----------

adlsAccountName=dbutils.widgets.get("accountname")
filename=dbutils.widgets.get("filename")
tempfilename=dbutils.widgets.get("tempfilename")
orgname=dbutils.widgets.get("orgname")
schemaname=dbutils.widgets.get("schemaname")
systemname=dbutils.widgets.get("systemname")
filepath='/dbfs/mnt/'+adlsAccountName+'/'+orgname+'/'+systemname+'/'+schemaname +'/'+filename
filepathtemp='/dbfs/mnt/'+adlsAccountName+'/'+orgname+'/'+systemname+'/'+schemaname +tempfilename

# COMMAND ----------

print(filepathtemp)

# COMMAND ----------

encryptionkey=dbutils.secrets.get(scope="azurekvhdr-scope",key="encryptionkey")

# COMMAND ----------

f = Fernet(encryptionkey)

# COMMAND ----------

with open(filepathtemp, "rb") as file:
        # read all file data
        file_data = file.read()

# COMMAND ----------

encrypted_data = f.encrypt(file_data)


# COMMAND ----------

    with open(filepath, "wb") as file:
        file.write(encrypted_data)