# Databricks notebook source
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, explode 

# COMMAND ----------

# MAGIC %run ../common_functions/UtilityFunctions

# COMMAND ----------

# DBTITLE 1,Get HDR Last Load Date
dblist=['dad','dis','cr','nafp','nscaf','ed','pr','dss']
for i in dblist:
    df=spark.sql(f"show tables in {i}")
    for j in df.collect():
        try:
            df2=str(spark.sql(f"select max(HDR_LASTLOADDATE) from {i}.{j[1]}").collect()[0][0])
            print(i,'|',j[1],'|',df2)
        except:
            pass

# COMMAND ----------

# DBTITLE 1,Data Validation - Hive Table Count check
dbs=spark.sql("SHOW DATABASES")
exclude_db = ["test","default","weather_example","testing","log","hub","adf_config","mz_out","parns"]
include_db=[]
dblist = dbs.filter(~dbs.databaseName.isin(exclude_db)).collect()
if len(include_db)>0:
    dblist = dbs.filter(dbs.databaseName.isin(include_db)).collect()
results=[]
error_list=[]

#Loop through DBs and Tables
for i in dblist:
    db_name = i["databaseName"]
    spark.sql(f"USE {db_name}")
    tables= spark.sql("SHOW TABLES")
    exclude_table = [] 
    tbl_list = tables.filter(~tables.tableName.isin(exclude_table)).collect()
    include_table=[]
    if len(include_table)>0:
        tbl_list = tables.filter(tables.tableName.isin(include_table)).collect()
    for j in tbl_list:
        table_name = j["tableName"]
        try:
            count= spark.sql(f"SELECT COUNT(*) as count from {db_name}.{table_name}").collect()[0][0]
            results.append((db_name,table_name, count))

        except :         
           # error_handling(f"Table {table_name} does not exist in DB {db_name}. Skipping..", str(e))
            print(f"Table {table_name} does not exist in DB {db_name}. Skipping..")
            error_list.append((db_name,table_name, 'ERROR'))
df = spark.createDataFrame(results, ["Database","Table","Count"])
error_df = spark.createDataFrame(error_list, ["Database","Table","Count"])
display(df)
display(error_df)
#spark.stop()    
# """     
                      
                         
            

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE schema data_validation

# COMMAND ----------

# DBTITLE 1,Create Delta Table in ADLS and Hive Table in DBX
dbschema = "data_validation"
dv_count_table= "HiveTableCount"
dv_error_count_table= "HiveTableCountError"
#Creating tables in ADLS Gen2 location
df.write.format("delta").mode("overwrite").save("/mnt/sthdrcurzonedevtest/data_validation/HiveTableCount")
error_df.write.format("delta").mode("overwrite").save("/mnt/sthdrcurzonedevtest/data_validation/HiveTableCountError")
#Creating Hive Tables upon ADLS Location
spark.sql(f"create table if not exists {dbschema}.{dv_count_table} using delta location 'dbfs:/mnt/sthdrcurzonedevtest/data_validation/{dv_count_table}'")
spark.sql(f"create table if not exists {dbschema}.{dv_error_count_table} using delta location 'dbfs:/mnt/sthdrcurzonedevtest/data_validation/{dv_error_count_table}'")


# COMMAND ----------

# DBTITLE 1,Code for Incremental Record Count
from pyspark.sql import SparkSession
import pyspark
from pyspark.sql.functions import lit
from delta.tables import *


results = []
dbs=spark.sql("SHOW DATABASES")#.collect()
print(dbs)
exclude_db = ["test","default","weather_example","testing","log","hub","adf_config","mz_out","parns","data_validation","sz"]
dblist = dbs.filter(~dbs.databaseName.isin(exclude_db)).collect()
include_db=[]
if len(include_db)>0:
    dblist = dbs.filter(dbs.tableName.isin(include_db)).collect()
colm = []
target_database = "data_validation"
target_table = "IncrementalRecords"
loc = "/mnt/sthdrcurzonedevtest/data_validation"
target_table_full_path = f"{loc}/{target_table}"
for i in dblist:
    db_name = i["databaseName"]
    spark.sql(f"USE {db_name}")
    tables= spark.sql("SHOW TABLES")
    print(tables)
    exclude_table = []
    tbl_list = tables.filter(~tables.tableName.isin(exclude_table)).collect()
    include_table=["mzin","mzout","czstg","cz"]
    if len(include_table)>0:
        tbl_list=tables.filter(tables.tableName.isin(include_table)).collect()
        print(tbl_list)
    for j in tbl_list:
        table_name = j["tableName"]    
        dfdesc= spark.sql(f"select _created_date,_modified_date, count(*) c from {db_name}.{table_name} group by 1,2 ")
        colm.extend(dfdesc.columns)
        #print(colm)
        dfdesc = dfdesc.withColumn("Table",lit(table_name))
        dfdesc = dfdesc.withColumn("Database",lit(db_name))
        print(dfdesc)
        dfdesc.write.format("delta").mode("append").save("/mnt/sthdrcurzonedevtest/data_validation/IncrementalRecords")
 

spark.sql(f"create table if not exists data_validation.IncrementalRecords using delta location 'dbfs:/mnt/sthdrcurzonedevtest/data_validation/IncrementalRecords'")



            

# COMMAND ----------

# DBTITLE 1,Code for DESCRIBE HISTORY  - IN PROGRESS -
from pyspark.sql import SparkSession
import pyspark
from pyspark.sql.functions import lit
from delta.tables import *


results = []
dbs=spark.sql("SHOW DATABASES")#.collect()
exclude_db = ["test","default","weather_example","testing","log","hub","adf_config","mz_out","parns","mzin","mzout","czstg","cz","data_validation"]
dblist = dbs.filter(~dbs.databaseName.isin(exclude_db)).collect()
include_db=[]
if len(include_db)>0:
    dblist = dbs.filter(dbs.tableName.isin(include_db)).collect()
colm = []
target_database = "data_validation"
target_table = "HistoryTracking"
loc = "/mnt/sthdrcurzonedevtest/data_validation"
target_table_full_path = f"{loc}/{target_table}"

for i in dblist:
    db_name = i["databaseName"]
    spark.sql(f"USE {db_name}")
    tables= spark.sql("SHOW TABLES")
    exclude_table = []
    tbl_list = tables.filter(~tables.tableName.isin(exclude_table)).collect()
    include_table=[]
    if len(include_table)>0:
        tbl_list=tables.filter(tables.tableName.isin(include_table)).collect()
    for j in tbl_list:
        try:
            table_name = j["tableName"]
            #print(table_name)
            dfdesc= spark.sql(f"DESCRIBE HISTORY {db_name}.{table_name}")
            dfdesc=dfdesc.withColumn("Table",lit(table_name))\
                        .withColumn("Database",lit(db_name))
            dfdesc = dfdesc.select([col(column_name).cast("string") for column_name in dfdesc.columns])
            dfdesc.write.format("delta").mode("append").save("/mnt/sthdrcurzonedevtest/data_validation/HistoryTracking")
        except:
            print(f"the table {table_name} in database {db_name} is not a deltatable")

spark.sql(f"create table if not exists data_validation.HistoryTracking using delta location 'dbfs:/mnt/sthdrcurzonedevtest/data_validation/HistoryTracking'")

            

# COMMAND ----------

results = []
dbs=spark.sql("SHOW DATABASES")#.collect()
exclude_db = ["test","default","weather_example","testing","log","hub","adf_config","mz_out","parns","mzin","mzout","czstg","cz","data_validation"]
dblist = dbs.filter(~dbs.databaseName.isin(exclude_db)).collect()
include_db=[]
if len(include_db)>0:
    dblist = dbs.filter(dbs.tableName.isin(include_db)).collect()
colm = []
target_database = "data_validation"
target_table = "DetailedHistoryTracking"
loc = "/mnt/sthdrcurzonedevtest/data_validation"
target_table_full_path = f"{loc}/{target_table}"

for i in dblist:
    db_name = i["databaseName"]
    spark.sql(f"USE {db_name}")
    tables= spark.sql("SHOW TABLES")
    exclude_table = []
    tbl_list = tables.filter(~tables.tableName.isin(exclude_table)).collect()
    include_table=[]
    if len(include_table)>0:
        tbl_list=tables.filter(tables.tableName.isin(include_table)).collect()
    for j in tbl_list:
        try:
            table_name = j["tableName"]
            #print(table_name)
            dfdesc= spark.sql(f"DESCRIBE HISTORY {db_name}.{table_name}")
            dfdesc=dfdesc.withColumn("Table",lit(table_name)).withColumn("Database",lit(db_name))
            dfdesc=dfdesc.filter(dfdesc.operation.isin(['MERGE','WRITE']))
            dfdesc = dfdesc.select("*", explode(col("operationmetrics")))
            col_ls=['version', 'timestamp',  'userName', 'operation',  'Table', 'Database','key','value']
            dfdesc=dfdesc.select(*col_ls)
            dfdesc.write.format('delta').mode('append').partitionBy('Table').save(target_table_full_path)
        except:
            print(f"Writing of DF failed for table {table_name} in database {db_name}")

# COMMAND ----------

spark.sql(f"create table data_validation.detailedhistorytracking using delta location {target_table_full_path}")
spark.sql("optimize delta.`{target_table_full_path}`")           

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from data_validation.IncrementalRecords where database = 'mzin' and Table like '%person' 
# MAGIC order by table asc

# COMMAND ----------

# MAGIC %sql
# MAGIC select HDR_LASTLOADDATE, DW_TimeStamp, count(*) from dad.dad_hospital_data_icd10 group by 1,2 order by 2 desc

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from data_validation.incrementalrecords where table like '%address%'

# COMMAND ----------

# MAGIC %sql
# MAGIC drop table data_validation.history_track

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from data_validation.history_tracking where table like '%nafp%'

# COMMAND ----------

from pyspark.sql import SparkSession
import pyspark
from pyspark.sql.functions import lit
from delta.tables import *


results = []
dbs=spark.sql("SHOW DATABASES")#.collect()
exclude_db = ["test","default","weather_example","testing","log","hub","adf_config","mz_out","parns","data_validation","sz"]
dblist = dbs.filter(~dbs.databaseName.isin(exclude_db)).collect()
include_db=['']
if len(include_db)>0:
    dblist = dbs.filter(dbs.tableName.isin(include_db)).collect()
colm = []
target_database = "data_validation"
target_table = "hdr_lastloaddate"
loc = "/mnt/sthdrcurzonedevtest/data_validation"
target_table_full_path = f"{loc}/{target_table}"
for i in dblist:
    db_name = i["databaseName"]
    spark.sql(f"USE {db_name}")
    tables= spark.sql("SHOW TABLES")
    exclude_table = []
    tbl_list = tables.filter(~tables.tableName.isin(exclude_table)).collect()
    include_table=["mzin"]
    if len(include_table)>0:
        tbl_list=tables.filter(tables.tableName.isin(include_table)).collect()
    for j in tbl_list:
        table_name = j["tableName"]    
        dfdesc= spark.sql(f"select _created_date,_modified_date, count(*) c from {db_name}.{table_name} group by 1,2 ")
        colm.extend(dfdesc.columns)
        #print(colm)
        dfdesc = dfdesc.withColumn("Table",lit(table_name))
        dfdesc = dfdesc.withColumn("Database",lit(db_name))
        dfdesc.write.format("delta").mode("append").save("/mnt/sthdrcurzonedevtest/data_validation/IncrementalRecords")
 

spark.sql(f"create table if not exists data_validation.IncrementalRecords using delta location 'dbfs:/mnt/sthdrcurzonedevtest/data_validation/IncrementalRecords'")



            