# Databricks notebook source
from pyspark.sql.functions import current_timestamp,lit, to_timestamp,dense_rank,max,when,col,monotonically_increasing_id,concat_ws,hash,row_number,sha2
from delta.tables import *
from pyspark.sql.window import Window

# COMMAND ----------

def Get_latest_records(df,output_path,pk):
    windowSpec  = Window.partitionBy(pk).orderBy(col('_modified_date').desc(),col('_created_date').desc())
    df=df.withColumn('row',row_number().over(windowSpec)).filter("row==1")
    df=df.drop('row')
    return df

# COMMAND ----------


def Write_SCD_Delta(input,output_location,pk,pipelineid,ct,Type='SCD1',fullloadind=False):
  if Type=='SCD1':
    # Creating Hash Column
    concatenated = concat_ws(",", *[col for col in sorted(input.columns)])
    #row_hash = hash(concatenated)
    row_hash = sha2(concatenated,256)
    hash_input = input.withColumn('_rowhash', row_hash)
    audit_col=["_created_date","_modified_date","_eff_from_date","_eff_to_date","is_active","_execution_id","_rowhash","_merge_key","isdeleted"]

    # Creating Update constraints
    update_cons={"_created_date": "output._created_date",
          "_modified_date": "updates._modified_date",
          "_eff_from_date": "output._eff_from_date",
          "_eff_to_date": "updates._eff_to_date",
          "is_active": "updates.is_active",
          "_execution_id":"updates._execution_id",
          "_rowhash":"updates._rowhash",
          "_merge_key":"updates._merge_key"}
    input_col=hash_input.columns
    for i in input_col:
      update_cons[i]=("updates."+i)

    #Determining First Load/ Incremental load
    try:
      existance=len(dbutils.fs.ls(output_location))
    except:
      existance=0

    #Merging of input data
    if existance==0:
      print('Initial load running')
      duplicate_check=hash_input.groupBy(pk[0]).count().filter(col("count") > 1).count()
      if duplicate_check>0:
          raise Exception(f"Column {pk} having duplicate records") 
      processed_output=hash_input.withColumn('_created_date',lit(ct))\
      .withColumn('_modified_date',lit(ct))\
      .withColumn('_eff_from_date',lit(ct))\
      .withColumn('_eff_to_date',when(col("IsDeleted") == "Y", lit(ct)).otherwise(to_timestamp(lit('9999-12-31T00:00:00.036+0000'))))\
      .withColumn("is_active", when(col("IsDeleted") == "Y", "N").otherwise("Y"))\
      .withColumn('_execution_id',lit(pipelineid))\
      .withColumn('_merge_key',lit(''))
      new_columns = audit_col + [col for col in processed_output.columns if col.lower() not in audit_col] 
      processed_output = processed_output.select(*new_columns)
      processed_output.write.format('delta').mode('overwrite').save(output_location)
    else:
      print('Incremental load running')
      duplicate_check=hash_input.groupBy(pk[0]).count().filter(col("count") > 1).count()
      if duplicate_check>0:
          raise Exception(f"Column {pk} having duplicate records") 
      output_table = DeltaTable.forPath(spark, output_location)
      processed_output=hash_input.withColumn('_modified_date',lit(ct))\
      .withColumn('_created_date',lit(ct))\
      .withColumn('_eff_from_date',lit(ct))\
      .withColumn('_eff_to_date',when(col("IsDeleted") == "Y", lit(ct)).otherwise(to_timestamp(lit('9999-12-31T00:00:00.036+0000'))))\
      .withColumn("is_active", when(col("IsDeleted") == "Y", "N").otherwise("Y"))\
      .withColumn('_execution_id',lit(pipelineid))\
      .withColumn('_merge_key',lit(''))
      update_condition="output._rowhash != updates._rowhash"
      if fullloadind==True:
        output_table_df=output_table.toDF()
        deleted_rows=output_table_df.join(processed_output, on=pk, how="left_anti")\
        .withColumn('IsDeleted',lit('Y'))\
        .withColumn('_modified_date',lit(ct))\
        .withColumn('_eff_to_date',lit(ct))\
        .withColumn('is_active',lit('N'))
        cols1 = sorted(processed_output.columns)
        cols2 = sorted(deleted_rows.columns)
        processed_output = processed_output.select(*[col(c) for c in cols1])
        deleted_rows = deleted_rows.select(*[col(c) for c in cols2])
        processed_output=processed_output.union(deleted_rows)
        update_condition="(output._rowhash != updates._rowhash) or updates.IsDeleted=='Y'"
      merge_condition=''
      for i in pk:
        if merge_condition=='':
          merge_condition="output.{i}==updates.{i}".format(i=i)
        else:
          merge_condition=merge_condition+' and '+"output.{i}==updates.{i}".format(i=i)
      output_table.alias('output') \
      .merge(
        processed_output.alias('updates'),
        merge_condition
      ) \
      .whenMatchedUpdate(set =update_cons,condition=update_condition)\
      .whenNotMatchedInsertAll()\
      .execute()
  elif Type=='SCD2':
    concatenated = concat_ws(",", *[col for col in sorted(input.columns)])
    #row_hash = hash(concatenated)
    row_hash = sha2(concatenated,256)
    hash_output = input.withColumn('_rowhash', row_hash)
    audit_col=["_created_date","_modified_date","_eff_from_date","_eff_to_date","is_active","_execution_id","_rowhash","_merge_key","isdeleted"]

    #Update constraints
    update_cons={
                "_created_date":"output._created_date" ,
                "_modified_date":"updates._modified_date",
                "_eff_from_date":"output._eff_from_date",
                "_eff_to_date":lit(ct),
                "is_active": lit("N"),
                "_execution_id":"output._execution_id",
                "_merge_key":"output._merge_key"
                }
    insert_cons={
                "_created_date":"updates._created_date" ,
                "_modified_date":"updates._modified_date",
                "_eff_from_date":"updates._eff_from_date",
                "_eff_to_date":"updates._eff_to_date",
                "is_active": "updates.is_active",
                "_execution_id":"updates._execution_id",
                "_merge_key":"updates._merge_key"
                }
    input_col=hash_output.columns
    for i in input_col:
        update_cons[i]=("output."+i)
        insert_cons[i]=("updates."+i)

    #Loading table for SCD-2
    try:
        existance=len(dbutils.fs.ls(output_location))
    except:
        existance=0
    if existance==0:
        print('Initial load running')
        duplicate_check=hash_output.groupBy(pk[0]).count().filter(col("count") > 1).count()
        if duplicate_check>0:
            raise Exception(f"Column {pk} having duplicate records")
        inc_table=hash_output.withColumn('_created_date',lit(ct))\
        .withColumn('_modified_date',lit(ct))\
        .withColumn('_eff_from_date',lit(ct))\
        .withColumn('_eff_to_date',when(col("IsDeleted") == "Y", lit(ct)).otherwise(to_timestamp(lit('9999-12-31T00:00:00.036+0000'))))\
        .withColumn("is_active", when(col("IsDeleted") == "Y", "N").otherwise("Y"))\
        .withColumn('_execution_id',lit(pipelineid))\
        .withColumn('_merge_key',lit(''))
        new_columns = audit_col + [col for col in inc_table.columns if col.lower() not in audit_col] 
        inc_table = inc_table.select(*new_columns)
        inc_table.write.format('delta').mode('overwrite').save(output_location)
    else:
        print('Incremental load running')
        duplicate_check=hash_output.groupBy(pk[0]).count().filter(col("count") > 1).count()
        if duplicate_check>0:
            raise Exception(f"Column {pk} having duplicate records")
        output_table = DeltaTable.forPath(spark, output_location)
        intermediate_table=output_table.toDF()
        intermediate_table=Get_latest_records(intermediate_table,output_location,pk[0])
        inc_table=hash_output.withColumn('_created_date',lit(ct))\
        .withColumn('_modified_date',lit(ct))\
        .withColumn('_eff_from_date',lit(ct))\
        .withColumn('_eff_to_date',when(col("IsDeleted") == "Y", lit(ct)).otherwise(to_timestamp(lit('9999-12-31T00:00:00.036+0000'))))\
        .withColumn("is_active", when(col("IsDeleted") == "Y", "N").otherwise("Y"))\
        .withColumn('_execution_id',lit(pipelineid))\
        .withColumn('_merge_key',lit(''))
        new_columns = audit_col + [col for col in inc_table.columns if col.lower() not in audit_col] 
        inc_table = inc_table.select(*new_columns)
        final_table_to_insert=inc_table.alias('a').join(intermediate_table.alias('b'), on="_rowhash", how="left_anti").select("a.*").withColumn('merge_ind',lit('INSERT'))
        final_table_to_update=inc_table.alias('c').join(intermediate_table.alias('d'), on=["source_keyattr"],how="inner").filter("c._rowhash !=d._rowhash").select("c.*").withColumn('merge_ind',lit('UPDATE'))
        scd2_input=final_table_to_insert.unionByName(final_table_to_update)
        output_table.alias('output') \
        .merge(
            scd2_input.alias('updates'),
            f"output.{pk[0]}==updates.{pk[0]} AND updates.merge_ind=='UPDATE'"
        ) \
        .whenMatchedUpdate(set =update_cons,condition="updates.merge_ind=='UPDATE' and output.is_active='Y'")\
        .whenNotMatchedInsert(values=insert_cons)\
        .execute()

# COMMAND ----------

#Error log functionality
def error_handling(error_type, error_message):
 raise Exception(f"Error: {error_type},Error_Message:{error_message}")

# COMMAND ----------

def ReadfromSQL(kv_scope,con_secret,table_name,DestinationTableName):
    configJdbcUrl = dbutils.secrets.get(scope=kv_scope, key=con_secret)
    lastloaddate=spark.sql(f"select lastloaddatetime from adf_config.adf_datasetlog where DatasetName ='{DestinationTableName}'").collect()[0][0]
    if (lastloaddate==None):
        lastloaddate = '1900-01-01'
    query=f"select * from {table_name} where lastchgdtm>'{lastloaddate}'"
    df=spark.read.format('jdbc').option('query',query).option('url',configJdbcUrl).load()
    return df

# COMMAND ----------

def df_format_columns(df):
    char_to_replace = {'\.':'_','\$':''}
    col_dict={}
    for col_name in df.columns:
        col_renamed = col_name
        col_renamed = col_renamed.translate({ord(c): "" for c in "()"})
        for key, value in char_to_replace.items():
            col_renamed = re.sub(r"{}".format(key), value, col_renamed)
        df = df.withColumnRenamed(col_name, col_renamed)
    return df

# COMMAND ----------

def read_config(env_config_path):
    data = ''
    with open(env_config_path, 'r') as s:
        data = json.load(s)
    return json.dumps(data)

# COMMAND ----------

def dataset_log(start_date,pipeline_runid,status,Error_message,end_date):
    columns=["start_datetime","pipeline_runid","status","Error_message","end_datetime"]
    values=[start_date,pipeline_runid,status,Error_message,end_date]
    df=spark.createDataFrame([values],columns)
    target_path='/mnt/sthdrcurzonedevtest/log/'
    target_table="log.pipelinedtlog"
    if DeltaTable.isDeltaTable(spark, target_path):
            print(1)
            df.write.format("delta").option("overwriteSchema","true").insertInto(target_table)
    else:
            print(2)
            df.write.format("delta").mode("overwrite").option("path", target_path).saveAsTable(target_table)



# COMMAND ----------

def Generate_IDColumn(input,output_location,pk,id_generated_col):
    try:
        existance=len(dbutils.fs.ls(output_location))
        output=spark.read.format('delta').load(output_location)
        df_cnt=output.count()
    except:
        existance=0
    if (existance==0 or df_cnt==0):
        windowSpec  = Window.orderBy(pk)
        new_df=input.withColumn(id_generated_col,dense_rank().over(windowSpec))
        return new_df
    else:
        output=spark.read.format('delta').load(output_location)
        joined_df = input.join(output, on=pk, how='left').select(input['*'], output[id_generated_col])
        max_id = output.select(max(id_generated_col)).first()[0]
        #new_df = joined_df.withColumn(id_generated_col, when(col(id_generated_col).isNull(), row_number().over(Window.orderBy(pk)) + max_id).otherwise(col(id_generated_col)))
        df_with_null=joined_df.filter(f"{id_generated_col} is null").withColumn(id_generated_col, row_number().over(Window.orderBy(pk)) + max_id)
        new_df=joined_df.filter(f"{id_generated_col} is not null").union(df_with_null)
        colname=new_df.columns
        colname.remove(id_generated_col)
        colname.insert(0,id_generated_col)
        new_df=new_df.select(*colname)
        return new_df

# COMMAND ----------

