# Databricks notebook source
import time
import json

from delta.tables import DeltaTable
from pprint import pprint
from pyspark.sql.utils import AnalysisException

# COMMAND ----------

# parameters passed in by the generic child pipeline for the profisee work
# this pipeline does not use most of them

dbutils.widgets.text('DestinationTableName','')
table_name=dbutils.widgets.get('DestinationTableName')

dbutils.widgets.text('MasterRunId','')
pipelineid=dbutils.widgets.get('MasterRunId')

# not used
dbutils.widgets.text('NumofRetry','')
no_of_retry=dbutils.widgets.get('NumofRetry')

# not used
dbutils.widgets.text('KeyAttrName','')
primary_key=dbutils.widgets.get('KeyAttrName')

# not used
dbutils.widgets.text('SrcFullLoadInd','')
fullloadind=dbutils.widgets.get('SrcFullLoadInd')

# not used
dbutils.widgets.text('DestinationPathNTable','')
output_path=dbutils.widgets.get('DestinationPathNTable')

dbutils.widgets.text('TransfScriptPath','')
script_path=dbutils.widgets.get('TransfScriptPath')

# not used
dbutils.widgets.text('GenerateId','')
generate_id_ind=dbutils.widgets.get('GenerateId')

# not used
dbutils.widgets.text('IDLabel','')
generate_id_col=dbutils.widgets.get('IDLabel')

# not used
dbutils.widgets.text('TransformationType','')
TransformationType=dbutils.widgets.get('TransformationType')

script_path = script_path + table_name + ".txt"

# COMMAND ----------

# MAGIC %md
# MAGIC # Trigger
# MAGIC This pipeline is called from a synapse pipeline, `pl_generic_child`, that is part of the Profisee consolidation and linkage process. `pl_generic_child` is called several times with different parameters retrieved from the control table `dbo`.`ADF_DataTransformationRules` as part of the parent pipeline `pl_generic_e2e_execution`.
# MAGIC
# MAGIC # Parameters
# MAGIC ## Synapse Generic Pipieline Parameters
# MAGIC - `p_execution_num`: `ExecutionOrder` from the control table `dbo`.`ADF_DataTransformationRules`.
# MAGIC
# MAGIC - `master_pipeline_run_id`: the pipeline run id for the parent generic pipeline. A system variable available to all synapse pipelines.
# MAGIC
# MAGIC - `master_pipeline_name`: the pipeline name for the parent generic pipeline, A system variable available to all synapse pipelines.
# MAGIC
# MAGIC - `pipeline_id`: `PipelineId` from the control table `dbo`.`ADF_DataTransformationRules`.
# MAGIC
# MAGIC - `child_pipeline_name`: `PipelineName` from the control table `dbo`.`ADF_DataTransformationRules`.
# MAGIC
# MAGIC - `last_execution_order`: Gets the value of `ExecutionOrder` for the last row returned by the query 
# MAGIC ```
# MAGIC     SELECT ExecutionOrder, PipeineName, PipelineId 
# MAGIC     FROM [dbo].[ADF_DataTransformationRules] 
# MAGIC     WHERE Enabled='True' and Environment = '@{pipeline().parameters.pENVIRONMENT}' 
# MAGIC     GROUP BY ExecutionOrder, PipelineName, PipelineId 
# MAGIC     ORDER BY ExecutionOrder
# MAGIC ```
# MAGIC
# MAGIC - `environment`: passed in from parent generic pipeline trigger.
# MAGIC
# MAGIC ## Databricks Pipeline Parameters
# MAGIC - `DestinationPathNTable`: Not used for this pipeline.
# MAGIC
# MAGIC - `DestinationTableName`: The name of the script in the transformation scripts folder that is used for this table.
# MAGIC
# MAGIC - `GenerateId`: Not used for this pipeline. 
# MAGIC
# MAGIC - `IDLabel`: Not used for this pipeline.
# MAGIC
# MAGIC - `KeyAttrName`: Not used for this pipeline.
# MAGIC
# MAGIC - `MasterRunId`: Not used for this pipeline.
# MAGIC
# MAGIC - `NumofRetry`: Not used for this pipeline.
# MAGIC
# MAGIC - `SrcFullLoadInd`: Not used for this pipeline.
# MAGIC
# MAGIC - `TransfScriptPath`: The location of the folder containing the transformation configuration scripts.
# MAGIC
# MAGIC - `TransformationType`: Not used for this pipeline.
# MAGIC
# MAGIC # Tables involved
# MAGIC ## Crosswalk tables that store the MDM GoldenRecord Identifier for person and provider in the curated zone
# MAGIC - `curated/dhw/czstg/cz_person_xwalk_ext/`
# MAGIC - `curated/dhw/czstg/cz_provider_xwalk_ext/`
# MAGIC
# MAGIC ## Standardized tables that contribute to the MDM entities
# MAGIC ###Person
# MAGIC - `standardized/dhw/hap/cr/CLIENT_REGISTRY_COMPOSITE_VIEW.delta`
# MAGIC - `standardized/dhw/hap/dss/DSS_INDIVIDUAL_2.delta`
# MAGIC - `standardized/dhw/hap/dis/PERSON.delta`
# MAGIC - `standardized/dhw/hap/nafp/NSHEALTH_DHW_NAFP_DHW_Query_Monthly.delta`
# MAGIC
# MAGIC ###Provider
# MAGIC - `standardized/dhw/hap/dis/PROVIDER.delta`
# MAGIC - `standardized/dhw/hap/dss/DSS_PROVIDER_2.delta`
# MAGIC - `standardized/dhw/hap/dss/PROVIDER_REGISTRY_IDENTIFIERS.delta`

# COMMAND ----------

with open(script_path) as f:
    config = json.load(f)

pprint(config)

# COMMAND ----------

def check_table_for_column(table_name: str, column_name: str):
    """Checks to see if a column exists in a delta table file

    Args:
      table_name: the name of the table, including schema, that is mounted in the metastore
      column_name: the column to check if exists

    Returns:
      True if column exists in table, False otherwise
    """
    
    try:
        spark.sql(f"SELECT {column_name} FROM {table_name} LIMIT 0")
        return True
    except AnalysisException:
        print(f"Couln't find {column_name} in {table_name}")
        return False
    

def retry_action(
    action,
    max_retries=3,
    delay_seconds=[5, 30, 60], 
    exceptions_to_catch=(Exception,),
):
    """Retries the function 'action' up to max_retries, with a progressively increasing delay.

    Args:
      action: a function that should be retried
      max_retries: the max number of retries
      delay_seconds: a list with max_retries entries of how long to delay after each failure
      exceptions_to_catch: a tuple containing all types of errors to catch and retry after

    Returns:
      the output of the action function
    """
    attempts = 0

    while attempts < max_retries:
        try:
            result = action()
            return result
        
        except exceptions_to_catch as e:
            print(f"Attempt {attempts + 1} failed with exception: {e}")
            attempts += 1

            if attempts < max_retries:
                print(f"Retrying in {delay_seconds} seconds...")
                time.sleep(delay_seconds[attempts])

            else:
                print("Max retries reached. Exiting.")
                raise 


def merge_data(full_load: bool):
    """A convenience function that is used to retry the merge operation

    Args:
      full_load: an indicator on whether this is a full or incremental load (1 = full)

    Returns:
      None
    """
    print("Performing the merge operation...")

    df = spark.sql(config["merge_goldenrec_column_sql"].format(full_load=full_load))

    print("Merge complete. Summary:")

    df.show()


# COMMAND ----------

   
# check and add the column manually instead of relying on automatic schema evolution
# not a good use case for automatic schema evolution (risk of contaminating standardized not worth it)
if not check_table_for_column(config["target_table_name"], config["target_table_column"]):
    print(f"Adding column {config['target_table_column']} to {config['target_table_name']}") 
    spark.sql(f"ALTER TABLE {config['target_table_name']} ADD COLUMN {config['target_table_column']} STRING")
    print("Column added.")
try:
    result = retry_action(lambda: merge_data(config['full_load']), # lambda passes as a function including parameters
                          max_retries=3,
                          delay_seconds=[30, 60, 300]) # long delay in case of exception due to concurrent write on standardized
except Exception as e:
    print(f"Action failed after max retries with exception: {e}")
