# Databricks notebook source
# DBTITLE 1,Getting current timestamp
import datetime
ct = datetime.datetime.now()

# COMMAND ----------

# DBTITLE 1,Importing widgets
dbutils.widgets.text('DestinationTableName','')
table_name=dbutils.widgets.get('DestinationTableName')

dbutils.widgets.text('MasterRunId','')
pipelineid=dbutils.widgets.get('MasterRunId')

dbutils.widgets.text('NumofRetry','')
no_of_retry=dbutils.widgets.get('NumofRetry')

dbutils.widgets.text('KeyAttrName','')
primary_key=dbutils.widgets.get('KeyAttrName')

dbutils.widgets.text('SrcFullLoadInd','')
fullloadind=dbutils.widgets.get('SrcFullLoadInd')

dbutils.widgets.text('DestinationPathNTable','')
output_path=dbutils.widgets.get('DestinationPathNTable')

dbutils.widgets.text('TransfScriptPath','')
script_path=dbutils.widgets.get('TransfScriptPath')

dbutils.widgets.text('GenerateId','')
generate_id_ind=dbutils.widgets.get('GenerateId')

dbutils.widgets.text('IDLabel','')
generate_id_col=dbutils.widgets.get('IDLabel')

dbutils.widgets.text('TransformationType','')
TransformationType=dbutils.widgets.get('TransformationType')


script_path=script_path+table_name.lower()+".txt"


# COMMAND ----------

# DBTITLE 1,Executing utility functions
# MAGIC %run ../common_functions/UtilityFunctions

# COMMAND ----------

# DBTITLE 1,Transformation script execution
try:
    with open(script_path, "r") as trans_script:
        words = trans_script.read()
    df=spark.sql(words)
except Exception as e:
    error_handling("Unable to process script file", str(e))

# COMMAND ----------

# DBTITLE 1,Generating id column
if generate_id_ind=='True':
    df=Generate_IDColumn(df,output_path,primary_key,generate_id_col)

# COMMAND ----------

# DBTITLE 1,Executing SCD function
Write_SCD_Delta(df,output_path,primary_key.split(','),pipelineid,ct,TransformationType,fullloadind)

# COMMAND ----------

# DBTITLE 1,Creating hive table
database=output_path.split('/')[4]
try:
    table_existance=spark.sql(f"show tables in {database} like '{table_name}'").count()
except:
    table_existance=0
if table_existance==0:
    database=output_path.split('/')[4]
    table=table_name
    spark.sql(f"create database if not exists {database}")
    spark.sql(f"create table if not exists {database}.{table} using delta location 'dbfs:{output_path}'")
    spark.sql(f"alter table {database}.{table} SET TBLPROPERTIES (delta.enableChangeDataFeed=true)")
    spark.sql(f"ALTER TABLE delta.`{output_path}` SET TBLPROPERTIES(delta.logRetentionDuration = 'interval 730 days')")
    spark.sql(f"ALTER TABLE {database}.{table} ALTER COLUMN {primary_key} SET NOT NULL")
else:
    spark.sql(f"OPTIMIZE delta.`{output_path}` ZORDER BY (_modified_date)")


# COMMAND ----------

# DBTITLE 1,Updating dataset log
max_date=spark.sql(f"select max(_modified_date) from {database}.{table_name}").collect()[0][0]
if max_date==None:
    dbutils.notebook.exit(f"Output table {table_name} don't have any records")
else:
    query=f"update adf_config.adf_datasetlog set LastLoadDateTime='{max_date}' where DatasetName='{table_name}'"
    retry=int(no_of_retry)
    while retry>0:
        try:
            spark.sql(query)
            retry=0
        except:
            retry=retry-1
            if retry==0:
                spark.sql(query)
    dbutils.notebook.exit(f"Execution completed and lastloaddate for table {table_name} updated to {max_date}")