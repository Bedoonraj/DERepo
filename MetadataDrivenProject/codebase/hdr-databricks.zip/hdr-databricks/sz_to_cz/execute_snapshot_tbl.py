# Databricks notebook source
# DBTITLE 1,Import Library
import json
from pyspark.sql.functions import *
from pyspark.sql.window import Window

# COMMAND ----------

# DBTITLE 1,Get Param
dbutils.widgets.text('Environment','')
Environment=dbutils.widgets.get('Environment')

# COMMAND ----------

# DBTITLE 1,Environment variable
if Environment=='DEV':
    config_path="/mnt/sthdrcurzonedevtest/ds_config/"
else:
    config_path="/mnt/sthdrcurzoneprd/ds_config/"

# COMMAND ----------

# DBTITLE 1,Get connection string
result = dbutils.fs.head(config_path+'config.txt')
env_config_data = json.loads(result)
kv_scope=env_config_data[Environment]["kvscope_configdb"]
con_secret=env_config_data[Environment]["ConfigDB-jdbc"]
configJdbcUrl = dbutils.secrets.get(scope=kv_scope, key=con_secret)

# COMMAND ----------

# DBTITLE 1,Query control mapping
query=f"select * from dbo.[ADF_GNS_ControlMapping] where environment = '{Environment}'"
cols=['SnapshotDate','SchemaName','Environment','TableName','WatermarkColumn','FullLoad','LastLoadDate']
df=spark.read.format('jdbc').option('query',query).option('url',configJdbcUrl).load()\
            .withColumn('SnapshotDate',current_timestamp()).select(*cols)

# COMMAND ----------

# DBTITLE 1,Creating snapshot table
sz_table = dbutils.fs.head(config_path+'sz_tables.txt')
sz_table_config = json.loads(sz_table)
table_ls=[]
df_latest=df.withColumn('HDR_LastLoadDate',lit(''))
for k,v in sz_table_config.get('SZ').items():
    for i in v:
        try:
            lld=spark.sql(f"select max(HDR_LASTLOADDATE) from {k}.{i}").collect()[0][0]
            df_latest=df_latest.withColumn('HDR_LastLoadDate',when(df_latest['TableName']==i,lit(lld)).otherwise(col('HDR_LastLoadDate')))
        except:
            print(f"Unable to find max of hdr_lastloadlate for table {k}.{i}")
        table_ls.append(i)
df_filter=df_latest.filter(df_latest.TableName.isin(table_ls))
#df_filter.write.mode('append').jdbc(url=configJdbcUrl, table='[dbo].[SrcControlLog]')#Write to Config SQl table
df_filter.write.format('delta').mode('append').save(config_path+'adf_snapshot_lld')

# COMMAND ----------

# DBTITLE 1,Hive table creation
try:
    if len(spark.sql("show tables in adf_config like 'adf_snapshot_lld'").collect())==1:
        existance=1
    else:
        existance=0
except:
    existance=0
if existance==0:
    spark.sql("create database if not exists adf_config")
    spark.sql(f"create table if not exists adf_config.adf_snapshot_lld using delta location '{config_path+'adf_snapshot_lld'}'")


# COMMAND ----------

dbutils.notebook.exit('Execution of snapshot table completed')