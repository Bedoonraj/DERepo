# Databricks notebook source
import glob, pprint
from pyspark.sql.types import StringType
from pyspark.sql.functions import col, substring, sha2, concat, lit, date_trunc

# COMMAND ----------

# storage account setup
standardized_sa = 'sthdrstdzonedevtest'
published_sa = 'sthdrpublishedprojects'
project_org = 'dhw'
project_name = 'alpha'

# Azure SQL database setup
jdbcUrl = dbutils.secrets.get(scope="azurekvhdr-scope", key="jdbc-sqldb-hdr-datalandingzone-health-sqlprojects-devtest-alpha")

# get project salt
# salt generated using
#   import secrets
#   secrets.token_hex(32)
key = dbutils.secrets.get(scope="azurekvhdr-scope", key="cmk-hdr-dhw-alpha-projectkey-devtest-001")

# COMMAND ----------

# PII columns to remove
# for actual pipeline, consider moving to only SELECTing required instead of banning a list
drop = {
    'NSHEALTH_DHW_NAFP_DHW_Query_Monthly': [
        'HDR_PRIMARY_KEY',
        #'HealthCardNumber', # HASHED
        'CitizenOrDepID',
        'UniqueReportingPersonID',
        'citizenid',
        'CitizenRequestId',
        'FirstName',
        'MiddleName',
        'LastName',
        'OtherGenderValue',
        'PrimaryPhoneNumber',
        'PrimaryPhoneContactName',
        #'DateOfBirth', # LEVEL 2
        'Address',
        'PlacedDate',
        'CreatedBy'
        #'City', # Brad to curate sample data instead to allow this through
        #'PostalCode' # Truncated to first three chars
        
    ],
    'DAD_HOSPITAL_DATA_ICD10': [
        'HDR_PRIMARY_KEY',
        'CHART_NBR',
        'REGISTER_NBR',
        'CHART_OR_REGISTER_NBR_2',
        'MATERNAL_NEWBORN_CHART',
        'RECORD_NBR',
        #'HCN', # HASHED
        #'POSTAL_CODE', # Truncated to first three chars
        'RESIDENCE',
        #'BIRTH_DATE', # LEVEL 2
        'AGE_ON_REGISTRATION', # NEW
        #'GENDER',
        'ADMIT_DATE',
        'DATE_PATIENT_LEFT_ER',
        'DISCHARGE_DATE',
        'LEGAL_STATUS_ON_ED_ARRIVAL',
        'LEGAL_STATUS_AT_ADMISSION' 
    ],
    'DAD_INTERVENTION_ICD10': [
        'HDR_PRIMARY_KEY',
        'ANAESTHETIST',
        'DOCTOR'
    ],
    'DAD_DIAGNOSIS_ICD10': [
        'HDR_PRIMARY_KEY'
    ]
}

clean_birth_dates = {
    'NSHEALTH_DHW_NAFP_DHW_Query_Monthly': [
        'DateOfBirth'
    ],
    'DAD_HOSPITAL_DATA_ICD10': [
        'BIRTH_DATE'
    ]
}

# # REMOVED as per HDR-668
# clean_pcode = {
#     'NSHEALTH_DHW_NAFP_DHW_Query_Monthly': [
#         'PostalCode'
#     ],
#     'DAD_HOSPITAL_DATA_ICD10': [
#         'POSTAL_CODE'
#     ]
# }

hash_columns = {
    'NSHEALTH_DHW_NAFP_DHW_Query_Monthly': [
        'HealthCardNumber',
        'dq_cleaned_HealthCardNumber'
    ],
    'DAD_HOSPITAL_DATA_ICD10': [
        'HCN',
        'dq_cleaned_HCN'
    ]
}

# COMMAND ----------

def column_check(df, column_list):
    '''
    Input: 
        - df: Spark dataframe
        - column_list: List of column names to be checked
    Output: 
        - True if all columns in column_list exist in df
    '''
    missing = set(column_list).difference(set(df.columns))
    assert len(missing) == 0, f"Columns not found: {missing}"
    
    return True
    

# COMMAND ----------

def drop_columns(df, column_list):
    '''
    Input: 
        - df: Spark dataframe
        - column_list: List of the column names to be dropped
    Output: 
        - Spark dataframe with all columns in column_list dropped
    '''
    print(f"...dropping columns: {column_list}")
    
    # drop does not warn if a column is not present in the df
    if column_check(df, column_list):
        df = df.drop(*column_list)

    return df

# COMMAND ----------

def pcode_to_fsa(df, column_list):
    '''
    Input: 
        - df: Spark dataframe
        - column_list: Name of the column containing the postal code
    Output: 
        - Spark dataframe with the postal code truncated to first three chars
          aka the Forward Sortation Area
    '''
    print(f"...cleaning podes: {column_list}")
    
    if column_check(df, column_list):
        for col_name in column_list:
            df = df.withColumn(col_name, substring(col(col_name), 1, 3))
    return df


# COMMAND ----------

def birth_date_to_year(df, column_list):
    '''
    Input: 
        - df: Spark dataframe
        - column_list: Name of the column containing the birth date
    Output: 
        - Spark dataframe with the birth date converted to birth year
    '''
    print(f"...cleaning birth dates: {column_list}")
    if column_check(df, column_list):
        for col_name in column_list:
            df = df.withColumn(col_name, date_trunc('year', col(col_name)))
    return df

# COMMAND ----------

def sha2_hash_column(df, column_list, salt, bit_length):
    '''
    Input: 
        - df: Spark dataframe
        - column_list: Name of the column to be hashed
        - salt: salt value to be used for the column
        - bit_length: bit length of digest to be returned
    Output: 
        - Spark dataframe with all columns in column list salted and hashed
    '''
    print(f"...hashing columns: {column_list}")
    
    if column_check(df, column_list):
        for col_name in column_list:
            df = df.withColumn(col_name, sha2(concat(lit(salt), col(col_name)), bit_length))
        
    return df


# COMMAND ----------

# copy from standardized to alpha demo storage account folder and database

for path in glob.glob(f"/dbfs/mnt/{standardized_sa}/{project_org}/*/*/*", recursive=True): # /dbfs required for local code   

     if "/dad/" in path or "/nafp/" in path: # only nafp and dad

        org, sys, schema, table = [path.split("/")[i] for i in (4, 5, 6, 7)]
        table = table[:-6]
        source_path = path[5:] # strip /dbfs for use in spark
        sink_path = f"/mnt/{published_sa}/{project_org}/{project_name}/{'/'.join(path.split('/')[4:]).replace('.delta', '.parquet')}"
        
        print(f"Processing {source_path}")

        # read delta table from standardized zone
        df = spark.read.format("delta").load(source_path)

        # run the cleaning functions
        if table in drop:
            df = drop_columns(df, drop[table])
        
        # # removed as per HDR-668
        # if table in clean_pcode:
        #     df = pcode_to_fsa(df, clean_pcode[table])
        
        if table in clean_birth_dates:
            df = birth_date_to_year(df, clean_birth_dates[table])

        if table in hash_columns:
            df = sha2_hash_column(df, hash_columns[table], key, 256)


        # write to .parquet in alpha sa
        try:
            print(f"...writing to {sink_path}", end = "... ")
            df.write \
                .format("parquet") \
                .mode("overwrite") \
                .save(sink_path)
            print(f"Complete. Row count: {df.count()}.")   
            
        except Exception as e:
            print(f"Error writing to parquet.")
            raise Exception(e)
            
        
        print(f"...writing to alpha database table [{org}_{sys}_{schema}].[{table}]", end = "... ")
        
        # write to SQL table in alpha db
        try:
            df.write \
                .format("jdbc") \
                .mode("overwrite") \
                .option("url", jdbcUrl) \
                .option("dbtable", f"{org}_{sys}_{schema}.{table}") \
                .save()
            print(f"Complete. Row count: {df.count()}.")
            
        except Exception as e:
            print(f"Error writing to database.")
            raise Exception(e)
            
        print(f"Done processing {source_path}", end = "\n\n")

    