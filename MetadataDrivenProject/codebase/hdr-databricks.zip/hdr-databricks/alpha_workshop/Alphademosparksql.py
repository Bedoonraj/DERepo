# Databricks notebook source
#Data is mounted using a application secret scope stored in azure keyvault
delta_table_path='/mnt/sthdrstdzonedevtest/dhw/hap/nafp/NSHEALTH_DHW_NAFP_DHW_Query_Monthly.delta'
nafp_df = spark.read.format("delta").load(delta_table_path)


# COMMAND ----------

# PHI columns to remove from NAFP table
nafp_pii = [
        'PRIMARY_KEY',
        'HealthCardNumber', 
        'CitizenOrDepID',
        'UniqueReportingPersonID',
        'citizenid',
        'CitizenRequestId',
        'FirstName',
        'MiddleName',
        'LastName',
        'OtherGenderValue',
        'PrimaryPhoneNumber',
        'PrimaryPhoneContactName',
        'DateOfBirth',
        'Address',
        'PlacedDate'
]

# COMMAND ----------

nafp_df=nafp_df.drop(*nafp_pii)

# COMMAND ----------

from pyspark.sql.functions import substring
nafp_df=nafp_df.withColumn("PostalCode",substring("PostalCode", 1, 3))

# COMMAND ----------

display(nafp_df.limit(3))

# COMMAND ----------

display(nafp_df.sort("Gender"))

# COMMAND ----------

rows = nafp_df.count()
print(f"DataFrame Columns count : {rows}")

# COMMAND ----------

display(nafp_df.limit(3))

# COMMAND ----------

# comment