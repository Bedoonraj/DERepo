# Databricks notebook source
# MAGIC %run "../utils/libraries"

# COMMAND ----------

from utils.config import DEV_FLAG

# COMMAND ----------

# MAGIC %run "../sz_to_pz/pseudonymization"

# COMMAND ----------

# read in parameters
# dbutils.widgets.removeAll()
dbutils.widgets.text("p_src_folder", "")
dbutils.widgets.text("p_src_file", "")
dbutils.widgets.text("p_sink_folder", "")
dbutils.widgets.text("p_sink_file", "")
dbutils.widgets.text("p_sz_st_name", "")
dbutils.widgets.text("p_psz_st_name", "")

src_folder = dbutils.widgets.get("p_src_folder")
src_file = dbutils.widgets.get("p_src_file")
sink_folder = dbutils.widgets.get("p_sink_folder")
sink_file = dbutils.widgets.get("p_sink_file")
sz_st_name = dbutils.widgets.get("p_sz_st_name")
psz_st_name = dbutils.widgets.get("p_psz_st_name")

# ensure parameters aren't empty
assert len(src_folder) > 0, "p_src_folder is required"
assert len(src_file) > 0, "p_src_file is required" 
assert len(sink_folder) > 0, "p_sink_folder is required"
assert len(sink_file) > 0, "p_sink_file is required" 
assert len(sz_st_name) > 0, "p_sz_st_name is required"
assert len(psz_st_name) > 0, "p_psz_st_name is required"

# get variables from file path
container, org,  schema = src_folder.split("/")
table = src_file.removesuffix(".delta")

# build mounted folder paths
sz_folder       = f"/mnt/{sz_st_name}/{src_folder}"
sz_filepath     = f"{sz_folder}/{src_file}"
sz_url          = f"https://{sz_st_name}.dfs.core.windows.net/{src_folder}/{src_file}"
sz_qualiname    = f"{sz_url}/{{SparkPartitions}}"

psz_folder      = f"/mnt/{psz_st_name}/{sink_folder}"
psz_container   = sink_folder.split("/")[0]
psz_filepath    = f"{psz_folder}/{sink_file}"
psz_checkpoint_folder = f"{psz_folder}/{sink_file}/_checkpoints"
psz_url         = f"https://{psz_st_name}.dfs.core.windows.net/{sink_folder}/{sink_file}"

# other notebook variables
primary_key = "HDR_PRIMARY_KEY"
PROJECT = 'hdr-pseudostandardized'

# hdr project key
if DEV_FLAG:
    kv_scope = "azurekvhdr-scope"
else:
    kv_scope = "scope-kv-hdr-app-prd-001"

try:
    key = dbutils.secrets.get(scope=kv_scope, key="projectkey-hdr-pseudostandardized")
except Exception as error:
    print(error)
    raise error


# ## for creating the view - changed to manual scripts in synapse
# # Synapse View variables
# view_schema = f"{org}_{sys}_{schema}"
# view_name = f"{table}"

# # Using sp-hdr-dbworchestrator-devtest
# # Needs Synapse RBAC role "Synapse SQL Administrator" on the Synapse Workspace
# driver = "{ODBC Driver 18 for SQL Server}"
# server = "synws-hdr-datalandingzone-health-synapse-devtest-ondemand.sql.azuresynapse.net"
# database = "pseudostandardized"


# managed_id_client_id = dbutils.secrets.get(scope="azurekvhdr-scope", key="id-dbworchestrator-clientid")
# managed_id_client_secret = dbutils.secrets.get(scope="azurekvhdr-scope", key="id-dbworchestrator-clientsecret")
# azure_tenant_id = dbutils.secrets.get(scope="azurekvhdr-scope", key="tenantid")
# user = f'{managed_id_client_id}@{azure_tenant_id}'

# conn_str = f"DRIVER={driver};SERVER={server};DATABASE={database};UID={user};PWD={managed_id_client_secret};Authentication=ActiveDirectoryServicePrincipal"


# COMMAND ----------

# print out variables to simplify troubleshooting from Synapse
print(f'''
  -- input params --
  {src_folder=}
  {src_file=}
  {sink_folder=}
  {sz_st_name=}
  {psz_st_name=}

  -- parsed from input params --
  {container=}
  {org=}
  {schema=}
  {table=}

  -- standardized path info --
  {sz_folder=}
  {sz_filepath=}
  {sz_url=}
  {sz_qualiname=}

  -- psudo path info --
  {psz_st_name=}
  {psz_container=}
  {psz_folder=}
  {psz_filepath=}
  {psz_checkpoint_folder=}
  {psz_url=}
  '''
)


# COMMAND ----------

def run_with_retry(notebook: str, timeout: int, args: dict = {}, max_retries: int = 3) -> None:
    '''Tries running a notebook and retries on failure.

    Args:
        notebook: the path to the databricks notebook.
        timeout: time in seconds to wait for timeout for the notebook running.
        args: arguments passed to the notebook.
        max_retries: number of retries before an exception is raised

    Returns:
        Nothing
    '''
    num_retries = 0
    while True:
        try:
            return dbutils.notebook.run(notebook, timeout, args)
        except Exception as e:
            if num_retries > max_retries:
                raise e
            else:
                print("Retrying error", e)
                num_retries += 1

# COMMAND ----------

# mounts pseudostandardized zone container if it is not mounted already
mount_point = f"/mnt/{psz_st_name}/{psz_container}"
if not any(mount.mountPoint == mount_point for mount in dbutils.fs.mounts()):
    args = {
        "orgname": psz_container,
        "accountname": psz_st_name,
        "systemname": None 
    }
    try:
        run_with_retry("../op_to_lz/configuration", 60, args, max_retries = 1)
    except Exception as e:
        error_handling(e, f"Error mounting std zone, {args=}", rz_in_folder=rz_in_folder, rz_in_filepath=rz_in_filepath)

# COMMAND ----------

# Python code to mount and access Azure Data Lake Storage Gen2 Account from Azure Databricks with Service Principal and OAuth
 
# Define the variables used for creating connection strings

#adlsContainerName=dbutils.widgets.get("orgname")
#adlsAccountName=dbutils.widgets.get("accountname")
#adlsSystemName=dbutils.widgets.get("systemname")
adlsContainerName='pseudocurated'
adlsAccountName='sthdrcurzonedevtest'
adlsSystemName=None

mountPoint = "/mnt/"+adlsAccountName+"/"+adlsContainerName
 
if DEV_FLAG:
    # Application (Client) ID
    applicationId = dbutils.secrets.get(scope="azurekvhdr-scope-02",key="st-gen2storage-accessclientid")
    
    # Application (Client) Secret Key
    authenticationKey = dbutils.secrets.get(scope="azurekvhdr-scope-02",key="st-gen2storage-accesskey")
    
    # Directory (Tenant) ID
    tenandId = dbutils.secrets.get(scope="azurekvhdr-scope-02",key="st-gen2storage-tenantid")
else:
    # Application (Client) ID
    applicationId = dbutils.secrets.get(scope="scope-kv-hdr-app-prd-001",key="sp-hdr-databricksws-prd-canc-001-clientid") 

    # Application (Client) Secret Key
    authenticationKey = dbutils.secrets.get(scope="scope-kv-hdr-app-prd-001",key="sp-hdr-databricksws-prd-canc-001-accesskey") 

    # Directory (Tenant) ID
    tenandId = dbutils.secrets.get(scope="scope-kv-hdr-app-prd-001",key="sp-hdr-databricksws-prd-canc-001-tenantid")
 
endpoint = "https://login.microsoftonline.com/" + tenandId + "/oauth2/token"
source = "abfss://" + adlsContainerName + "@" + adlsAccountName + ".dfs.core.windows.net/"
 
# Connecting using Service Principal secrets and OAuth
configs = {"fs.azure.account.auth.type": "OAuth",
           "fs.azure.account.oauth.provider.type": "org.apache.hadoop.fs.azurebfs.oauth2.ClientCredsTokenProvider",
           "fs.azure.account.oauth2.client.id": applicationId,
           "fs.azure.account.oauth2.client.secret": authenticationKey,
           "fs.azure.account.oauth2.client.endpoint": endpoint}
 

# COMMAND ----------

if not any(mount.mountPoint == mountPoint for mount in dbutils.fs.mounts()):
  dbutils.fs.mount(
    source = source,
    mount_point = mountPoint,
    extra_configs = configs)

# COMMAND ----------

dbutils.fs.ls("/mnt/")

# COMMAND ----------

dbutils.fs.rm("/mnt/sthdrcurzonedevtest")

# COMMAND ----------

display(dbutils.fs.mounts())

# COMMAND ----------

dbutils.fs.unmount('/mnt/sthdrcurzonedevtest/')

# COMMAND ----------

