# Databricks notebook source
# MAGIC %md
# MAGIC # Standardized to Pseudostandardized Pipeline
# MAGIC
# MAGIC ## Dependencies
# MAGIC ## ODBC Dependency Removed - only required if using the create_view functionality
# MAGIC This pipeline depends on [Microsofts ODBC Driver 18 for SQL Server](https://learn.microsoft.com/en-us/sql/connect/odbc/linux-mac/installing-the-microsoft-odbc-driver-for-sql-server?view=sql-server-ver16&tabs=ubuntu18-install%2Calpine17-install%2Cdebian8-install%2Credhat7-13-install%2Crhel7-offline). This should be installed as part of the [cluster-scoped init script](https://learn.microsoft.com/en-us/azure/databricks/clusters/init-scripts#--configure-a-cluster-scoped-init-script-using-the-ui).
# MAGIC ```
# MAGIC # creates a init script that you can point to from the cluster ui
# MAGIC
# MAGIC dbutils.fs.put("dbfs:/databricks/scripts/install_msodbc18.sh", """
# MAGIC #!/bin/bash
# MAGIC curl https://packages.microsoft.com/keys/microsoft.asc | apt-key add -
# MAGIC curl https://packages.microsoft.com/config/ubuntu/$(lsb_release -rs)/prod.list > /etc/apt/sources.list.d/mssql-release.list
# MAGIC sudo apt-get update
# MAGIC sudo ACCEPT_EULA=Y apt-get -q -y install msodbcsql18
# MAGIC """,True)
# MAGIC ```
# MAGIC
# MAGIC
# MAGIC ## Documentation
# MAGIC [Link to documentation](https://novascotia.sharepoint.com/:w:/r/sites/NSHealthDataRepository2/Shared%20Documents/General/HDR%20Team%20Working%20Files/Architecture/Detailed%20Design/Pseudostandardized%20Detailed%20Design/Pseudostandardized%20Detailed%20Design.docx?d=w07a7cbed94c044f5b0dfbec36c3562d5&csf=1&web=1&e=ys42ig)

# COMMAND ----------

# MAGIC %run "../utils/libraries"

# COMMAND ----------

from utils.config import DEV_FLAG

# COMMAND ----------

# MAGIC %run "../sz_to_pz/pseudonymization"

# COMMAND ----------

# MAGIC %md
# MAGIC ### Set Notebook Properties
# MAGIC `spark.databricks.delta.propteries.defaults.enableChangeDataFeed = true` enables the change data feed on all newly created delta tables.
# MAGIC `spark.databricks.delta.properties.defaults.logRetentionDuration = interval 730 days` sets the retention length to 2 years for history on delta tables.

# COMMAND ----------

# MAGIC %sql
# MAGIC set spark.databricks.delta.properties.defaults.enableChangeDataFeed = true;
# MAGIC set spark.databricks.delta.properties.defaults.logRetentionDuration = interval 730 days;

# COMMAND ----------

# MAGIC %md
# MAGIC ### Read Notebook Parameters and Build FilePaths
# MAGIC Using parameters that will be send from the Synapse pipeline, build the required file paths for Databricks.

# COMMAND ----------

# read in parameters
# dbutils.widgets.removeAll()
dbutils.widgets.text("p_src_folder", "")
dbutils.widgets.text("p_src_file", "")
dbutils.widgets.text("p_sink_folder", "")
dbutils.widgets.text("p_sink_file", "")
dbutils.widgets.text("p_sz_st_name", "")
dbutils.widgets.text("p_psz_st_name", "")

src_folder = dbutils.widgets.get("p_src_folder")
src_file = dbutils.widgets.get("p_src_file")
sink_folder = dbutils.widgets.get("p_sink_folder")
sink_file = dbutils.widgets.get("p_sink_file")
sz_st_name = dbutils.widgets.get("p_sz_st_name")
psz_st_name = dbutils.widgets.get("p_psz_st_name")

# ensure parameters aren't empty
assert len(src_folder) > 0, "p_src_folder is required"
assert len(src_file) > 0, "p_src_file is required" 
assert len(sink_folder) > 0, "p_sink_folder is required"
assert len(sink_file) > 0, "p_sink_file is required" 
assert len(sz_st_name) > 0, "p_sz_st_name is required"
assert len(psz_st_name) > 0, "p_psz_st_name is required"

# get variables from file path
container, org, sys, schema = src_folder.split("/")
table = src_file.removesuffix(".delta")

# build mounted folder paths
sz_folder       = f"/mnt/{sz_st_name}/{src_folder}"
sz_filepath     = f"{sz_folder}/{src_file}"
sz_url          = f"https://{sz_st_name}.dfs.core.windows.net/{src_folder}/{src_file}"
sz_qualiname    = f"{sz_url}/{{SparkPartitions}}"

psz_folder      = f"/mnt/{psz_st_name}/{sink_folder}"
psz_container   = sink_folder.split("/")[0]
psz_filepath    = f"{psz_folder}/{sink_file}"
psz_checkpoint_folder = f"{psz_folder}/{sink_file}/_checkpoints"
psz_url         = f"https://{psz_st_name}.dfs.core.windows.net/{sink_folder}/{sink_file}"

# other notebook variables
primary_key = "HDR_PRIMARY_KEY"
PROJECT = 'hdr-pseudostandardized'

# hdr project key
if DEV_FLAG:
    kv_scope = "azurekvhdr-scope"
else:
    kv_scope = "scope-kv-hdr-app-prd-001"

try:
    key = dbutils.secrets.get(scope=kv_scope, key="projectkey-hdr-pseudostandardized")
except Exception as error:
    print(error)
    raise error


# ## for creating the view - changed to manual scripts in synapse
# # Synapse View variables
# view_schema = f"{org}_{sys}_{schema}"
# view_name = f"{table}"

# # Using sp-hdr-dbworchestrator-devtest
# # Needs Synapse RBAC role "Synapse SQL Administrator" on the Synapse Workspace
# driver = "{ODBC Driver 18 for SQL Server}"
# server = "synws-hdr-datalandingzone-health-synapse-devtest-ondemand.sql.azuresynapse.net"
# database = "pseudostandardized"


# managed_id_client_id = dbutils.secrets.get(scope="azurekvhdr-scope", key="id-dbworchestrator-clientid")
# managed_id_client_secret = dbutils.secrets.get(scope="azurekvhdr-scope", key="id-dbworchestrator-clientsecret")
# azure_tenant_id = dbutils.secrets.get(scope="azurekvhdr-scope", key="tenantid")
# user = f'{managed_id_client_id}@{azure_tenant_id}'

# conn_str = f"DRIVER={driver};SERVER={server};DATABASE={database};UID={user};PWD={managed_id_client_secret};Authentication=ActiveDirectoryServicePrincipal"


# COMMAND ----------

# print out variables to simplify troubleshooting from Synapse
print(f'''
  -- input params --
  {src_folder=}
  {src_file=}
  {sink_folder=}
  {sz_st_name=}
  {psz_st_name=}

  -- parsed from input params --
  {container=}
  {org=}
  {sys=}
  {schema=}
  {table=}

  -- standardized path info --
  {sz_folder=}
  {sz_filepath=}
  {sz_url=}
  {sz_qualiname=}

  -- psudo path info --
  {psz_st_name=}
  {psz_container=}
  {psz_folder=}
  {psz_filepath=}
  {psz_checkpoint_folder=}
  {psz_url=}
  '''
)


# COMMAND ----------

# mounts pseudostandardized zone container if it is not mounted already
mount_point = f"/mnt/{psz_st_name}/{psz_container}"
if not any(mount.mountPoint == mount_point for mount in dbutils.fs.mounts()):
    args = {
        "orgname": psz_container,
        "accountname": psz_st_name,
        "systemname": None 
    }
    run_with_retry("../op_to_lz/configuration", 60, args, max_retries = 1)

# COMMAND ----------

# def create_view(odbc_conn_str: str, view_schema: str, view_name: str, url: str) -> None:
#     ''' Creates a view of an external delta table in Synapse

#     Inputs:
#       - odbc_conn_str: ODBC formatted connection string. 
#       - view_schema: schema to be used when creating the view
#       - view_name: name to be used when creating the view
#       - url: url of the external delta table to be used as the base for the view

#     Outputs:
#       - None

#     More Info:
#       - Example odbc_conn_str:        
#         DRIVER={driver};SERVER={server};DATABASE={database};UID={user};PWD={password};Authentication=ActiveDirectoryServicePrincipal

#         where:
#           - driver is a SQL Server ODBC driver. ex/ "{ODBC Driver 17 for SQL Server}"
#           - server is the synapse server endpoint. ex/ "synws-hdr-datalandingzone-health-synapse-devtest-ondemand.sql.azuresynapse.net"
#           - database is the Database name.
#           - user is the client_id for a service principal in Azure AD 
#           - password is the secret for a service principal in Azure AD

#       - Links:
#         - https://learn.microsoft.com/en-us/azure/synapse-analytics/sql/create-use-views
#         - https://learn.microsoft.com/en-us/azure/synapse-analytics/sql/query-delta-lake-format
#         - https://learn.microsoft.com/en-us/azure/synapse-analytics/sql/resources-self-help-sql-on-demand?tabs=x80070002#delta-lake

#     '''

#     # create new schema if required
#     create_schema_query = f"""
#         IF NOT EXISTS (
#             SELECT *
#             FROM sys.schemas
#             WHERE name = ?
#         )
#         EXEC('CREATE SCHEMA [{view_schema}]');
#     """

#     create_view_query = f"""
#     CREATE OR ALTER VIEW [{view_schema}].[{view_name}] 
#     AS SELECT *
#     FROM OPENROWSET(BULK N'{url}', FORMAT = 'DELTA') AS rows
#     """

#     with pyodbc.connect(odbc_conn_str) as conn:
#         conn.autocommit = True

#         with conn.cursor() as c:
#             c.execute(create_schema_query, view_schema)
#             c.execute(create_view_query)


# COMMAND ----------

# MAGIC %md
# MAGIC ### Create the Pseudostandardized Table if it Doesn't Exist
# MAGIC This will also create the lineage in Purview. We can just exit after this.

# COMMAND ----------

# if the pseudostandardized delta table doesn't exist -> initial load, don't stream anything
# run the entire table through the process
try:
    delta_table_target = DeltaTable.forPath(spark, psz_filepath)

except AnalysisException as e:
    print(f"table {psz_filepath} doesn't exist, creating")
    
    # initial load
    df = spark.read.format("delta").load(sz_filepath) 

    pv = call_purview_api([sz_qualiname], PROJECT)

    try:
        pseudo_df = pseudonymization(PROJECT, df, pv, project_key = key)
        
    except PurviewNotPublishableException:
        # we don't want to fail the pipeline if the file isn't publishable
        #
        # Should move this to a Synapse Web Activity and if the table is not publishable, just end the pipeline and
        # don't call this notebook at all. Currently can't access the function from Synapse's IP 

        dbutils.notebook.exit("Table is not publishable.")
    except Exception as e:
        # we do want to fail for any other Exception
        print(str(e))
        raise e
    
    pseudo_df.write.format("delta").mode("overwrite").save(psz_filepath)

    # create view in synapse - removed, replaced with synapse scripts
    #create_view(conn_str, view_schema, view_name, psz_url)

    dbutils.notebook.exit('Initial load complete')

except Exception as e:
    print(str(e))
    raise e

# COMMAND ----------

# MAGIC %md
# MAGIC ### Create a StreamReader to read the Change Data Feed of the Standardized Zone Table
# MAGIC `option("startingVersion", 1)` required or it will only read the latest change data. We use `1` because `0` will re-process all of the initial load data.

# COMMAND ----------

# if there is not a new version, nothing new to load
if spark.sql(f'DESCRIBE HISTORY delta.`{sz_filepath}` LIMIT 1').first()['version'] == 0:
    dbutils.notebook.exit("Table still at version 0, nothing to load.")

# stream changes from std _change_data folder
df_streaming = spark.readStream \
    .format("delta") \
    .option("readChangeFeed", "true") \
    .option("startingVersion", 1) \
    .load(sz_filepath)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Define Functions that Identify the Most Recent Change Data and Merge to Pseudostandardized
# MAGIC
# MAGIC The `upsert_to_delta` function will be called for each batch in the stream. 

# COMMAND ----------

def get_most_recent_update(df: DataFrame, pk: str) -> DataFrame:
    ''' Gets the most recent change for each primary key from a change data feed
        dataframe.
    
    Inputs:
      - df: a change data feed dataframe
      - pk: the primary key for the dataframe

    Outputs:
      - A dataframe that contains the most recent change event for each primary key.
    '''

    # window must be defined to use a window function
    w = Window.partitionBy(pk).orderBy(col("_commit_version").desc())

    return df \
      .filter(col("_change_type") != 'update_preimage') \
      .withColumn("row", row_number().over(w)) \
      .filter(col("row") == 1) \
      .drop("row")
      

def upsert_to_delta(batch_df: DataFrame, batch_id: int, deltaTableTarget: DeltaTable, pk:str) -> None:
    ''' Gets updates from the change data feed, runs them through the pseudonymization process, and merges them with 
        the pseudostandardized zone table

    Inputs:
      - batch_df: the dataframe passed in by the forEachBatch() method of the streamwriter (required as part of using forEachBatch)
      - batch_id: the batch id passed in by the forEachBatch() method of the streamwriter (required as part of using forEachBatch)
      - deltaTableTarget: the delta table that will be the target for the merge operation
      - pk: the name of the column that will be used as the primary key for the merge operation. Must be the same name in the source and target table.

    Outputs:
      - None

    '''
    updates = get_most_recent_update(batch_df, pk)
    
    pv = call_purview_api([sz_qualiname], PROJECT)
    
    # all HDR_PRIMARY_KEY columns will be hashed as part of the pseudonymization process
    pseudo_df = pseudonymization(PROJECT, updates, pv, project_key = key)
    
    # write to target delta table
    deltaTableTarget.alias("t").merge(
            source = pseudo_df.alias("s"),
            condition = f"t.{pk} = s.{pk}"
        ).whenMatchedDelete("s._change_type = 'delete'") \
        .whenMatchedUpdateAll() \
        .whenNotMatchedInsertAll() \
        .execute()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Write the Changed Data
# MAGIC `.foreachBatch(lambda df, epochId: upsert_to_delta(df, epochId, DeltaTable.forPath(spark, psz_filepath), primary_key))` calls the function upsert_to_delta for each batch processed in the stream.
# MAGIC
# MAGIC `.option("checkpointLocation", psz_checkpoint_folder)` stores the state of the stream between batches in the psz_checkpoint_folder `{Delta Table Folder}/_checkpoints`. It is safe to keep this folder inside the delta table folder as long as it is prefixed with an underscore `_`. The `VACUUM` command ignores all folders with a `_` prefix.
# MAGIC
# MAGIC `.trigger(availableNow=True)` triggers once and processes all data that has been added or modified since the last stream batch. Without this the stream would run continunously, checking for new data at a regular interval.

# COMMAND ----------

df_streaming \
    .writeStream \
    .format("delta") \
    .foreachBatch(lambda df, epochId: upsert_to_delta(df, epochId, DeltaTable.forPath(spark, psz_filepath), primary_key)) \
    .option("checkpointLocation", psz_checkpoint_folder) \
    .trigger(availableNow=True) \
    .outputMode("update") \
    .start() \
    .awaitTermination()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Recreate the view that is based on this table in Synapse Serverless SQL Pool
# MAGIC For R1 decided to create external tables in Synapse using manual scripts.

# COMMAND ----------

# removed - views will be created using a manual script in synapse
# create_view(conn_str, view_schema, view_name, psz_url)