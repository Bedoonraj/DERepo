# Databricks notebook source
# DBTITLE 1,Libraries are imported
import json
from pyspark.sql.functions import regexp_replace
import re
from datetime import datetime
start_date=datetime.now()

# COMMAND ----------

# DBTITLE 1,Input Widgets are declared
dbutils.widgets.text('SourceTableName','')
tablename=dbutils.widgets.get('SourceTableName')

dbutils.widgets.text('MasterRunId','')
pipeline_runid=dbutils.widgets.get('MasterRunId')

dbutils.widgets.text('KeyAttrName','')
KeyAttrName=dbutils.widgets.get('KeyAttrName')

dbutils.widgets.text('DestinationTableName','')
DestinationTableName=dbutils.widgets.get('DestinationTableName')

dbutils.widgets.text('DestinationPath','')
DestinationPath=dbutils.widgets.get('DestinationPath')

dbutils.widgets.text('TransformationType','')
TransformationType=dbutils.widgets.get('TransformationType')

dbutils.widgets.text('TransfScriptPath','')
TransfScriptPath=dbutils.widgets.get('TransfScriptPath')

dbutils.widgets.text('Environment','')
Environment=dbutils.widgets.get('Environment')


dbutils.widgets.text('NumofRetry','')
no_of_retry=dbutils.widgets.get('NumofRetry')



# COMMAND ----------

# DBTITLE 1,Utility functions are called
# MAGIC %run ../common_functions/UtilityFunctions

# COMMAND ----------

# DBTITLE 1,Environment and paths are defined
try:

     # set to False when ready for production

    if Environment=='DEV':
        
        script_path=f"{TransfScriptPath}{DestinationTableName}.txt"
        config_path="/dbfs/mnt/sthdrcurzonedevtest/ds_config/config.txt"
        output_path=f'{DestinationPath}{DestinationTableName}'
        #env="dev"
    else:
        script_path=f"{TransfScriptPath}{DestinationTableName}.txt"
        config_path="/dbfs/mnt/sthdrcurzoneprd/ds_config/config.txt"
        output_path=f'{DestinationPath}{DestinationTableName}'
        #env="prod"

except Exception as e:
    #dataset_log(start_date,pipeline_runid,status='Failed',Error_message=str(e),end_date=datetime.now())
    error_handling("unable to get the inputs",str(e))


# COMMAND ----------

try:
    result = read_config(config_path)
    env_config_data = json.loads(result)
    kv_scope=env_config_data[Environment]["kvscope"]
    con_secret=env_config_data[Environment]["SecretName"]
    KeyAttrName=KeyAttrName.strip('][').split(',')
    #print(con_secret)
except Exception as e:
    #dataset_log(start_date,pipeline_runid,status='Failed',Error_message=str(e),end_date=datetime.now())
    error_handling("unable to get the inputs",str(e))

# COMMAND ----------

# DBTITLE 1,Below code is for profisee to mzout
try:


    df = ReadfromSQL(kv_scope, con_secret, tablename,DestinationTableName)
    df = df_format_columns(df)
    df.createOrReplaceTempView(tablename.replace("data.", ""))
    try:
        with open(script_path, "r") as trans_script:
            words = trans_script.read()

        df_1 = spark.sql(words)
    except Exception as e:
        #dataset_log(start_date,pipeline_runid,status="Failed", Error_message=str(e),end_date=datetime.now(),)
        error_handling("Unable to process script file", str(e))
    try:
        Write_SCD_Delta(
            df_1, output_path, KeyAttrName, pipeline_runid,start_date, TransformationType, False
        )

        try:
            Db = DestinationTableName.split("_")[0]
            try:
                table_existance=spark.sql(f"show tables in {Db} like '{DestinationTableName.lower()}'").count()
            except:
                table_existance=0
            if table_existance==0:
                spark.sql(f"create database if not exists {Db}")
                spark.sql(f"create table if not exists {Db}.{DestinationTableName.lower()} using delta location '{output_path}'")
                spark.sql(f"alter table {Db}.{DestinationTableName.lower()} SET TBLPROPERTIES (delta.enableChangeDataFeed=true)")
                spark.sql(f"ALTER TABLE delta.`{output_path}` SET TBLPROPERTIES(delta.logRetentionDuration = 'interval 730 days')")
                spark.sql(f"ALTER TABLE {Db}.{DestinationTableName} ALTER COLUMN {KeyAttrName[0]} SET NOT NULL")
            else:
                spark.sql(f"OPTIMIZE delta.`{output_path}` ZORDER BY (_modified_date)")

        except Exception as e:
            #dataset_log(start_date,pipeline_runid,status="Failed",Error_message=str(e),end_date=datetime.now(), )
            error_handling("Unable to create target table", str(e))

    except Exception as e:
        #dataset_log(start_date,pipeline_runid,status="Failed",Error_message=str(e),end_date=datetime.now(),)
        error_handling("Unable to write as Type1", str(e))


except Exception as e:
    #dataset_log(start_date,pipeline_runid,status="Failed",Error_message=str(e),end_date=datetime.now(),)
    error_handling("profisee_to_mzout loop failed", str(e))

# COMMAND ----------

#dataset_log(start_date,pipeline_runid,status='Success',Error_message='No Error',end_date=datetime.now())

# COMMAND ----------

# DBTITLE 1,Updating dataset log
max_date=spark.sql(f"select max(_modified_date) from mzout.{DestinationTableName}").collect()[0][0]
if max_date==None:
    dbutils.notebook.exit(f"Output table {DestinationTableName} don't have any records")
else:
    query=f"update adf_config.adf_datasetlog set LastLoadDateTime='{max_date}' where DatasetName='{DestinationTableName}'"
    retry=int(no_of_retry)
    while retry>0:
        try:
            spark.sql(query)
            retry=0
        except:
            retry=retry-1
            if retry==0:
                spark.sql(query)
    dbutils.notebook.exit(f"Execution completed and lastloaddate for table {DestinationTableName} updated to {max_date}")