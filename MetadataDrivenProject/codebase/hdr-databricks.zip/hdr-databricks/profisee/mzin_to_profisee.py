# Databricks notebook source
# DBTITLE 1,Importing libraries
import json
import datetime
from pyspark.sql.functions import current_timestamp

# COMMAND ----------

# DBTITLE 1,Importing widgets

dbutils.widgets.text('DestinationTableName','')
DestinationTableName=dbutils.widgets.get('DestinationTableName')

dbutils.widgets.text('TransfScriptPath','')
TransfScriptPath=dbutils.widgets.get('TransfScriptPath')

dbutils.widgets.text('Environment','')
DEV_FLAG=dbutils.widgets.get('Environment')

dbutils.widgets.text('NumofRetry','')
no_of_retry=dbutils.widgets.get('NumofRetry')


script_path=TransfScriptPath+DestinationTableName.lower().replace('[stg].','')+".txt"
table_name=DestinationTableName.split('.')[1]



if DEV_FLAG=='DEV':
    env="DEV"
    config_path="/dbfs/mnt/sthdrcurzonedevtest/ds_config/config.txt"
else:
    env='PROD'
    config_path="/dbfs/mnt/sthdrcurzoneprd/ds_config/config.txt"

# COMMAND ----------

# DBTITLE 1,Executing utility functions
# MAGIC %run ../common_functions/UtilityFunctions

# COMMAND ----------

# DBTITLE 1,Transformation script execution
try:
    with open(script_path, "r") as trans_script:
        words = trans_script.read()
    df=spark.sql(words)
    max_date = datetime.datetime.now()
except Exception as e:
    error_handling("Unable to process script file", str(e))


# COMMAND ----------

# DBTITLE 1,Write into Profisee
try:
    with open(config_path, 'r') as s:
        data = json.load(s)
    result=json.dumps(data)
    env_config_data = json.loads(result)
    kv_scope=env_config_data[env]["kvscope"]
    con_secret=env_config_data[env]["SecretName"]
    configJdbcUrl = dbutils.secrets.get(scope=kv_scope, key=con_secret)
    df.write.mode('overwrite').option('truncate',True).jdbc(url=configJdbcUrl, table=f'stg.{table_name}')
except Exception as e:
    error_handling("Unable to write into Profisee DB", str(e))

# COMMAND ----------

# DBTITLE 1,Updating dataset log
query=f"update adf_config.adf_datasetlog set LastLoadDateTime=getdate() where DatasetName='{DestinationTableName}'"
retry=int(no_of_retry)
while retry>0:
    try:
        spark.sql(query)
        retry=0
    except:
        retry=retry-1
        if retry==0:
            spark.sql(query)

# COMMAND ----------

dbutils.notebook.exit('Profisee stage table loading is completed')

# COMMAND ----------

