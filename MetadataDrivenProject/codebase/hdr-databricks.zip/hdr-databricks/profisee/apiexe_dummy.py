# Databricks notebook source
dbutils.notebook.exit("Execution of Profisee Job completed")

# COMMAND ----------

