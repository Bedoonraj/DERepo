# Databricks notebook source
import pyspark.pandas as ps
import pandas as pd
import re
import os
import uuid
import json
import requests
import pyodbc
from titlecase import titlecase

# later we should use "import pyspark.sql.functions as F" to clean this up
from pyspark.sql import DataFrame
from pyspark.sql.functions import col, upper, regexp_replace, regexp_extract, udf, when, lit, trim, sha2, concat, substring, date_format, to_date, year, to_timestamp, row_number
from pyspark.sql.types import BooleanType, StringType, TimestampType, StructType, StructField, Row
from pyspark.sql.utils import AnalysisException
from pyspark.sql.window import Window
from datetime import datetime
# enable arrow-based columnar data transfers for conversions
spark.conf.set("spark.sql.execution.arrow.enabled", "true")

from delta.tables import DeltaTable

import sqlparse
from sql_metadata import Parser