# Databricks notebook source
# MAGIC %run "../utils/libraries"

# COMMAND ----------

# MAGIC %run "../sz_to_pz/masking_engine"

# COMMAND ----------

from utils.config import DEV_FLAG

# COMMAND ----------

class PurviewNotPublishableException(Exception):
    ''' Exception that allows handling of the publishable flag not being set to true'''
    pass

# COMMAND ----------

def error_handling(error, debug=None) -> None:
    error = str(error)
    
    if debug:
        print(debug)
        error += f"\nNote: {debug}"
    
    raise Exception(error)

# COMMAND ----------

def call_purview_api(qualified_names: list, project: str) -> list:
    '''
    Purpose: Call the Purview function app API and retrieve the response list of JSON objects
    
    Input:
        - qualified_names: list of qualified names to be used for the Purview API 
        - project: the project name to get the correct access levels
    '''
    if DEV_FLAG:
        kv_scope = "azurekvhdr-scope"
        url = "https://func-hdr-datamanagement-purviewapi-devtest-001.azurewebsites.net/api/StandardizedTableInfoList"
    else:
        kv_scope = "scope-kv-hdr-app-prd-001"
        url = "https://func-hdr-datamanagement-purviewapi-prd-canc-001.azurewebsites.net/api/StandardizedTableInfoList"
    
    try:
        functions_key = dbutils.secrets.get(scope=kv_scope, key="func-purviewapi-standardizedtableinfolist-key")
    except Exception as error:
        debug = "The Key Vault Purview API function key cannot be read"
        error_handling(error, debug)
    
    headers = {
        "x-functions-key": functions_key,
        "Content-Type": "application/json"
    }

    payload_dict = {
        "project": project,
        "qualifiedNames": qualified_names
    }
    
    payload = json.dumps(payload_dict)

    response = requests.post(url, headers=headers, data=payload)
   
    if response.ok:
        return json.loads(response.text)
    
    error = f"There was an error in the Purview API: {response.text}"
    error_handling(error)

# COMMAND ----------

def is_publishable(purview: list) -> bool:
    '''
    Purpose: Validates a Purview response to see if the "publishable" flag is set to True

    Input:
      - purview: Purview list returned by the API
    
    Output:
      - Boolean indicating if this table can be published or not (True = Can be published)
    '''

    for table_dict in purview:
        if not table_dict.get("publishable", False):
            return False

    return True

# COMMAND ----------

def determine_maskable_columns(purview: list) -> dict:
    '''
    Input: 
        - purview: Purview list returned by the API
    Output: 
        - columns_dict: dict of all columns in `purview` that have classifications, i.e., need masking
        i.e. 
        {
            "<column_name_or_alias_1>": {"classification_name": "<classification_name_1>", "access_level": <access_level_1>, "masking_rule": "<masking_rule_1>"},
            ...
        }
        
        e.g.
        {
            "CitizenRequestId": {"classification_name": "Unique Identifier Number", "access_level": 1, "masking_rule": "1-Way Hash"}
        }
    '''
    columns_dict = {}
    
    for i in range(len(purview)):
        purview_dict = purview[i]
        
        for column_dict in purview_dict["columns"]:
            classifications = column_dict["classifications"]
            
            if classifications:
                classification_name = classifications[0].get("name")
                access_level_str = classifications[0].get("overrideAccessLevel")
                sensitivity_level = classifications[0].get("sensitivityLevel")
                
                if classification_name is None or access_level_str is None or sensitivity_level is None:
                    continue
    
                access_level = int(access_level_str[-1])
                masking_rule = classifications[0].get(f"accessLevel{access_level}")

                if "special permission" in sensitivity_level.lower():
                    masking_rule = "Special Permission"

                column_name = column_dict["name"]
                
                columns_dict[column_name] = {
                    "classification_name": classification_name,
                    "access_level": access_level,
                    "masking_rule": masking_rule if masking_rule else "1-Way Hash"
                }
                
    return columns_dict

def determine_exclusive_maskable_columns(columns_dict: dict, table_dict: dict) -> dict:
    '''
    Input:
        - columns_dict: output from determine_maskable_columns()
        - table_dict: dictionary that gives any corresponding column aliases used in the query

    Output: 
        - exclusive_dict: dict of column names and/or aliases that need to be masked based on `table_dict`
    '''
    exclusive_dict = {}

    column_names_dict = {}
    for key, value in table_dict.items():
        table_alias = value["table_alias"]
        for column_name, column_alias in value["columns"].items():
            # check if there's a duplicate column name/alias
            # raise exception if there is
            if column_name in column_names_dict and column_names_dict[column_name] == column_alias:
                error = "There are duplicate column names/aliases in the query"
                error_handling(error)
            column_names_dict[f"{table_alias}.{column_name}" if table_alias else column_name] = column_alias
    
    for column_name in column_names_dict:
        try:
            column_name_isolated = column_name.split(".")[1]
        except:
            column_name_isolated = column_name
        for col, value in columns_dict.items():
            if column_name_isolated == col:
                column_alias = column_names_dict[column_name]
                exclusive_dict[column_alias if column_alias else column_name_isolated] = value
                continue # next column
    
    return exclusive_dict

# COMMAND ----------

def create_masking_rules_dict(columns_dict: dict) -> dict:
    '''
    Input: 
        - columns_dict: dict of columns that need to be masked
    Output: 
        - masking_dict: reorganized dictionary with masking rules as the keys and list of columns as the values
        i.e. 
        {
            "<masking_rule_1>": ["column_name_1", ...],
            ...
        }
        
        e.g.
        {
            "1-Way Hash": ["MIDDLE_NAME", "FIRST_NAME"],
            "Year and Month": ["DATE_OF_BIRTH"]
        }
    '''
    masking_dict = {}

    for key, value in columns_dict.items():
        masking_rule = value["masking_rule"]
        if masking_rule in masking_dict:
            masking_dict[masking_rule].append(key)
        else: # create the list
            masking_dict[masking_rule] = [key]
    
    return masking_dict

# COMMAND ----------

def pseudonymization(project: str, df, purview: dict, masking_dict: dict=None, project_key: str=None):
    '''
    Input: 
        - project: the project name
        - df: constructed Spark dataframe from the project query
        - columns_dict: dict of columns that need to be masked
        - project_key: salt value to be used for the columns that need to be hashed
    Output: 
        - df: masked df
    '''
    if not DEV_FLAG:
        if not is_publishable(purview):
            raise PurviewNotPublishableException("At least one of the tables is not publishable")
    
    if not masking_dict:
        columns_dict = determine_maskable_columns(purview)
        masking_dict = create_masking_rules_dict(columns_dict)
    
    if not project_key:
        if DEV_FLAG:
            kv_scope = "azurekvhdr-scope"
        else:
            kv_scope = "scope-kv-hdr-project-prd-001"

        try:
            project_key = dbutils.secrets.get(scope=kv_scope, key=f"projectkey-{project}")
        except Exception as error:
            debug = "The Key Vault project key cannot be read"
            error_handling(error, debug)

    # do the heavy-lifting
    df = masking_engine(df, masking_dict, project_key)

    return df