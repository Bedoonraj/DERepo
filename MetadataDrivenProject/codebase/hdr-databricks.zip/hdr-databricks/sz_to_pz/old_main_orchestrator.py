# Databricks notebook source
#archived 2023-06-27 by Mark Ferris

# COMMAND ----------

# MAGIC %run "../utils/libraries"

# COMMAND ----------

from utils.config import DEV_FLAG

# COMMAND ----------

# MAGIC %run "../sz_to_pz/pseudonymization"

# COMMAND ----------

# read in parameters
dbutils.widgets.text("p_project", "") # matches `AbbreviatedName` in dbo.HDR_User_Project_Tracking (project config)
dbutils.widgets.text("p_query", "")
dbutils.widgets.text("p_destination_format", "")
# Possible string values for `destination_format`:
#         - Database
#         - Container
#         - Both
dbutils.widgets.text("p_destination_name", "")
dbutils.widgets.text("p_email", "")
dbutils.widgets.text("p_sz_st_name", "")
dbutils.widgets.text("p_pz_st_name", "")

project = dbutils.widgets.get("p_project")
query = dbutils.widgets.get("p_query")
destination_format = dbutils.widgets.get("p_destination_format")
destination_name = dbutils.widgets.get("p_destination_name")
email = dbutils.widgets.get("p_email")
sz_st_name = dbutils.widgets.get("p_sz_st_name")
pz_st_name = dbutils.widgets.get("p_pz_st_name")

# ensure parameters fit the bill. For internal debugging purposes
# none of these errors should ever occur
assert len(project) > 0, "p_project is required"
assert project.count('-') == 1, "Invalid project, should be of the format <org>-<project name>"
assert len(query) > 0, "p_query is required"
assert len(destination_format) > 0, "p_destination_format is required"
assert destination_format.lower() in ["database", "container", "both"], "Invalid destination_format, should be one of 'Database', 'Container', or 'Both'"
assert len(destination_name) > 0, "p_destination_name is required"
assert len(email) > 0, "p_email is required"
assert email.count('@') == 1, "Invalid email address"
assert len(sz_st_name) > 0, "p_sz_st_name is required"
assert sz_st_name.islower(), "p_sz_st_name must be lowercased"
assert len(pz_st_name) > 0, "p_pz_st_name is required"
assert pz_st_name.islower(), "p_pz_st_name must be lowercased"

# lowercase project name just in case
project = project.lower()

# build mountpoint to see if pz needs to be mounted
org_name, project_name = project.split('-')
pz_mountpoint = f"/mnt/{pz_st_name}/{org_name}"

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Mount containers if required

# COMMAND ----------

# mounts std zone container if it is not mounted already
if not any(mount.mountPoint == pz_mountpoint for mount in dbutils.fs.mounts()):
    args = {
        "orgname": org_name,
        "accountname": pz_st_name,
        "systemname": None 
    }
    run_with_retry("../op_to_lz/configuration", 60, args, max_retries = 1)

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Define useful functions

# COMMAND ----------

def validate_sql_query(query: str) -> sqlparse.sql.Statement:
    '''
    Input:
        - query: SQL-syntax query string (format must be like "dhw_hap_dad.DAD_AGE_GROUPINGS" for table names)
    Output:
        - parsed_query: validated SQL-syntax sqlparse query
    '''
    statements = sqlparse.parse(query)
    
    if len(statements) != 1:
        error = "The SQL query is invalid or has more than one statement"
        error_handling(error)
    
    parsed_query = statements[0]
    if not parsed_query.token_first().match(sqlparse.tokens.DML, "SELECT"):
        error = "The SQL query is not a valid SQL SELECT statement"
        error_handling(error)
    
    for token in parsed_query.tokens:
        if token.match(sqlparse.tokens.Wildcard, '*'):
            error = "The SQL query is not allowed to use the '*' wildcard symbol for selecting columns"
            error_handling(error)
    
    return parsed_query

# COMMAND ----------

def get_table_info(query: str) -> dict:
    '''
    Purpose: To be passed into the Purview function app API (specifically just the keys of this dict)
    
    Input:
        - query: validated SQL-syntax string query that can involve one or more tables
    Output:
        - table_dict: dictionary that gives the true table names and any corresponding aliases used in the query
        i.e. {
        "<table_name_1>": {
                        table_alias: "<table_alias_1>",
                        "columns": {
                            "<column_name_1>": "<column_alias_1>",
                            "<column_name_2>": "<column_alias_2>",
                            ...
                        }
              },
        "<table_name_2>": {
                        table_alias: "<table_alias_2>",
                        "columns": {
                            "<column_name_1>": "<column_alias_1>",
                            "<column_name_2>": "<column_alias_2>",
                            ...
                        }
              }
        }
        e.g. {'dhw_hap_dad.DAD_AGE_GROUPINGS': {'table_alias': 't1', 'columns': {}}, 
        'dhw_hap_dad.DAD_CCI_CHAPTERS': {'table_alias': 't2', 'columns': {'CHAPTER_ID': 'chapter_id'}}
        }
    '''
    
    # populate table_dict
    tables = Parser(query).tables

    parser_table_alias_dict = Parser(query).tables_aliases
    table_alias_dict = {v: k for k, v in parser_table_alias_dict.items()}

    columns = Parser(query).columns_dict['select']
    parser_col_alias_dict = Parser(query).columns_aliases
    col_alias_dict = {v: k for k, v in parser_col_alias_dict.items()}
    for col in columns:
        if col not in col_alias_dict:
            col_alias_dict[col] = None
    
    # initiate table_dict
    table_dict = {}
    for table in tables:
        table_alias = None

        if table in table_alias_dict:
            table_alias = table_alias_dict[table]
        
        table_dict[table] = {
            'table_alias': table_alias,
            'columns': {}
        }
    
    # populate the rest of table_dict
    for column_name, column_alias in col_alias_dict.items():
        split = column_name.rfind(".") # index of last '.' char

        if split != -1: # table names in front of column names; it's a join
            table_name, column_name = column_name[:split], column_name[split+1:]
            for table in table_dict:
                if table == table_name:
                    table_dict[table]["columns"][column_name] = column_alias 
        else: # only one table mentioned in the query
            table_dict[table]["columns"] = col_alias_dict
        
    return table_dict

# COMMAND ----------

def get_qualified_table_names(table_names: list) -> list:
    '''
    Purpose: To be passed into the Purview function app API
    
    Input:
        - table_names: list of true table names used in the query
    Output:
        - qualified_names: list of qualified names to be used for the Purview API 
    '''
    qualified_names = []
    
    for table in table_names:
        delta_folder_path, delta_file = table.split(".")
        
        delta_folder_path = delta_folder_path.replace("_", "/").lower()
        delta_file += ".delta"
        
        qualified_name = f"https://{sz_st_name}.dfs.core.windows.net/standardized/{delta_folder_path}/{delta_file}/{{SparkPartitions}}"
        
        if qualified_name.count('/') != 8:
            error = "Something is wrong with the table name schema or the name itself. Incorrect number of / characters"
            error_handling(error)
        
        qualified_names.append(qualified_name)
    
    return qualified_names

# COMMAND ----------

def get_destination_source(project: str) -> str: 
    '''
    Purpose: Get the database for the project

    Output: A string `database`
    '''
    # get JDBC connection string from key vault

    if DEV_FLAG:
        kv_scope = "azurekvhdr-scope"
        key_secret = "jdbc-sqldb-hdr-datalandingzone-health-connection-string"
    else:
        kv_scope = "scope-kv-hdr-app-prd-001"
        key_secret = "jdbc-sqldb-hdr-datazonehealth-config-connection-string-prd"
        
    try:
        jdbcUrl = dbutils.secrets.get(scope=kv_scope, key=key_secret)
    except Exception as error:
        debug = "The Key Vault connection string key cannot be read"
        error_handling(error, debug)

    # retrieve HDR_User_Project_Tracking (project config) table
    pc_df = spark.read.jdbc(url=jdbcUrl, table='dbo.HDR_User_Project_Tracking')

    # register the df as a SQL temporary view
    pc_df.createOrReplaceTempView("pc")

    # define SQL query to get information for the relevant project
    sql_query = f"""
    SELECT * FROM pc
    WHERE AbbreviatedName = '{project}'
    """

    # query against our `pc` temp view
    try:
        sql_df = spark.sql(sql_query)
    except Exception as error:
        debug = "dbo.HDR_User_Project_Tracking (PC) table inaccessible"
        error_handling(error, debug) # exit notebook here with logging

    # convert to pandas
    try:
        sql_pandas_df = sql_df.select("*").toPandas()
    except Exception as error:
        debug = "dbo.HDR_User_Project_Tracking (PC) table could not be converted to a pandas df"
        error_handling(error, debug) # exit notebook here with logging
    
    try:
        database = sql_df.first()['Database']
    except Exception as error:
        debug = "Something wrong with the Database column"
        error_handling(error, debug) # exit notebook here with logging
    
    return database

# COMMAND ----------

def write_to_published(df, project: str, destination_format: str, destination_name: str) -> None:
    '''
    Purpose: Write `df` to the project's SQL database or ADLS Gen2 storage or both

    Possible values for `destination_format`:
        - Database: is a key for `destination_dict`
        - Container: is a key for `destination_dict`
        - Both: is not a key for `destination_dict`, but it will be used later for the logic to use both Database and Container
    '''
    # define the intermediate functions
    def write_to_database() -> None:
        if not re.match(r'^[a-zA-Z_][a-zA-Z0-9_]*$', destination_name):
            raise AssertionError("Invalid character(s) in destination_name (table name)")

        # retrieve the necessary database name
        database = get_destination_source(project)

        assert database.count('/') == 1, "Invalid Database name, should be of the format <SQL server>/<SQL database>"

        # extract the server and database names
        sql_server, sql_database = database.split('/')

        sql_server_url = f"{sql_server}.database.windows.net:1433"

        # define the JDBC URL and table name to be used (default 'dbo' schema)
        jdbc_url = f"jdbc:sqlserver://{sql_server_url};database={sql_database};encrypt=true;trustServerCertificate=false;hostNameInCertificate=*.database.windows.net;loginTimeout=30;"
        table_name = f"dbo.{destination_name}"

        # get username and password needed to insert the data
        if DEV_FLAG:
            kv_scope = "azurekvhdr-scope"
            db_client_id = "id-dbworchestrator-clientid"
            db_client_secret = "id-dbworchestrator-clientsecret"
            db_tenant_id = "tenantid"
        else:
            kv_scope = "scope-kv-hdr-app-prd-001"
            db_client_id = "sp-hdr-databricksws-prd-canc-001-clientid"
            db_client_secret = "sp-hdr-databricksws-prd-canc-001-accesskey"
            db_tenant_id = "sp-hdr-databricksws-prd-canc-001-tenantid"

        try:
            # sp-hdr-dbworchestrator credentials
            client_id = dbutils.secrets.get(scope=kv_scope, key=db_client_id)
            client_secret = dbutils.secrets.get(scope=kv_scope, key=db_client_secret)
            tenant_id = dbutils.secrets.get(scope=kv_scope, key=db_tenant_id)
        except Exception as error:
            debug = "The Key Vault service principal cannot be read"
            error_handling(error, debug)

        # define the connection properties
        connection_properties = {
            "AADSecurePrincipalId": f"{client_id}@{tenant_id}",
            "AADSecurePrincipalSecret": client_secret,
            "driver": "com.microsoft.sqlserver.jdbc.SQLServerDriver",
            "authentication": "ActiveDirectoryServicePrincipal"
        }

        # write the table to the appropriate SQL db
        try:
            df.write.jdbc(url=jdbc_url, table=table_name, mode="overwrite", properties=connection_properties)
        except:
            debug = "Could not write a table to the SQL database"
            error_handling(error, debug)


    def write_to_container() -> None:
        if not re.match(r'^[A-Za-z0-9_\- ]+$', destination_name):
            raise AssertionError("Invalid character(s) in destination_name (filename)")

        _, ext = os.path.splitext(destination_name)
        if ext != '':
            raise AssertionError("destination_name should not have a file extension named")
    
        # build mounted folder paths
        pz_out_folder      = f"/dbfs/mnt/{pz_st_name}/{org_name}/{project_name}"
        pz_out_filepath    = f"{pz_out_folder}/{destination_name}.parquet"

        # write the file to the appropriate out folder
        if not os.path.exists(pz_out_folder):
            os.makedirs(pz_out_folder)

        try:
            df.write.format("parquet").mode("overwrite").save(pz_out_filepath[5:])
        except Exception as error:
            debug = "Could not write a Parquet file to the container"
            error_handling(error, debug)
            
            
    # standardize the format string just in case
    destination_format = destination_format.lower()

    if destination_format == "database":
        write_to_database()
    elif destination_format == "container":
        write_to_container()
    elif destination_format == "both":
        write_to_database()
        write_to_container()

# COMMAND ----------

# may as well try to retrieve the project key first
# if it can't, end it all

if DEV_FLAG:
    kv_scope = "azurekvhdr-scope"
else:
    kv_scope = "scope-kv-hdr-project-prd-001"

try:
    project_key = dbutils.secrets.get(scope=kv_scope, key=f"projectkey-{project}")
except Exception as error:
    debug = "The Key Vault project key cannot be read"
    error_handling(error, debug)

# COMMAND ----------

parsed_query = validate_sql_query(query)

# COMMAND ----------

table_dict = get_table_info(query)
table_names = list(table_dict.keys())

print(table_dict)
print("-------")
print(table_names)

# COMMAND ----------

# read in the constructed Spark df based off of `parsed_query`

parsed_query = str(parsed_query)

for table in table_names:
    delta_folder_path, delta_file = table.split(".")
    delta_folder_path = delta_folder_path.replace("_", "/").lower()
    delta_file += ".delta"
    
    delta_mount = f"/mnt/{sz_st_name}/standardized/{delta_folder_path}/{delta_file}"
    
    try: 
        temp_df = spark.read.format("delta").load(delta_mount)
    except Exception as error:
        debug = "Standardized zone Delta file cannot be read"
        error_handling(error, debug) # exit notebook here with logging
    
    temp_df.createOrReplaceTempView(f"`{table}`")
    
    parsed_query = re.sub(fr"\b{table}\b", f"`{table}`", parsed_query)

# COMMAND ----------

spark.catalog.listTables()

# COMMAND ----------

print(parsed_query)

# COMMAND ----------

# construct the df using the parsed query and the temporary dataframe views
df = spark.sql(parsed_query)

# COMMAND ----------

df.show()

# COMMAND ----------

qualified_names = get_qualified_table_names(table_names)
purview = call_purview_api(qualified_names, project)

# COMMAND ----------

print(purview)

# COMMAND ----------

columns_dict = determine_maskable_columns(purview)

print(columns_dict)

# COMMAND ----------

columns_dict = determine_exclusive_maskable_columns(columns_dict, table_dict)

print(columns_dict)

# COMMAND ----------

masking_dict = create_masking_rules_dict(columns_dict)

print(masking_dict)

# COMMAND ----------

df = pseudonymization(project, df, purview, masking_dict, project_key)

# COMMAND ----------

df.show()

# COMMAND ----------

# write it in project's DB or storage account now that we have `df` masked
write_to_published(df, project, destination_format, destination_name)