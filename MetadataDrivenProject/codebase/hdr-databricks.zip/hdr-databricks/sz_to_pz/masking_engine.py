# Databricks notebook source
def sha2_hash_column(df, column_list, salt, bit_length=512):
    '''
    Input: 
        - df: Spark dataframe
        - column_list: list of columns to be hashed
        - salt: salt value to be used for the column
        - bit_length: bit length of digest to be returned
    Output: 
        - df: Spark dataframe with all columns in `column_list` salted and hashed
    '''
    for col_name in column_list:
        # try:
        df = df.withColumn(col_name, sha2(concat(lit(salt), col(col_name)), bit_length))
        # except:
        #     pass
        
    return df

# COMMAND ----------

def extract_postal_code_fsa(df, column_list):
    '''
    Input:
        - df: Spark dataframe
        - column_list: list of postal code columns to keep only their FSA components (they have "dqc_" prefixed)
    Output:
        - df: Spark dataframe with all columns in `column_list` FSA-extracted
    '''
    for col_name in column_list:
        if not col_name.startswith("dqc_"):
            continue
            
        # try:
        df = df.withColumn(col_name, substring(col(col_name), 1, 3))
        # except:
        #     pass
    
    return df

# COMMAND ----------

def range_of_year(df, column_list):
    '''
    Input:
        - df: Spark dataframe
        - column_list: list of date columns to keep only the range of the years
    Output:
        - df: Spark dataframe with all columns in `column_list` transformed to a string type as the range of years
    
    e.g. A date of 1996-06-15 gets converted to "1990 - 1999"
    '''
    for col_name in column_list:
        # try:
        df = df.withColumn('range_of_years_temp',
                            concat(
                                year(col(col_name)) - year(col(col_name)) % 10,
                                lit(' - '),
                                year(col(col_name)) - year(col(col_name)) % 10 + 9
                            )
                        ).drop(col_name).withColumnRenamed('range_of_years_temp', col_name)
        # except:
        #     pass
    
    return df

# COMMAND ----------

def extract_year(df, column_list):
    '''
    Input:
        - df: Spark dataframe
        - column_list: list of date columns to keep only the year of the date
    Output:
        - df: Spark dataframe with all columns in `column_list` transformed to years
    '''
    for col_name in column_list:
        # try:
            # df = df.withColumn(col_name, year(df[col_name])) # if we want integer type instead
        df = df.withColumn('year_temp', 
            year(col(col_name))
        ).drop(col_name).withColumnRenamed('year_temp', col_name)
        # except:
        #     pass
            
    return df

# COMMAND ----------

def extract_year_month(df, column_list):
    '''
    Input:
        - df: Spark dataframe
        - column_list: list of date columns to keep only the year and month of the date
    Output:
        - df: Spark dataframe with all columns in `column_list` transformed
    '''
    for col_name in column_list:
        # try:
        df = df.withColumn('year_month_temp', 
            date_format(col(col_name), "yyyy-MM")
        ).drop(col_name).withColumnRenamed('year_month_temp', col_name)
        # except:
        #     pass
            
    return df

# COMMAND ----------

def special_permission(df, column_list):
    '''
    Input:
        - df: Spark dataframe
        - column_list: list of columns to be dropped
    Output:
        - df: Spark dataframe with all columns in `column_list` dropped
    '''
    # try:
    df = df.drop(*column_list) # starred expression is cooler
    # except:
    #     pass
    
    return df

# COMMAND ----------

def default_to_zero(df, column_list):
    '''
    Input:
        - df: Spark dataframe
        - column_list: list of date columns to keep the year and month of the date to zero
    Output:
        - df: Spark dataframe with all columns in `column_list` transformed
    '''
    for col_name in column_list:
        #try:
            df = df.withColumn('default_to_zero_temp', (col(col_name)*0)).drop(col_name).withColumnRenamed('default_to_zero_temp', col_name)
        #except:
        #    pass
            
    return df

# COMMAND ----------

def range_of_years(df, column_list):
    '''
    Input:
        - df: Spark dataframe
        - column_list: list of year columns to keep only the range of the years
    Output:
        - df: Spark dataframe with all columns in `column_list` transformed to a string type as the range of years
    
    e.g. A year of 1996 gets converted to "1990 - 1999"
    '''
    for col_name in column_list:
        #try:
            df = df.withColumn('range_of_years_temp',
                                concat(
                                    (col(col_name)) - (col(col_name)) % 10,
                                    lit(' - '),
                                    (col(col_name)) - (col(col_name)) % 10 + 9
                                )
                            ).drop(col_name).withColumnRenamed('range_of_years_temp', col_name)
        #except:
         #   pass
    
    return df

# COMMAND ----------

def masking_engine(df, masking_dict, salt):
    '''
    Input: 
        - df: constructed Spark dataframe from the project query
        - masking_dict: dictionary with masking rules as the keys and list of columns as the values
        - salt: salt value (project key) to be used for the columns that need to be hashed
    Output: 
        - df: masked df
    '''
    for masking_rule, column_list in masking_dict.items():
        if masking_rule == "1-Way Hash":
            df = sha2_hash_column(df, column_list, salt)
        elif masking_rule == "FSA":
            df = extract_postal_code_fsa(df, column_list)
        elif masking_rule == "Range of Age":
            df = range_of_year(df, column_list)
        elif masking_rule == "Year":
            df = extract_year(df, column_list)
        elif masking_rule == "Year and Month":
            df = extract_year_month(df, column_list)
        elif masking_rule == "Special Permission":
            df = special_permission(df, column_list)
        elif masking_rule == "Default to Zero":
            df = default_to_zero(df, column_list)
        elif  masking_rule == "Range of Years":
            df = range_of_years(df, column_list)
    
    return df