# Databricks notebook source
# MAGIC %run "/Repos/repo/hdr-databricks/utils/libraries"

# COMMAND ----------

# MAGIC %run "../masking_engine"

# COMMAND ----------

def compare_dfs(df1, df2):
    df2.show()

    compare_df = df1.exceptAll(df2)

    if compare_df.isEmpty():
        print("The testing is successful and is working as expected.")
    else:
        print("The testing has failed and is not working as expected.")

# COMMAND ----------

# MAGIC %md
# MAGIC #### SHA-2 Hashing
# MAGIC ##### Input: 
# MAGIC     - df: Spark dataframe
# MAGIC     - column_list: list of columns to be hashed
# MAGIC     - salt: salt value to be used for the column
# MAGIC     - bit_length: bit length of digest to be returned
# MAGIC ##### Output: 
# MAGIC     - df: Spark dataframe with all columns in `column_list` salted and hashed

# COMMAND ----------

strings = [("hello there",), ("lord of the rings",), (None,), ("title",)]
column_name = "strings"
schema = StructType([StructField(column_name, StringType(), nullable=True)])
df = spark.createDataFrame(strings, schema)

expected_strings = [("fe705a95aa2309371ff196b2f7fa1c73922658e265c2c6036f8f81a621d7206472658dc8c63c175b364186e7aebb48ba233b40a6679a06843ea74d3dceacd3ca",), ("e8a1b029e9bcaa847e4444560ec9b29c3e31a5bab2437b735262a3179f72710bfa0cbf3bffc92ef71d07319437145dc982c0cc95a3fea34e125eb837cd29c809",), (None,), ("aef63e8ada619a24ff632e386ea42acef976a082fec8e2ad480e3e08df68548f03f58492c49be6bc37b60a9ce14440a17c87fa7a90fc130cce4357f1709e8016",)]
expected_df = spark.createDataFrame(expected_strings, schema)

salt = "abc123"
actual_df = sha2_hash_column(df, [column_name], salt)

compare_dfs(expected_df, actual_df)

# COMMAND ----------

# MAGIC %md
# MAGIC #### FSA Postal Code Extraction
# MAGIC ##### Input:
# MAGIC     - df: Spark dataframe
# MAGIC     - column_list: list of postal code columns to keep only their FSA components (they have "dqc_" prefixed)
# MAGIC ##### Output:
# MAGIC     - df: Spark dataframe with all columns in `column_list` FSA-extracted

# COMMAND ----------

strings = [("N2P2V5",), (None,), ("L9T 5e2",), ("L9T     5E2",)]
column_name = "dqc_postal_code"
schema = StructType([StructField(column_name, StringType(), nullable=True)])
df = spark.createDataFrame(strings, schema)

expected_strings = [("N2P",), (None,), ("L9T",), ("L9T",)]
dqc_schema = StructType([StructField(column_name, StringType(), nullable=True)])
expected_df = spark.createDataFrame(expected_strings, dqc_schema)

actual_df = extract_postal_code_fsa(df, [column_name])

compare_dfs(expected_df, actual_df)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Range of Age (Year)
# MAGIC ##### Input:
# MAGIC     - df: Spark dataframe
# MAGIC     - column_list: list of date columns to keep only the range of the years
# MAGIC ##### Output:
# MAGIC     - df: Spark dataframe with all columns in `column_list` transformed to a string type as the range of years
# MAGIC
# MAGIC e.g. A date of 1996-06-15 gets converted to "1990 - 1999"

# COMMAND ----------

dates = [(datetime(2023, 1, 1),), (datetime(1996, 6, 15),), (None,), (datetime(1989, 12, 31, 13, 33, 37),), (None,)]
column_name = "dates"
schema = StructType([StructField(column_name, TimestampType(), nullable=True)])
df = spark.createDataFrame(dates, schema)

expected_dates = [("2020 - 2029",), ("1990 - 1999",), (None,), ("1980 - 1989",), (None,)]
dates_schema = StructType([StructField(column_name, StringType(), nullable=True)])
expected_df = spark.createDataFrame(expected_dates, dates_schema)

actual_df = range_of_year(df, [column_name])

compare_dfs(expected_df, actual_df)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Year Extraction
# MAGIC ##### Input:
# MAGIC     - df: Spark dataframe
# MAGIC     - column_list: list of date columns to keep only the year of the date
# MAGIC ##### Output:
# MAGIC     - df: Spark dataframe with all columns in `column_list` transformed to years

# COMMAND ----------

dates = [(datetime(2023, 1, 1),), (datetime(1996, 6, 15),), (None,), (datetime(1989, 12, 31, 13, 33, 37),), (None,)]
column_name = "dates"
schema = StructType([StructField(column_name, TimestampType(), nullable=True)])
df = spark.createDataFrame(dates, schema)

expected_dates = [("2023",), ("1996",), (None,), ("1989",), (None,)]
dates_schema = StructType([StructField(column_name, StringType(), nullable=True)])
expected_df = spark.createDataFrame(expected_dates, dates_schema)

actual_df = extract_year(df, [column_name])

compare_dfs(expected_df, actual_df)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Year-Month Extraction
# MAGIC ##### Input:
# MAGIC     - df: Spark dataframe
# MAGIC     - column_list: list of date columns to keep only the year and month of the date
# MAGIC ##### Output:
# MAGIC     - df: Spark dataframe with all columns in `column_list` transformed

# COMMAND ----------

dates = [(datetime(2023, 1, 1),), (datetime(1996, 6, 15),), (None,), (datetime(1989, 12, 31, 13, 33, 37),), (None,)]
column_name = "dates"
schema = StructType([StructField(column_name, TimestampType(), nullable=True)])
df = spark.createDataFrame(dates, schema)

expected_dates = [("2023-01",), ("1996-06",), (None,), ("1989-12",), (None,)]
dates_schema = StructType([StructField(column_name, StringType(), nullable=True)])
expected_df = spark.createDataFrame(expected_dates, dates_schema)

actual_df = extract_year_month(df, [column_name])

compare_dfs(expected_df, actual_df)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Special Permission
# MAGIC ##### Input:
# MAGIC     - df: Spark dataframe
# MAGIC     - column_list: list of columns to be dropped
# MAGIC ##### Output:
# MAGIC     - df: Spark dataframe with all columns in `column_list` dropped

# COMMAND ----------

strings = [("123-456-7890",), ("2223334444",), (None,), ("Crazy long 555-555-5555 Blah blah Blah",)]
column_name = "strings"
schema = StructType([StructField(column_name, StringType(), nullable=True)])
df = spark.createDataFrame(strings, schema)

actual_df = special_permission(df, [column_name])

if actual_df.isEmpty:
    print("The testing is successful and is working as expected.")
else:
    print("The testing has failed and is not working as expected.")

# COMMAND ----------

# MAGIC %md
# MAGIC #### Validate Postal Codes
# MAGIC ##### Input: 
# MAGIC     - Spark dataframe (df)
# MAGIC     - List of string-type columns (column_names_list) representing postal codes
# MAGIC ##### Output: 
# MAGIC     - Creates a new column (prefixed with "dqc_") for each of the postal code columns with the following:
# MAGIC         - Uppercase
# MAGIC         - Remove non-alphanumeric characters
# MAGIC         - Validated Canadian format (A9A9A9)

# COMMAND ----------

strings = [("n2p2V5",), ("lord of the rings",), (None,), ("l9t 5e2",), ("L9T     5E2",)]
column_name = "postal_code"
schema = StructType([StructField(column_name, StringType(), nullable=True)])
df = spark.createDataFrame(strings, schema)

expected_strings = [("n2p2V5", "N2P2V5"), ("lord of the rings", ""), (None, None), ("l9t 5e2", "L9T5E2"), ("L9T     5E2", "L9T5E2")]
dqc_schema = StructType([StructField(column_name, StringType(), nullable=True),
                         StructField(f"dqc_{column_name}", StringType(), nullable=True)])
expected_df = spark.createDataFrame(expected_strings, dqc_schema)

actual_df = validate_postal_codes_child(df, [column_name])

compare_dfs(expected_df, actual_df)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Validate Health Card Numbers

# COMMAND ----------

# TODO

# COMMAND ----------

# MAGIC %md
# MAGIC #### Convert Dates
# MAGIC ##### Input: 
# MAGIC     - Spark dataframe (df)
# MAGIC     - List of string-type columns (column_names_list) representing dates in one of the following formats:
# MAGIC         (i) xxxx-xx-xx
# MAGIC         (ii) xxxx-xx-xx xx:xx:xx
# MAGIC         (iii) xxxxxxxx
# MAGIC         where x is a digit
# MAGIC ##### Output: 
# MAGIC     - Transforms the string-type columns data to dates

# COMMAND ----------

strings = [("20230101",), ("1996-06-15",), (None,), ("1989-12-31 13:33:37",), ("2023",)]
column_name = "strings"
schema = StructType([StructField(column_name, StringType(), nullable=True)])
df = spark.createDataFrame(strings, schema)

expected_dates = [(datetime(2023, 1, 1),), (datetime(1996, 6, 15),), (None,), (datetime(1989, 12, 31, 13, 33, 37),), (None,)]
dates_schema = StructType([StructField(column_name, TimestampType(), nullable=True)])
expected_df = spark.createDataFrame(expected_dates, dates_schema)

actual_df = convert_dates_child(df, [column_name])

compare_dfs(expected_df, actual_df)