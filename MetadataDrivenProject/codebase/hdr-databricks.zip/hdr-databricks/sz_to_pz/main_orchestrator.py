# Databricks notebook source
# MAGIC %md
# MAGIC **Known issues / requirements**
# MAGIC - The table name used in the query must match the case of the table in azure data lake storage and purview (ex. if the alds filepath is __./dhw/hap/dis/IDENTIFIER.delta/__ the query must be __'SELECT * FROM dhw_hap_dis.IDENTIFIER'__)
# MAGIC - All table names must include their schema. (ex. __'SELECT col FROM schema.table'__, not __'SELECT col FROM table'__)
# MAGIC - Table names must __NOT__ include database names or linked server names (ex. __'SELECT col FROM pseudostandardized.schema.table'__ is prohibited)
# MAGIC - No __SELECT ... INTO__ clauses are permitted
# MAGIC - No __SELECT *__ in the top level __SELECT__ statement
# MAGIC
# MAGIC **TODO**
# MAGIC - Move code into testable functions & write unit tests
# MAGIC
# MAGIC **Notes**
# MAGIC - Code is written as functions wherever possible to increase testability of the code
# MAGIC

# COMMAND ----------

# MAGIC %run "../utils/libraries"

# COMMAND ----------

from collections import defaultdict
from pprint import pprint
from pyspark.sql.functions import col 
import sqlglot
from sqlglot import expressions as exp
from sqlglot.optimizer.scope import traverse_scope
from sqlglot.optimizer.qualify import qualify
from time import sleep

# COMMAND ----------

from utils.config import DEV_FLAG
RUN_TESTS = False

# COMMAND ----------

# MAGIC %run "../sz_to_pz/pseudonymization"

# COMMAND ----------

# read in parameters
dbutils.widgets.text("p_project", "") # matches `AbbreviatedName` in dbo.HDR_User_Project_Tracking (project config)
dbutils.widgets.text("p_query", "")
dbutils.widgets.text("p_destination_format", "")
# Possible string values for `destination_format`:
#         - Database
#         - Container
#         - Both
dbutils.widgets.text("p_destination_name", "")
dbutils.widgets.text("p_email", "")
dbutils.widgets.text("p_sz_st_name", "")
dbutils.widgets.text("p_pz_st_name", "")

project = dbutils.widgets.get("p_project")
tsql = dbutils.widgets.get("p_query")
destination_format = dbutils.widgets.get("p_destination_format")
destination_name = dbutils.widgets.get("p_destination_name")
email = dbutils.widgets.get("p_email")
sz_st_name = dbutils.widgets.get("p_sz_st_name")
pz_st_name = dbutils.widgets.get("p_pz_st_name")

# ensure parameters fit the bill. For internal debugging purposes
# none of these errors should ever occur
assert len(project) > 0, "p_project is required"
assert project.count('-') == 1, "Invalid project, should be of the format <org>-<project name>"
assert len(tsql) > 0, "tsql is required"
assert len(destination_format) > 0, "p_destination_format is required"
assert destination_format.lower() in ["database", "container", "both"], "Invalid destination_format, should be one of 'Database', 'Container', or 'Both'"
assert len(destination_name) > 0, "p_destination_name is required"
assert len(email) > 0, "p_email is required"
assert email.count('@') == 1, "Invalid email address"
assert len(sz_st_name) > 0, "p_sz_st_name is required"
assert sz_st_name.islower(), "p_sz_st_name must be lowercased"
assert len(pz_st_name) > 0, "p_pz_st_name is required"
assert pz_st_name.islower(), "p_pz_st_name must be lowercased"

# lowercase project name just in case
project = project.lower()

# build mountpoint to see if pz needs to be mounted
pz_mountpoint = f"/mnt/{pz_st_name}/{project}"

# COMMAND ----------

def run_with_retry(notebook: str, timeout: int, args: dict = {}, max_retries: int = 3) -> None:
    '''Tries running a notebook and retries on failure.

    Args:
        notebook: the path to the databricks notebook.
        timeout: time in seconds to wait for timeout for the notebook running.
        args: arguments passed to the notebook.
        max_retries: number of retries before an exception is raised

    Returns:
        Nothing
    '''
    num_retries = 0
    while True:
        try:
            return dbutils.notebook.run(notebook, timeout, args)
        except Exception as e:
            if num_retries > max_retries:
                raise e
            else:
                print("Retrying error", e)
                num_retries += 1

# COMMAND ----------

# DBTITLE 1,Get project key
# get project key - fail if not accessible
if DEV_FLAG:
    kv_scope = "azurekvhdr-scope"
else:
    kv_scope = "scope-kv-hdr-project-prd-001"

try:
    project_key = dbutils.secrets.get(scope=kv_scope, key=f"projectkey-{project}")
except Exception as error:
    debug = "The Key Vault project key cannot be read"
    error_handling(error, debug)

# COMMAND ----------

# DBTITLE 1,Mount containers if required
# mounts std zone container if it is not mounted already
if not any(mount.mountPoint == pz_mountpoint for mount in dbutils.fs.mounts()):
    args = {"orgname": project, "accountname": pz_st_name, "systemname": None}
    run_with_retry("../op_to_lz/configuration", 60, args, max_retries=1)

# COMMAND ----------

# DBTITLE 1,Parse the query using sqlglot
# parse the sql statement using sqlglot. This creates an "abstract syntax tree" of the query
# which is essentially just a plan the sql engine uses to understand a query
ast = sqlglot.parse_one(tsql, read="tsql")


# COMMAND ----------

# DBTITLE 1,Validate the query complies with basic HDR requirements
def validate_query(query_tree: exp.Expression) -> exp.Expression:
    '''Validates a sqlglot abstract syntax tree to ensure it meets HDR requirements

    Args:
      query_tree: the result of sqlglot.parse_one 
    
    Returns:
      The query tree if it passes all tests. Raises an Exception otherwise.
    '''
    
    # only select statements are allowed
    try:
        query_tree = query_tree.assert_is(exp.Select) # only SELECT allowed
    except AssertionError as e:
        raise Exception("Only SELECT statements are permitted.") from e

    # no INTO statements are allowed
    # only need to check outer SELECT as INTO is not allowed in a subquery or CTE (see view rules)
    # https://learn.microsoft.com/en-us/sql/relational-databases/performance/subqueries?view=sql-server-ver16#rules
    # https://learn.microsoft.com/en-us/sql/t-sql/statements/create-view-transact-sql?view=sql-server-ver16#as
    if query_tree.find(exp.Into):
        raise Exception("SQL keyword INTO is prohibited.")

    # no '*' wildcard in the final select, could result in ambiguous
    # column names in destination
    if query_tree.is_star:
        raise Exception("The character star ('*') is prohibited in the final SELECT statement.")

    return query_tree

ast = validate_query(ast)

# COMMAND ----------

def get_physical_tables(query_tree: exp.Expression) -> list[exp.Table]:
    """Gets all physical tables used in a query. A physical table
    is one actually in the database, not a cte or subquery.

    If a physical table is used more than onece it takes one of them. A table
    can be present under many aliases, the first one is selected for the list.

    Args:
      query_tree: the result of sqlglot.parse_one

    Returns:
      The physical tables used in the query
    """
    physical_tables = []

    for scope in traverse_scope(query_tree):
        for src in scope.sources:
            node = scope.sources.get(src)

            if not isinstance(node, exp.Table):
                continue

            if exp.table_name(node) not in [exp.table_name(t) for t in physical_tables]:
                # without copy acts like copy by reference instead of by value
                physical_tables.append(node.copy())

    return physical_tables


physical_tables = get_physical_tables(ast)


def validate_schema(table: exp.Table) -> exp.Table:
    """Validates that all tables have a schema that complies with HDR requirements.

    Args:
      table: a sqlglot table expression

    Returns:
      The table if it has a valid schema.
    """

    print(f"Validating schema for table: {exp.table_name(table)}...", end="")

    # no database part of table allowed, all tables must have schema parts defined
    if table.db is None or table.catalog:
        raise Exception(
            f"All tables must be in the format {{schema}}.{{table}}, got {exp.table_name(table)}"
        )

    if len(table.db.split("_")) != 3:
        raise Exception(
            f"All schema must use the format '{{organization}}_{{system}}_{{schema}}, got {physical_table.db}."
        )

    print("Pass.")

    return table


# validate all schemas for compliance with HDR naming rules
for t in physical_tables:
    validate_schema(t)

# COMMAND ----------

# DBTITLE 1,Get schemas for all physical tables used in query

def get_schema_delta(table: exp.Table, sz_storage_account: str) -> dict[str: str]:
    '''Gets the delta table schema for a standardized zone table.

    Args:
      table: a sqlglot table obect

    Returns
      A dictionary of column: datatype for all columns in the delta table
    ''' 
    
    path = (
        f"/mnt/{sz_storage_account}/standardized/{table.db.replace('_', '/')}/{table.name}.delta"
    )

    return dict(spark.read.format("delta").load(path).dtypes)


def build_schema(table_list: list[exp.Table]) -> dict[str: dict]:
    '''Builds dictionary containing schema. Format:

    Args:
      table_list: a list of sqlglot tables with associated files in the std zone

    Returns:
    {
        schema_name_1 <optional>: {
            table_name_1 : {
                column_name_1: data_type,
                . . .
            },
            . . .
        },
        . . .
    }
    '''
    schema = {}

    for t in table_list:

        if t.db not in schema:  # sqlserver schema is called db in sqlglot
            schema[t.db] = {}

        if t.name not in schema[t.db]:
            schema[t.db][t.name] = {}

        # build the schema
        schema[t.db][t.name] = get_schema_delta(t, sz_st_name)

        # print(f"Added {t.db}.{t.name}.{schema[t.db][t.name]} to schema.")

    return schema

schema = build_schema(physical_tables)

pprint(schema)

# COMMAND ----------

# qualify all columns (non-validating). Qualifying adds table and column aliases to all
# tables/columns and prefixes all columns with the table alias for the table
# they are part of.
# validating transforms all identifiers (table names, column names, etc) to lowercase.
# this can't be prevented.
print(f"Query before qualifying:\n {ast.sql()}", end="\n\n")

qualify(ast, dialect="tsql", schema=schema, quote_identifiers=True)

print(f"Query after qualifying:\n {ast.sql()}", end="\n\n")

# COMMAND ----------

# get the list of columns used
def get_physical_columns(query_tree: exp.Expression) -> dict[str: set]:
    '''Gets all physical columns used in a query. A physical column
    is one actually in the database, not calculated or the result of a function.

    Args:
      query_tree: the result of sqlglot.parse_one

    Returns:
      Dict of table: {columns}
    '''
    physical_columns = defaultdict(set)  # set to prevent duplicate cols being added
    for scope in traverse_scope(query_tree):
        for c in scope.columns:
            if isinstance(scope.sources.get(c.table), exp.Table):
                physical_columns[exp.table_name(scope.sources.get(c.table))].add(c.name)
    
    return physical_columns

physical_columns = get_physical_columns(ast)

print(physical_columns)

# COMMAND ----------

def _build_masking_rules(used_columns: list, purview_response: list) -> dict:
    """Builds a masking dictionary with masking rules as the keys and list of columns as the values.

    Args:
      used_columns: a list of columns that are used in the query.
      purview_response: the output of the Purview API

    Returns:
      A dictionary containing masking rules and the list of columns to apply them to.
        i.e.
        {
            "<masking_rule_1>": ["column_name_1", ...],
            ...
        }

        e.g.
        {
            "1-Way Hash": ["MIDDLE_NAME", "FIRST_NAME"],
            "Year and Month": ["DATE_OF_BIRTH"]
        }
    """

    assert len(purview_response) == 1, "Error with Purview API Response"

    purview_response = purview_response[0]  # only run for single response

    masking_rules = defaultdict(list)

    for col in purview_response.get("columns"):
        col_name = col.get("name")

        if col_name.lower() not in [c.lower() for c in used_columns]:
            continue

        classifications = col.get("classifications")

        if classifications:
            classification_name = classifications[0].get("name")
            access_level_str = classifications[0].get("overrideAccessLevel")
            sensitivity_level = classifications[0].get("sensitivityLevel")

            if None in (classification_name, access_level_str, sensitivity_level):
                raise Exception(
                    f"Column {col_name} is missing classification information.\n{classification_name=}, {access_level_str=}, {sensitivity_level=}"
                )

            # get the last character of access level (the numeric level)
            access_level = int(access_level_str[-1])

            # use access_level to build the correct key to get the masking function that should be applied
            masking_rule = classifications[0].get(f"accessLevel{access_level}")

            # if sensitivity level is special permission then the masking rule is unique
            if "special permission" in sensitivity_level.lower():
                masking_rule = "Special Permission"

            # only include masking rules for columns we are selecting from the dataframe
            masking_rules[masking_rule].append(col_name)

    return masking_rules

# COMMAND ----------

# DBTITLE 1,Builds views with all columns used in query masked
# build masked views
# mask the tables before they're queried to prevent
# users from running exploratory where clauses like "WHERE HCN=0000123456" to get that data
for t in physical_tables:

    # build fqn for use in the purview API
    qualified_name = f"https://{sz_st_name}.dfs.core.windows.net/standardized/{t.db.replace('_', '/')}/{t.name}.delta/{{SparkPartitions}}"

    # build path to load table
    path = (
        f"/mnt/{sz_st_name}/standardized/{t.db.replace('_', '/')}/{t.name}.delta"
    )

    # get purview configuration for this table and project
    purview_response = call_purview_api([qualified_name], project)

    print(purview_response, end=f"\n{'-'*20}\n")

    df = spark.read.format("delta").load(path)

    masking_dict = _build_masking_rules(
        list(physical_columns[exp.table_name(t).lower()]), purview_response
    )
    print(f"{masking_dict=}", end=f"\n{'-'*20}\n")

    # pseudonymize the dataframe
    pseudo_df = pseudonymization(
        project=project,
        df=df,
        purview=purview_response,
        masking_dict=masking_dict,
        project_key=project_key,
    )

    # create temp view for later use
    # having a '.' in the name causes problems in sqlglot, replace with '#'
    pseudo_df.createOrReplaceTempView(f"`{exp.table_name(t).replace('.','#')}`")

# COMMAND ----------

# show temp table names for debugging
spark.sql("SHOW TABLES").where("IsTemporary = True").display()

# COMMAND ----------

# DBTITLE 1,Replace table names in query to dbricks temp view names
# replace table names so they can be run vs temp views in dbricks
#
# databricks temp views are not created in a user-definable schema so we must move the schema to be part
# of the table name.
def transformer(node):
    if isinstance(node, exp.Table) and exp.table_name(node) in [
        exp.table_name(t).lower() for t in physical_tables
    ]:

        tmp = node.copy()
        tmp.set(
            "this",
            exp.maybe_parse(
                exp.to_identifier(exp.table_name(node).replace(".", "#"), quoted=True)
            ),
        )
        tmp.set("db", None)

        print(f"{repr(node)}\n\nCopied to:\n\n{repr(tmp)}", end=f"\n{'-'*20}\n")

        return tmp
    return node


ast_transformed = ast.transform(transformer)

print("Original query parsed sql: ", ast.sql(dialect="tsql"), end=f"\n{'-'*20}\n")
print("Qualified query sql: ", ast_transformed.sql(dialect="tsql"), end=f"\n{'-'*20}\n")
print("Original query tree: ", repr(ast), end=f"\n{'-'*20}\n")
print("Qualified query tree: ", repr(ast_transformed), end=f"\n{'-'*20}\n")

# COMMAND ----------

print("Query transcribed to spark sql: ", ast_transformed.sql(dialect="spark"))
df = spark.sql(ast_transformed.sql(dialect="spark"))

# COMMAND ----------

# show dataframe sample for debugging
df.show()

# COMMAND ----------

def get_destination_source(project: str) -> str:
    """Get the database for the project.

    Args:
      project: the HDR project key

    Returns:
      A string `database`
    """
    # get JDBC connection string from key vault

    if DEV_FLAG:
        kv_scope = "azurekvhdr-scope"
        key_secret = "jdbc-sqldb-hdr-datalandingzone-health-connection-string"
    else:
        kv_scope = "scope-kv-hdr-app-prd-001"
        key_secret = "jdbc-sqldb-hdr-datazonehealth-config-connection-string-prd"

    try:
        jdbcUrl = dbutils.secrets.get(scope=kv_scope, key=key_secret)
    except Exception as error:
        debug = "The Key Vault connection string key cannot be read"
        error_handling(error, debug)

    # retrieve HDR_User_Project_Tracking (project config) table
    # and get the database name
    pc_df = spark.read.jdbc(url=jdbcUrl, table="dbo.HDR_User_Project_Tracking")\
        .where(col('AbbreviatedName') == project)

    print(f"{project=}")
    print('pc_df')
    pc_df.show()

    try:
        database = pc_df.first()["Database"]
    except Exception as error:
        debug = "Something wrong with the Project Tracking sheet"
        error_handling(error, debug)  # exit notebook here with logging

    return database

# COMMAND ----------

def write_to_published(
    df, project: str, destination_format: str, destination_name: str
) -> None:
    """Write `df` to the project's SQL database or ADLS Gen2 storage or both

    Args:
      df: dataframe to be written
      project: the HDR project key
      destination_format: one of ['Database', 'Container', 'Both'], the destination to write the query result to
      destination_name: the name that will be used for the file or database table
    """

    # define the intermediate functions
    def write_to_database() -> None:
        if not re.match(r"^[a-zA-Z_][a-zA-Z0-9_]*$", destination_name):
            raise AssertionError(
                "Invalid character(s) in destination_name (table name)"
            )

        # retrieve the necessary database name
        database = get_destination_source(project)

        print(f"Database parsed as: {database}")

        assert (
            database.count("/") == 1
        ), "Invalid Database name, should be of the format <SQL server>/<SQL database>"

        # extract the server and database names
        sql_server, sql_database = database.split("/")

        sql_server_url = f"{sql_server}.database.windows.net:1433"

        # define the JDBC URL and table name to be used (default 'dbo' schema)
        jdbc_url = f"jdbc:sqlserver://{sql_server_url};database={sql_database};encrypt=true;trustServerCertificate=false;hostNameInCertificate=*.database.windows.net;loginTimeout=30;"
        table_name = f"dbo.{destination_name}"

        # get username and password needed to insert the data
        if DEV_FLAG:
            kv_scope = "azurekvhdr-scope"
            db_client_id = "id-dbworchestrator-clientid"
            db_client_secret = "id-dbworchestrator-clientsecret"
            db_tenant_id = "tenantid"
        else:
            kv_scope = "scope-kv-hdr-app-prd-001"
            db_client_id = "sp-hdr-databricksws-prd-canc-001-clientid"
            db_client_secret = "sp-hdr-databricksws-prd-canc-001-accesskey"
            db_tenant_id = "sp-hdr-databricksws-prd-canc-001-tenantid"

        try:
            # sp-hdr-dbworchestrator credentials
            client_id = dbutils.secrets.get(scope=kv_scope, key=db_client_id)
            client_secret = dbutils.secrets.get(scope=kv_scope, key=db_client_secret)
            tenant_id = dbutils.secrets.get(scope=kv_scope, key=db_tenant_id)
        except Exception as error:
            debug = "The Key Vault service principal cannot be read"
            error_handling(error, debug)

        # define the connection properties
        connection_properties = {
            "AADSecurePrincipalId": f"{client_id}@{tenant_id}",
            "AADSecurePrincipalSecret": client_secret,
            "driver": "com.microsoft.sqlserver.jdbc.SQLServerDriver",
            "authentication": "ActiveDirectoryServicePrincipal",
        }

        # write the table to the appropriate SQL db
        max_tries = 2
        num_tries = 0
        while num_tries <= max_tries:
            try:
                df.write.jdbc(
                    url=jdbc_url,
                    table=table_name,
                    mode="overwrite",
                    properties=connection_properties,
                )
                break
            except Exception as e:
                if num_tries == max_tries:
                    error_handling(e, "Error writing to database, max tries exceeded")
                else:
                    print(f"Error writing to database, attempt {num_tries}")
                    sleep(30)
                    num_tries += 1


    def write_to_container() -> None:
        if not re.match(r"^[A-Za-z0-9_\- ]+$", destination_name):
            raise AssertionError("Invalid character(s) in destination_name (filename)")

        _, ext = os.path.splitext(destination_name)
        if ext != "":
            raise AssertionError(
                "destination_name should not have a file extension named"
            )

        # build mounted folder paths
        pz_out_folder = f"/dbfs/mnt/{pz_st_name}/{project}/data"
        pz_out_filepath = f"{pz_out_folder}/{destination_name}.parquet"

        
        # write the file to the appropriate out folder
        if not os.path.exists(pz_out_folder):
            os.mkdir(pz_out_folder)

        try:
            print(f"Writing to {pz_out_filepath}")
            df.write.format("parquet").mode("overwrite").save(pz_out_filepath[5:])
            
        except Exception as error:
            debug = f"Could not write a table to {pz_out_filepath[5:]}"
            error_handling(error, debug)

    # standardize the format string just in case
    destination_format = destination_format.lower()

    if destination_format == "database":
        write_to_database()
    elif destination_format == "container":
        write_to_container()
    elif destination_format == "both":
        write_to_database()
        write_to_container()
    else:
        raise Exception(f"Invalid destination format: {destination_format}")

# COMMAND ----------

# write it in project's DB or storage account now that we have `df` masked
write_to_published(df, project, destination_format, destination_name)

# COMMAND ----------

if RUN_TESTS:
    import unittest

    class TestValidateQuery(unittest.TestCase):

        def test_no_star(self):
            q = sqlglot.parse_one("SELECT * FROM t")
            self.assertRaises(Exception, validate_query, q)

        def test_no_into(self):
            q = sqlglot.parse_one("SELECT a INTO b FROM c")
            self.assertRaises(Exception, validate_query, q)

        def test_select_only(self):
            q = sqlglot.parse_one("DELETE FROM a WHERE b = 'c'")
            self.assertRaises(Exception, validate_query, q)

    class TestGetPhysicalTables(unittest.TestCase):

        def test_cte(self):
            ts = get_physical_tables(sqlglot.parse_one("WITH a AS (SELECT b FROM c) SELECT * FROM a join b"))
            self.assertEqual(sorted([exp.table_name(t) for t in ts]), ['b', 'c'])

        def test_subquery(self):
            ts = get_physical_tables(sqlglot.parse_one("SELECT * FROM a join (SELECT * FROM b) AS c"))
            self.assertEqual(sorted([exp.table_name(t) for t in ts]), ['a', 'b'])

        def test_quoted(self):
            ts = get_physical_tables(sqlglot.parse_one('SELECT * FROM [a] join (SELECT * FROM "b") AS c', read='tsql'))
            self.assertEqual(sorted([exp.table_name(t) for t in ts]), ['a', 'b'])

    class TestValidateSchema(unittest.TestCase):

        def test_valid(self):
            t = exp.table_('a', 'b_c_d')
            self.assertEqual(validate_schema(t), t)

        def test_four_parts(self):
            t = exp.table_('a', 'b_c_d_e')
            self.assertRaises(Exception, validate_schema, t)

        def test_two_parts(self):
            t = exp.table_('a', 'b_c')
            self.assertRaises(Exception, validate_schema, t)

        def test_database(self):
            t = exp.table_('a', 'b_c_d', 'e')
            self.assertRaises(Exception, validate_schema, t)

    class TestGetPhysicalColumns(unittest.TestCase):
        # test cases should be fully qualified as they will be in the script

        def test_valid(self):
            t = get_physical_columns(sqlglot.parse_one("SELECT e.f, e.g, e.h FROM a_b_c.d as e"))
            self.assertEqual(sorted(t.items()), sorted({'a_b_c.d': {'f', 'g', 'h'}}.items()))

        def test_no_schema(self):
            t = get_physical_columns(sqlglot.parse_one("SELECT a.b, a.c, a.d FROM a"))
            self.assertEqual(sorted(t.items()), sorted({'a': {'b', 'c', 'd'}}.items()))

        def test_quoted_table(self):
            t = get_physical_columns(sqlglot.parse_one('SELECT "a".b, [a].c, a.d FROM a', read='tsql'))
            self.assertEqual(sorted(t.items()), sorted({'a': {'b', 'c', 'd'}}.items()))

    class TestQualify(unittest.TestCase):
        # test cases to ensure the behavior of sqlglot qualify doesn't change if version is changed

        def test_case_unquoted(self):
            self.assertEqual(
                qualify(sqlglot.parse_one('SELECT a FROM FOo')).sql(),
                'SELECT "foo"."a" AS "a" FROM "foo" AS "foo"'
        )
        
        def test_case_quoted_square(self):
            self.assertEqual(
                qualify(sqlglot.parse_one('SELECT [A] FROM [FOo]')).sql(),
                'SELECT "foo"."a" AS "a" FROM "foo" AS "foo"'
        )
        
        def test_case_quoted_double_quote(self):
            self.assertEqual(
                qualify(sqlglot.parse_one('SELECT "A" FROM "FOo"')).sql(),
                'SELECT "foo"."a" AS "a" FROM "foo" AS "foo"'
        )

    r = unittest.main(argv=[''], verbosity=2, exit=False, warnings='ignore')
    assert r.result.wasSuccessful(), 'Test failed; see logs above'