# Databricks notebook source
# DBTITLE 1,Importing Libraries
import json
from pyspark.sql.functions import regexp_replace,monotonically_increasing_id,row_number,to_date
from pyspark.sql.window import Window
from pyspark.sql.types import DateType,IntegerType,LongType
import re
import datetime

# COMMAND ----------

# DBTITLE 1,Input Widgets are declared
dbutils.widgets.text('Environment','')
Environment=dbutils.widgets.get('Environment')

# COMMAND ----------

# DBTITLE 1,Environment and paths are defined
if Environment=='DEV':
    output_ref_path='/mnt/sthdrcurzonedevtest/athena/output/ref/'
    output_omop_path='/mnt/sthdrcurzonedevtest/dhw/cz/'
    sz_tables_list_path="/dbfs/mnt/sthdrcurzonedevtest/ds_config/sz_tables.txt"
    source_ref_path='/mnt/sthdrstdzonedevtest/standardized/athena/output/ref/'
    source_omop_path='/mnt/sthdrstdzonedevtest/standardized/athena/output/omop/'
    cur_ext_table_path='/mnt/sthdrcurzonedevtest/dhw/cz/curated_db/'

else:
    output_ref_path='/mnt/sthdrcurzoneprd/dhw/ref/'
    output_omop_path='/mnt/sthdrcurzoneprd/dhw/cz/'
    sz_tables_list_path="/dbfs/mnt/sthdrcurzoneprd/ds_config/sz_tables.txt"
    source_ref_path="/mnt/sthdrstdzoneprd/standardized/athena/output/ref/"
    source_omop_path="/mnt/sthdrstdzoneprd/standardized/athena/output/omop/"
    cur_ext_table_path='/mnt/sthdrcurzoneprd/dhw/cz/curated_db/'

# COMMAND ----------

# DBTITLE 1,Utility functions are called
# MAGIC %run ../common_functions/UtilityFunctions

# COMMAND ----------

# DBTITLE 1,Read Table List
try:
    result = read_config(sz_tables_list_path)
    env_config_data = json.loads(result)
    sz_list=env_config_data["SZ"]
    ref_list=env_config_data["ref"]["mzin_ref"]
except Exception as e:
    error_handling("unable to get the inputs",str(e))

# COMMAND ----------

# DBTITLE 1,Create RefTables
for tablename in ref_list:
    target_table = f"mdm_ref.{tablename}"
    target_path=output_ref_path+f"{tablename}"
    source_path=source_ref_path+f"{tablename}.delta"
    ref_df=spark.read.format('delta').load(source_path)
    ref_df=df_format_columns(ref_df)
    ref_df.write.format('delta').mode('overwrite').save(target_path)
    spark.sql('create database if not exists mdm_ref')
    spark.sql(f"create table if not exists {target_table} using delta location '{target_path}'")

# COMMAND ----------

# DBTITLE 1,Create OMOP Tables
for i in env_config_data.get('OMOP').get('cz'):
    src_omop=source_omop_path+i+'.delta/'
    df_omop=spark.read.format('delta').load(src_omop)
    cols=df_omop.columns
    if 'valid_start_date' in cols and 'valid_start_date' in cols:
        df_omop=df_omop.withColumn("valid_start_date",to_date(col("valid_start_date"),"yyyyMMdd").cast(DateType()))\
            .withColumn("valid_end_date",to_date(col("valid_end_date"),"yyyyMMdd").cast(DateType()))
    for j in cols:
        if j in ["concept_id","ancestor_concept_id","descendant_concept_id","concept_class_concept_id","concept_id_1","concept_id_2","language_concept_id","relationship_concept_id","vocabulary_concept_id","max_levels_of_separation","min_levels_of_separation","domain_concept_id"]:
            df_omop=df_omop.withColumn(j,col(j).cast(IntegerType()))
    df_omop.write.format('delta').mode('overwrite').save(output_omop_path+i.lower())
    spark.sql('create database if not exists cz')
    spark.sql(f"create table if not exists cz.{i.lower()} using delta location '{output_omop_path+i.lower()}'")

# COMMAND ----------

# DBTITLE 1,OMOP External Table files
mapping_config={
"CONCEPT":"concept_id",
"CONCEPT_CLASS":"concept_class_concept_id",
"DOMAIN":"domain_concept_id",
"RELATIONSHIP":"relationship_concept_id",
"VOCABULARY":"vocabulary_concept_id"
}
for i in env_config_data.get('OMOP').get('cz'):
    df_omop=spark.read.format('delta').load(output_omop_path+i.lower())
    if i=='CONCEPT_ANCESTOR':
        df_omop=df_omop.withColumn('min_levels_of_separation',col('min_levels_of_separation').cast(IntegerType()))\
                        .withColumn('max_levels_of_separation',col('max_levels_of_separation').cast(IntegerType()))\
                            .withColumn('ancestor_concept_id',col('ancestor_concept_id').cast(LongType()))\
                                .withColumn('descendant_concept_id',col('descendant_concept_id').cast(LongType()))
    elif i=='CONCEPT_SYNONYM':
        df_omop=df_omop.withColumn('concept_id',col('concept_id').cast(LongType()))\
                        .withColumn('language_concept_id',col('language_concept_id').cast(LongType()))
    elif i=='CONCEPT_RELATIONSHIP':
        df_omop=df_omop.withColumn('concept_id_1',col('concept_id_1').cast(LongType()))\
                        .withColumn('concept_id_2',col('concept_id_2').cast(LongType()))
    if i in mapping_config:
        colm=mapping_config.get(i)
        df_omop=df_omop.withColumn(colm,col(colm).cast(LongType()))
    cols=df_omop.columns
    if 'valid_start_date' in cols and 'valid_start_date' in cols:
        df_omop=df_omop.withColumn("valid_start_date",to_date(col("valid_start_date"),"yyyyMMdd").cast(DateType()))\
            .withColumn("valid_end_date",to_date(col("valid_end_date"),"yyyyMMdd").cast(DateType()))
    df_omop.write.format('delta').mode('overwrite').save(cur_ext_table_path+i.lower())   

# COMMAND ----------

dbutils.notebook.exit("Ref and OMOP Tables created successfully")