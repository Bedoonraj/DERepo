-- Databricks notebook source
-- MAGIC %python
-- MAGIC dbutils.widgets.text('Environment','')
-- MAGIC Environment=dbutils.widgets.get('Environment')

-- COMMAND ----------

-- MAGIC %python
-- MAGIC if Environment=='DEV':
-- MAGIC     storage="sthdrcurzonedevtest"
-- MAGIC else:
-- MAGIC     storage="sthdrcurzoneprd"

-- COMMAND ----------

-- DBTITLE 1,SZ to MZIN
-- MAGIC %python
-- MAGIC #Code to compare two hive data set
-- MAGIC import datacompy
-- MAGIC import os
-- MAGIC
-- MAGIC dir_path = f'/dbfs/mnt/{storage}/trans_script/1_sz_mzin/'
-- MAGIC schema = 'mzin'
-- MAGIC res = []
-- MAGIC for path in os.listdir(dir_path):
-- MAGIC     if os.path.isfile(os.path.join(dir_path, path)):
-- MAGIC         res.append(path)
-- MAGIC
-- MAGIC for name in res:
-- MAGIC     try:
-- MAGIC         #print(name)
-- MAGIC         table_name = schema + "." + (name.split('.', 1)[0])
-- MAGIC         tbl_name = (name.split('.', 1)[0])
-- MAGIC         script_path = dir_path + name
-- MAGIC         print('Table :' + tbl_name)
-- MAGIC
-- MAGIC         string_to_replace = "(select lastloaddatetime from adf_config.adf_datasetlog where datasetname ='" + tbl_name + "')"
-- MAGIC         source_script_path = script_path
-- MAGIC         result_file_path = "/dbfs/mnt/sthdrcurzonedevtest/sit/comparison_result/" + table_name.replace(".", "_") + ".txt"
-- MAGIC
-- MAGIC         with open(source_script_path, "r") as trans_script:
-- MAGIC             source_script = trans_script.read()
-- MAGIC             source_script = source_script.replace(string_to_replace, "null")
-- MAGIC             #print(source_script)
-- MAGIC
-- MAGIC         df1=spark.sql(source_script)
-- MAGIC         sql_script = "select * from " + table_name
-- MAGIC         df2=spark.sql(sql_script)
-- MAGIC         comparison = datacompy.SparkCompare(spark, df1, df2, join_columns = [('source_keyattr')],show_all_columns=True,match_rates=True)
-- MAGIC
-- MAGIC         print('No. of rows in source: '+ str(comparison.base_row_count))
-- MAGIC         print('No. of rows in target: '+ str(comparison.compare_row_count))
-- MAGIC         print('No. of rows in common: '+ str(comparison.common_row_count))
-- MAGIC
-- MAGIC         with open(result_file_path, 'w') as report_file:
-- MAGIC             comparison.report(file=report_file)
-- MAGIC             #comparison.rows_both_mismatch.display()
-- MAGIC         print('\n')
-- MAGIC     
-- MAGIC     except Exception as e:
-- MAGIC             print(str(e))
-- MAGIC             print('\n')
-- MAGIC

-- COMMAND ----------

-- DBTITLE 1,Dup check for mzin tables

select 'mzin_cr_person' 	as tbl_name, code from mzin.mzin_cr_person 	  group by code having count(1) > 1 union 
select 'mzin_dad_person' 	as tbl_name, code from mzin.mzin_dad_person   group by code having count(1) > 1 union 
select 'mzin_dis_person' 	as tbl_name, code from mzin.mzin_dis_person   group by code having count(1) > 1 union 
select 'mzin_dss_person' 	as tbl_name, code from mzin.mzin_dss_person   group by code having count(1) > 1 union 
select 'mzin_ed_person' 	as tbl_name, code from mzin.mzin_ed_person 	  group by code having count(1) > 1 union 
select 'mzin_nafp_person' 	as tbl_name, code from mzin.mzin_nafp_person  group by code having count(1) > 1 union 
select 'mzin_dad_provider' 	as tbl_name, code from mzin.mzin_dad_provider group by code having count(1) > 1 union 
select 'mzin_dis_provider' 	as tbl_name, code from mzin.mzin_dis_provider group by code having count(1) > 1 union 
select 'mzin_dss_provider' 	as tbl_name, code from mzin.mzin_dss_provider group by code having count(1) > 1 union 
select 'mzin_ed_provider' 	as tbl_name, code from mzin.mzin_ed_provider  group by code having count(1) > 1 union 
select 'mzin_pr_provider' 	as tbl_name, code from mzin.mzin_pr_provider  group by code having count(1) > 1 

-- COMMAND ----------

-- DBTITLE 1,Null check for Mzin tables

select 'mzin_cr_person' 	as tbl_name, hdr_primary_key from mzin.mzin_cr_person 	 group by hdr_primary_key having count(1) > 1 union 
select 'mzin_dad_person' 	as tbl_name, hdr_primary_key from mzin.mzin_dad_person 	 group by hdr_primary_key having count(1) > 1 union 
select 'mzin_dis_person' 	as tbl_name, hdr_primary_key from mzin.mzin_dis_person 	 group by hdr_primary_key having count(1) > 1 union 
select 'mzin_dss_person' 	as tbl_name, hdr_primary_key from mzin.mzin_dss_person 	 group by hdr_primary_key having count(1) > 1 union 
select 'mzin_ed_person' 	as tbl_name, hdr_primary_key from mzin.mzin_ed_person 	 group by hdr_primary_key having count(1) > 1 union 
select 'mzin_nafp_person' 	as tbl_name, hdr_primary_key from mzin.mzin_nafp_person  group by hdr_primary_key having count(1) > 1 union 
select 'mzin_dad_provider' 	as tbl_name, hdr_primary_key from mzin.mzin_dad_provider group by hdr_primary_key having count(1) > 1 union 
select 'mzin_dis_provider' 	as tbl_name, hdr_primary_key from mzin.mzin_dis_provider group by hdr_primary_key having count(1) > 1 union 
select 'mzin_dss_provider' 	as tbl_name, hdr_primary_key from mzin.mzin_dss_provider group by hdr_primary_key having count(1) > 1 union 
select 'mzin_ed_provider' 	as tbl_name, hdr_primary_key from mzin.mzin_ed_provider  group by hdr_primary_key having count(1) > 1 union 
select 'mzin_pr_provider' 	as tbl_name, hdr_primary_key from mzin.mzin_pr_provider  group by hdr_primary_key having count(1) > 1  

-- COMMAND ----------


select 'mzin_cr_person' 	as tbl_name, count(1) as cnt from mzin.mzin_cr_person 	 where code is null union 
select 'mzin_dad_person' 	as tbl_name, count(1) as cnt from mzin.mzin_dad_person 	 where code is null union 
select 'mzin_dis_person' 	as tbl_name, count(1) as cnt from mzin.mzin_dis_person 	 where code is null union 
select 'mzin_dss_person' 	as tbl_name, count(1) as cnt from mzin.mzin_dss_person 	 where code is null union 
select 'mzin_ed_person' 	as tbl_name, count(1) as cnt from mzin.mzin_ed_person 	 where code is null union 
select 'mzin_nafp_person' 	as tbl_name, count(1) as cnt from mzin.mzin_nafp_person  where code is null union 
select 'mzin_dad_provider' 	as tbl_name, count(1) as cnt from mzin.mzin_dad_provider where code is null union 
select 'mzin_dis_provider' 	as tbl_name, count(1) as cnt from mzin.mzin_dis_provider where code is null union 
select 'mzin_dss_provider' 	as tbl_name, count(1) as cnt from mzin.mzin_dss_provider where code is null union 
select 'mzin_ed_provider' 	as tbl_name, count(1) as cnt from mzin.mzin_ed_provider  where code is null union 
select 'mzin_pr_provider' 	as tbl_name, count(1) as cnt from mzin.mzin_pr_provider  where code is null  

-- COMMAND ----------


							
select 'mzin_cr_person' 	as tbl_name, count(1) as cnt from mzin.mzin_cr_person 	 where hdr_primary_key is null union 
select 'mzin_dad_person' 	as tbl_name, count(1) as cnt from mzin.mzin_dad_person 	 where hdr_primary_key is null union 
select 'mzin_dis_person' 	as tbl_name, count(1) as cnt from mzin.mzin_dis_person 	 where hdr_primary_key is null union 
select 'mzin_dss_person' 	as tbl_name, count(1) as cnt from mzin.mzin_dss_person 	 where hdr_primary_key is null union 
select 'mzin_ed_person' 	as tbl_name, count(1) as cnt from mzin.mzin_ed_person 	 where hdr_primary_key is null union 
select 'mzin_nafp_person' 	as tbl_name, count(1) as cnt from mzin.mzin_nafp_person  where hdr_primary_key is null union 
select 'mzin_dad_provider' 	as tbl_name, count(1) as cnt from mzin.mzin_dad_provider where hdr_primary_key is null union 
select 'mzin_dis_provider' 	as tbl_name, count(1) as cnt from mzin.mzin_dis_provider where hdr_primary_key is null union 
select 'mzin_dss_provider' 	as tbl_name, count(1) as cnt from mzin.mzin_dss_provider where hdr_primary_key is null union 
select 'mzin_ed_provider' 	as tbl_name, count(1) as cnt from mzin.mzin_ed_provider  where hdr_primary_key is null union 
select 'mzin_pr_provider' 	as tbl_name, count(1) as cnt from mzin.mzin_pr_provider  where hdr_primary_key is null  
