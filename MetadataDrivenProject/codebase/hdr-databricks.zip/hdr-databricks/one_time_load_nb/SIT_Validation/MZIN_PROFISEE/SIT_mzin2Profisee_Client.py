# Databricks notebook source
# DBTITLE 1,Importing modules
import json
import datacompy

# COMMAND ----------

dbutils.widgets.text('Environment','')
Environment=dbutils.widgets.get('Environment')

# COMMAND ----------

if Environment=='DEV':
    storage="sthdrcurzonedevtest"
else:
    storage="sthdrcurzoneprd"

# COMMAND ----------

# DBTITLE 1,Function to read table from profisee
def read_profisee(Table_name):
    config_path=f"/dbfs/mnt/{storage}/ds_config/config.txt"
    with open(config_path, 'r') as s:
            result=json.load(s)
    kv_scope=result[f"{Environment}"]["kvscope"]
    con_secret=result[f"{Environment}"]["SecretName"]
    jdbcurl=dbutils.secrets.get(scope=kv_scope,key=con_secret)
    return spark.read.jdbc(url=jdbcurl, table=Table_name)
    

# COMMAND ----------

# DBTITLE 1,Validate [stg].tDAD_client_Merge
#####Creation of views#####
with open(f"/dbfs/mnt/{storage}/trans_script/2_mzin_Profisee/tdad_client_merge.txt", "r") as trans_script:
        words = trans_script.read()
spark.sql(words).createOrReplaceTempView("InputDataTable")
read_profisee("[stg].tDAD_Client_Merge").createOrReplaceTempView("ProfiseeDataTable")

#####Count Check#####
InputDataCount=spark.sql("select count(*) from InputDataTable").collect()[0][0]
ProfiseeDataCount=spark.sql("select count(*) from ProfiseeDataTable").collect()[0][0]
print("Both the counts should match ",InputDataCount," ",ProfiseeDataCount)

#####Null Check######
NullCount=spark.sql("select count(*) from ProfiseeDataTable where code is null").collect()[0][0]
print("Null count is ",NullCount)

#####Dup Count#####
DupCheckCount=spark.sql("select count(*) from (select count(*) from ProfiseeDataTable group by code having count(1)>1)").collect()[0][0]
print("Number of duplicate records present in profisee table is ",DupCheckCount," Ideally it should be 0")
df1=spark.table("InputDataTable")
df2=spark.table("ProfiseeDataTable")
comparison = datacompy.SparkCompare(spark, df1, df2, join_columns = ["code"],show_all_columns=True,match_rates=True)
display(comparison.report())


# COMMAND ----------

result_file_path=f"/dbfs/mnt/{storage}sit/comparison_result/mzin_profisee_compare_res/tdad_provider_merge.txt"
with open(result_file_path, 'w') as report_file:
    comparison.report(file=report_file)

# COMMAND ----------

# DBTITLE 1,Validate [stg].tDSS_Client_Merge
#####Creation of views#####
with open(f"/dbfs/mnt/{storage}/trans_script/2_mzin_Profisee/tdss_client_merge.txt", "r") as trans_script:
        words = trans_script.read()
spark.sql(words).createOrReplaceTempView("InputDataTable")
read_profisee("[stg].tDSS_Client_Merge").createOrReplaceTempView("ProfiseeDataTable")

#####Count Check#####
InputDataCount=spark.sql("select count(*) from InputDataTable").collect()[0][0]
ProfiseeDataCount=spark.sql("select count(*) from ProfiseeDataTable").collect()[0][0]
print("Both the counts should match ",InputDataCount," ",ProfiseeDataCount)

#####Null Check######
NullCount=spark.sql("select count(*) from ProfiseeDataTable where code is null").collect()[0][0]
print("Null count is ",NullCount)

#####Dup Count#####
DupCheckCount=spark.sql("select count(*) from (select count(*) from ProfiseeDataTable group by code having count(1)>1)").collect()[0][0]
print("Number of duplicate records present in profisee table is ",DupCheckCount," Ideally it should be 0")
df1=spark.table("InputDataTable")
df2=spark.table("ProfiseeDataTable")
comparison = datacompy.SparkCompare(spark, df1, df2, join_columns = ["code"],show_all_columns=True,match_rates=True)
display(comparison.report())


# COMMAND ----------

# DBTITLE 1,Validate [stg].tCR_client_Merge
#####Creation of views#####
with open(f"/dbfs/mnt/{storage}/trans_script/2_mzin_Profisee/tcr_client_merge.txt", "r") as trans_script:
        words = trans_script.read()
spark.sql(words).createOrReplaceTempView("InputDataTable")
read_profisee("[stg].tCR_Client_Merge").createOrReplaceTempView("ProfiseeDataTable")

#####Count Check#####
InputDataCount=spark.sql("select count(*) from InputDataTable").collect()[0][0]
ProfiseeDataCount=spark.sql("select count(*) from ProfiseeDataTable").collect()[0][0]
print("Both the counts should match ",InputDataCount," ",ProfiseeDataCount)

#####Null Check######
NullCount=spark.sql("select count(*) from ProfiseeDataTable where code is null").collect()[0][0]
print("Null count is ",NullCount)

#####Dup Count#####
DupCheckCount=spark.sql("select count(*) from (select count(*) from ProfiseeDataTable group by code having count(1)>1)").collect()[0][0]
print("Number of duplicate records present in profisee table is ",DupCheckCount," Ideally it should be 0")
df1=spark.table("InputDataTable")
df2=spark.table("ProfiseeDataTable")
comparison = datacompy.SparkCompare(spark, df1, df2, join_columns = ["code"],show_all_columns=True,match_rates=True)
display(comparison.report())


# COMMAND ----------

# DBTITLE 1,Validate [stg].tDIS_client_Merge
#####Creation of views#####
with open(f"/dbfs/mnt/{storage}/trans_script/2_mzin_Profisee/tdis_client_merge.txt", "r") as trans_script:
        words = trans_script.read()
spark.sql(words).createOrReplaceTempView("InputDataTable")
read_profisee("[stg].tDIS_Client_Merge").createOrReplaceTempView("ProfiseeDataTable")

#####Count Check#####
InputDataCount=spark.sql("select count(*) from InputDataTable").collect()[0][0]
ProfiseeDataCount=spark.sql("select count(*) from ProfiseeDataTable").collect()[0][0]
print("Both the counts should match ",InputDataCount," ",ProfiseeDataCount)

#####Null Check######
NullCount=spark.sql("select count(*) from ProfiseeDataTable where code is null").collect()[0][0]
print("Null count is ",NullCount)

#####Dup Count#####
DupCheckCount=spark.sql("select count(*) from (select count(*) from ProfiseeDataTable group by code having count(1)>1)").collect()[0][0]
print("Number of duplicate records present in profisee table is ",DupCheckCount," Ideally it should be 0")
df1=spark.table("InputDataTable")
df2=spark.table("ProfiseeDataTable")
comparison = datacompy.SparkCompare(spark, df1, df2, join_columns = ["code"],show_all_columns=True,match_rates=True)
display(comparison.report())


# COMMAND ----------

# DBTITLE 1,Validate [stg].tED_client_Merge
#####Creation of views#####
with open(f"/dbfs/mnt/{storage}/trans_script/2_mzin_Profisee/ted_client_merge.txt", "r") as trans_script:
        words = trans_script.read()
spark.sql(words).createOrReplaceTempView("InputDataTable")
read_profisee("[stg].tED_Client_Merge").createOrReplaceTempView("ProfiseeDataTable")

#####Count Check#####
InputDataCount=spark.sql("select count(*) from InputDataTable").collect()[0][0]
ProfiseeDataCount=spark.sql("select count(*) from ProfiseeDataTable").collect()[0][0]
print("Both the counts should match ",InputDataCount," ",ProfiseeDataCount)

#####Null Check######
NullCount=spark.sql("select count(*) from ProfiseeDataTable where code is null").collect()[0][0]
print("Null count is ",NullCount)

#####Dup Count#####
DupCheckCount=spark.sql("select count(*) from (select count(*) from ProfiseeDataTable group by code having count(1)>1)").collect()[0][0]
print("Number of duplicate records present in profisee table is ",DupCheckCount," Ideally it should be 0")
df1=spark.table("InputDataTable")
df2=spark.table("ProfiseeDataTable")
comparison = datacompy.SparkCompare(spark, df1, df2, join_columns = ["code"],show_all_columns=True,match_rates=True)
display(comparison.report())


# COMMAND ----------

# DBTITLE 1,Validate [stg].tNAFP_client_Merge
#####Creation of views#####
with open(f"/dbfs/mnt/{storage}/trans_script/2_mzin_Profisee/tnafp_client_merge.txt", "r") as trans_script:
        words = trans_script.read()
spark.sql(words).createOrReplaceTempView("InputDataTable")
read_profisee("[stg].tNAFP_Client_Merge").createOrReplaceTempView("ProfiseeDataTable")

#####Count Check#####
InputDataCount=spark.sql("select count(*) from InputDataTable").collect()[0][0]
ProfiseeDataCount=spark.sql("select count(*) from ProfiseeDataTable").collect()[0][0]
print("Both the counts should match ",InputDataCount," ",ProfiseeDataCount)

#####Null Check######
NullCount=spark.sql("select count(*) from ProfiseeDataTable where code is null").collect()[0][0]
print("Null count is ",NullCount)

#####Dup Count#####
DupCheckCount=spark.sql("select count(*) from (select count(*) from ProfiseeDataTable group by code having count(1)>1)").collect()[0][0]
print("Number of duplicate records present in profisee table is ",DupCheckCount," Ideally it should be 0")
df1=spark.table("InputDataTable")
df2=spark.table("ProfiseeDataTable")
comparison = datacompy.SparkCompare(spark, df1, df2, join_columns = ["code"],show_all_columns=True,match_rates=True)
display(comparison.report())


# COMMAND ----------

