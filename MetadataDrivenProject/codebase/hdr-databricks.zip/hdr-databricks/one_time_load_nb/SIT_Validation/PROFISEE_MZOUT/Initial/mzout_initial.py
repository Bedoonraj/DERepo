# Databricks notebook source
from pyspark.sql.functions import concat_ws,hash,sha2
import datacompy
import json,re,os
import os

# COMMAND ----------

dbutils.widgets.text('Trans_Script_Path','')
Trans_Script_Path=dbutils.widgets.get('Trans_Script_Path')

dbutils.widgets.text('Schema_Name','')
Schema_Name=dbutils.widgets.get('Schema_Name')

dbutils.widgets.text('Table_Name','')
Table_Name=dbutils.widgets.get('Table_Name')

Table=Schema_Name+'.'+Table_Name
Trans_Script_Path=Trans_Script_Path+Table_Name+'.txt'

dbutils.widgets.text('Environment','')
Environment=dbutils.widgets.get('Environment')

# COMMAND ----------

if Environment=='DEV':
    storage="sthdrcurzonedevtest"
else:
    storage="sthdrcurzoneprd"

# COMMAND ----------

def df_format_columns(df):
    char_to_replace = {'\.':'_','\$':''}
    col_dict={}
    for col_name in df.columns:
        col_renamed = col_name
        col_renamed = col_renamed.translate({ord(c): "" for c in "()"})
        for key, value in char_to_replace.items():
            col_renamed = re.sub(r"{}".format(key), value, col_renamed)
        df = df.withColumnRenamed(col_name, col_renamed)
    return df

# COMMAND ----------

def profiseeTableasView(Table_name):
    config_path=f"/dbfs/mnt/{storage}/ds_config/config.txt"
    with open(config_path, 'r') as s:
            result=json.load(s)
    kv_scope=result[f"{Environment}"]["kvscope"]
    con_secret=result[f"{Environment}"]["SecretName"]
    jdbcurl=dbutils.secrets.get(scope=kv_scope,key=con_secret)
    lastloaddate='1900-01-01'
    query=f"select * from {Table_name} where lastchgdtm>'{lastloaddate}'"
    #return df_format_columns(spark.read.jdbc(url=jdbcurl, table=Table_name)).createOrReplaceTempView(Table_name.replace("data.", ""))
    return df_format_columns(spark.read.format('jdbc').option('query',query).option('url',jdbcurl).load()).createOrReplaceTempView(Table_name.replace("data.", ""))

# COMMAND ----------

profiseeTableasView("data.vaddress")
profiseeTableasView("data.vprovider")
profiseeTableasView("data.vclient")

# COMMAND ----------

# MAGIC %sql
# MAGIC select "vaddress",count(*) from vaddress
# MAGIC union
# MAGIC select "mout_address",count(*) from mzout.mzout_address

# COMMAND ----------

# MAGIC %sql
# MAGIC select "vclient",count(*) from vclient
# MAGIC union
# MAGIC select "mout_client",count(*) from mzout.mzout_client

# COMMAND ----------

# MAGIC %sql
# MAGIC select "vprovider",count(*) from vprovider
# MAGIC union
# MAGIC select "mout_provider",count(*) from mzout.mzout_provider

# COMMAND ----------

# DBTITLE 1,duplicate check for mzout tables
# MAGIC %sql
# MAGIC select 'mzout_address',count(code) from mzout.mzout_address group by code having count(code)>1
# MAGIC union
# MAGIC select 'mzout_client',count(code) from mzout.mzout_client group by code having count(code)>1
# MAGIC union
# MAGIC select 'mzout_provider',count(code) from mzout.mzout_provider group by code having count(code)>1

# COMMAND ----------

# DBTITLE 1,null check
# MAGIC %sql
# MAGIC select 'mzout_address',count(*) from mzout.mzout_address where id is null or code is null
# MAGIC union
# MAGIC select 'mzout_client',count(*) from mzout.mzout_client where id is null or code is null
# MAGIC union
# MAGIC select 'mzout_provider',count(*) from mzout.mzout_provider where id is null or code is null

# COMMAND ----------

# DBTITLE 1,proposed matches
# MAGIC %sql
# MAGIC select count(*) from mzout.mzout_Provider_2407 where mdm_MatchStatus_Name = 'Proposed'
# MAGIC Union 
# MAGIC select count(*) from mzout.mzout_Client_2407 where mdm_MatchStatus_Name = 'Proposed'