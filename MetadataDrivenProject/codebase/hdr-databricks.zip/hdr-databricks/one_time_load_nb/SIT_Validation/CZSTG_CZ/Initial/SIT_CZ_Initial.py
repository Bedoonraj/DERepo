# Databricks notebook source
dbutils.widgets.text('Environment','')
Environment=dbutils.widgets.get('Environment')

# COMMAND ----------

if Environment=='DEV':
    storage="sthdrcurzonedevtest"
else:
    storage="sthdrcurzoneprd"

# COMMAND ----------

# DBTITLE 1,Location
String2bReplaced="coalesce((select lastloaddatetime from adf_config.adf_datasetlog where upper(datasetname) = upper('location')), '1900-01-01')"
ReplacedString="'1900-01-01 00:00:00.000'"
with open(f"/dbfs/mnt/{storage}/trans_script/6_czstg_cz/location.txt", "r") as trans_script:
        words = trans_script.read()
        words=words.replace(String2bReplaced, ReplacedString)
spark.sql(words).createOrReplaceTempView("InputDataTable")

# COMMAND ----------

##Count_Check
InputDataCount=spark.sql("select count(*) from InputDataTable").collect()[0][0]
cz_location=spark.sql("select count(*) from cz.location").collect()[0][0]
print("Both the counts should match ",InputDataCount," ",cz_location)

# COMMAND ----------

with open(f"/dbfs/mnt/{storage}/trans_script/6_czstg_cz/location_unverified_cz.txt", "r") as trans_script:
        words = trans_script.read()
spark.sql(words).createOrReplaceTempView("Input_DataTable")
##Count_Check
Input_DataCount=spark.sql("select count(*) from Input_DataTable").collect()[0][0]
Count_From_Location=spark.sql("select count(*) from cz.location").collect()[0][0]
print("Both the counts should match ",Input_DataCount,Count_From_Location)

# COMMAND ----------

1300763-654803


# COMMAND ----------

# DBTITLE 1,dup check for location
##Duplicate_Check
duplicate_check=spark.sql("Select distinct source_keyattr,address_1,address_2,city,state,zip,county,location_source_value,country_concept_id,country_source_value,lattitude,longitude from cz.location").count()
Original_count=spark.sql("Select * from cz.location").count()
print("Original count",Original_count,"Duplicate count",duplicate_check,"Count should match if there is no duplicate")

# COMMAND ----------

# DBTITLE 1,dup check for location
# MAGIC %sql
# MAGIC select location_id ,count(*) from cz.location group by 1 having count(1)>1

# COMMAND ----------

# DBTITLE 1,Null check for location
##Null Check
null_check=spark.sql("select * from cz.location where address_1 is null").count()
print(null_check)

# COMMAND ----------

##Null Check
null_check=spark.sql("select * from cz.location where lattitude is null and longitude is null").count()
print(null_check)

# COMMAND ----------

# DBTITLE 1,Person
##person count check
String2bReplaced=f"coalesce((select lastloaddatetime from adf_config.adf_datasetlog where upper(datasetname) = upper('person')), '1900-01-01')"
ReplacedString="'1900-01-01 00:00:00.000'"
with open(f"/dbfs/mnt/{storage}/trans_script/6_czstg_cz/person.txt", "r") as trans_script:
        words = trans_script.read()
        words=words.replace(String2bReplaced, ReplacedString)
spark.sql(words).createOrReplaceTempView("InputDataTable")
##Count_Check
InputDataCount=spark.sql("select count(*) from InputDataTable").collect()[0][0]
cz_person=spark.sql("select count(*) from cz.person").collect()[0][0]
print("Both the counts should match ",InputDataCount," ",cz_person)

# COMMAND ----------

# DBTITLE 1,person dup check
# MAGIC %sql
# MAGIC select person_id from cz.person group by person_id having count(person_id)>1

# COMMAND ----------

# MAGIC %sql
# MAGIC select person_source_value from cz.person group by person_source_value having count(person_source_value)>1

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(person_id) from cz.person group by person_id having count(person_id)>1

# COMMAND ----------

# DBTITLE 1,Death
##death count check
String2bReplaced=f"coalesce((select lastloaddatetime from adf_config.adf_datasetlog where upper(datasetname) = upper('death')), '1900-01-01')"
ReplacedString="'1900-01-01 00:00:00.000'"
with open(f"/dbfs/mnt/{storage}/trans_script/6_czstg_cz/death.txt", "r") as trans_script:
        words = trans_script.read()
        words=words.replace(String2bReplaced, ReplacedString)
spark.sql(words).createOrReplaceTempView("InputDataTable")
##Count_Check
InputDataCount=spark.sql("select count(*) from InputDataTable").collect()[0][0]
cz_death=spark.sql("select count(*) from cz.death").collect()[0][0]
print("Both the counts should match ",InputDataCount," ",cz_death)

# COMMAND ----------

# DBTITLE 1,count check for death
# MAGIC %sql
# MAGIC select "cz.death",count(*) from cz.death
# MAGIC union
# MAGIC select "czstg.cz_person_stg",count(*) from czstg.cz_person_stg where death_date is not null and _is_active='Y'
# MAGIC

# COMMAND ----------

# DBTITLE 1,null check
# MAGIC
# MAGIC %sql
# MAGIC select * from cz.death where death_date is null or death_datetime is null or isDeleted is null
# MAGIC

# COMMAND ----------

# DBTITLE 1,DQ check for death
# MAGIC %sql
# MAGIC SELECT * FROM cz.death where person_id like '% ' or person_id like ' %'
# MAGIC union
# MAGIC SELECT * FROM cz.death where death_date like '% ' or death_date like ' %'
# MAGIC union
# MAGIC SELECT * FROM cz.death where death_datetime like '% ' or death_datetime like ' %'
# MAGIC union
# MAGIC SELECT * FROM cz.death where cause_concept_id like '% ' or cause_concept_id like ' %'
# MAGIC union
# MAGIC SELECT * FROM cz.death where cause_source_value like '% ' or cause_source_value like ' %'
# MAGIC union
# MAGIC SELECT * FROM cz.death where cause_source_concept_id like '% ' or cause_source_concept_id like ' %'
# MAGIC UNION
# MAGIC SELECT * FROM cz.death where isDeleted like '% ' or isDeleted like ' %'

# COMMAND ----------

# DBTITLE 1,dup check
# MAGIC %sql
# MAGIC select count(person_id) from cz.death group by person_id having count(person_id)>1
# MAGIC union
# MAGIC select count(person_id) from cz.person group by person_id having count(person_id)>1

# COMMAND ----------

# DBTITLE 1,Provider
##provider count check
String2bReplaced=f"coalesce((select lastloaddatetime from adf_config.adf_datasetlog where upper(datasetname) = upper('provider')), '1900-01-01')"
ReplacedString="'1900-01-01 00:00:00.000'"
with open(f"/dbfs/mnt/{storage}/trans_script/6_czstg_cz/provider.txt", "r") as trans_script:
        words = trans_script.read()
        words=words.replace(String2bReplaced, ReplacedString)
spark.sql(words).createOrReplaceTempView("InputDataTable")
##Count_Check
InputDataCount=spark.sql("select count(*) from InputDataTable").collect()[0][0]
cz_provider=spark.sql("select count(*) from cz.provider").collect()[0][0]
print("Both the counts should match ",InputDataCount," ",cz_provider)

# COMMAND ----------

# DBTITLE 1,provider dup check
# MAGIC %sql
# MAGIC select 'cz_provider',count(provider_id) from cz.provider group by provider_id having count(provider_id)>1

# COMMAND ----------

# DBTITLE 1,count check for provider
# MAGIC %sql
# MAGIC select 'cz_provider_stg',count(*) from czstg.cz_provider_stg where _is_active='Y'
# MAGIC union 
# MAGIC select 'cz_provider',count(*) from cz.provider

# COMMAND ----------

# DBTITLE 1,provider null check
# MAGIC %sql
# MAGIC --select 'cz_provider',count(provider_id) from cz.provider where provider_id is null
# MAGIC select 'cz_provider',count(provider_name) from cz.provider where provider_name is null

# COMMAND ----------

# DBTITLE 1,DQ check for provider
# MAGIC %sql
# MAGIC SELECT 'provider_name',MAX (LEN (provider_name))  FROM cz.provider
# MAGIC union
# MAGIC SELECT 'npi',MAX (LEN (npi))  FROM cz.provider
# MAGIC union
# MAGIC SELECT 'dea',MAX (LEN (dea))  FROM cz.provider
# MAGIC union
# MAGIC SELECT 'speciality_concept_id',MAX (LEN (speciality_concept_id))  FROM cz.provider
# MAGIC union
# MAGIC SELECT 'care_site_id',MAX (LEN (care_site_id))  FROM cz.provider
# MAGIC union
# MAGIC SELECT 'year_of_birth',MAX (LEN (year_of_birth))  FROM cz.provider
# MAGIC union
# MAGIC SELECT 'gender_concept_id',MAX (LEN (gender_concept_id))  FROM cz.provider
# MAGIC union
# MAGIC SELECT 'provider_source_value',MAX (LEN (provider_source_value))  FROM cz.provider
# MAGIC --union
# MAGIC --SELECT 'specialty_source_concept_id',MAX (LEN (specialty_source_concept_id))  FROM cz.provider
# MAGIC union
# MAGIC SELECT 'gender_source_value',MAX (LEN (gender_source_value))  FROM cz.provider
# MAGIC union
# MAGIC SELECT 'gender_source_concept_id',MAX (LEN (gender_source_concept_id))  FROM cz.provider
# MAGIC union
# MAGIC SELECT 'isdeleted',MAX (LEN (isdeleted))  FROM cz.provider
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(provider_id) from cz.provider group by provider_id having count(provider_id)>1

# COMMAND ----------

# DBTITLE 1,Location_History count check
# MAGIC %sql
# MAGIC select count(1) from czstg.cz_person_stg 
# MAGIC where _is_active = 'Y' and location_id is not null
# MAGIC
# MAGIC select count(1) from czstg.cz_provider_stg 
# MAGIC where _is_active = 'Y' and location_id is not null
# MAGIC
# MAGIC SELECT count(1)
# MAGIC FROM mzin.mzin_location_history_unverified lh
# MAGIC inner join czstg.cz_person_stg cps on lh.hoa_hcn = cps.health_card_number and cps._is_active = 'Y'
# MAGIC inner join cz.person p on cps.golden_record_code = p.person_source_value
# MAGIC inner join cz.location l on l.source_keyattr = lh.address_source_keyattr
# MAGIC
# MAGIC select count(1) from cz.location_history

# COMMAND ----------

# DBTITLE 1,null check
# MAGIC %sql
# MAGIC select count(1) from cz.location_history where location_id is null
# MAGIC select count(1) from cz.location_history where relationship_type_concept_id is null
# MAGIC select count(1) from cz.location_history where domain_id is null
# MAGIC select count(1) from cz.location_history where entity_id is null
# MAGIC select count(1) from cz.location_history where start_date  is null

# COMMAND ----------

# DBTITLE 1,dup check
# MAGIC %sql
# MAGIC select lh.location_id,relationship_type_concept_id, domain_id, entity_id, start_date
# MAGIC from cz.location_history lh
# MAGIC group by lh.location_id,relationship_type_concept_id, domain_id, entity_id, start_date
# MAGIC having count(1) > 1