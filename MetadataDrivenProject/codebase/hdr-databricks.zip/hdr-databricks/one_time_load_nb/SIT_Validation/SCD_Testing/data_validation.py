# Databricks notebook source
# DBTITLE 1,Import Configuration Notebook
# MAGIC %run /Repos/repo/hdr-databricks/one_time_load_nb/SIT_Validation/SCD_Testing/configuration

# COMMAND ----------

import warnings
import numpy as np
import datacompy
from datetime import datetime

current_datetime = datetime.now()
warnings.filterwarnings("ignore")

# Assuming you have already set up a SparkSession named 'spark'
# spark = SparkSession.builder.appName("YourAppName").getOrCreate()

def get_version_details(check_type, schema_name, table_name, scd):
    if check_type == "Before Insert":
        version_script_path = bfr_insrt_tbl_vrsn_scrpt_file_path
    else:
        version_script_path = aftr_insrt_tbl_vrsn_scrpt_file_path

    with open(version_script_path, 'r') as file:
        content = file.read()

    version_script = content.replace("schemaname", schema_name).replace("tablename", table_name).replace("@scd", str(scd))
    df_version_detail = spark.sql(version_script)
    return df_version_detail.toPandas()


def get_table_row_count(schema_name, table_name, scd):
    row_count_script_path = tbl_row_count_scrpt_file_path
    with open(row_count_script_path, 'r') as file:
        content = file.read()

    row_count_script = content.replace("schemaname", schema_name).replace("tablename", table_name).replace("@scd", str(scd))
    df_rowcount = spark.sql(row_count_script)
    return df_rowcount.toPandas()


def get_scd_validation(check_type, schema_name, table_name, trnsfrmtn_script_path, tbl_script, input_datetime, join_columns, scd):
    tbl_version_dtl = get_version_details(check_type, schema_name, table_name, scd)
    tbl_version = tbl_version_dtl['version'][0]
    is_deleted = 0
    tbl_row_count = get_table_row_count(schema_name, table_name, scd)

    with open(trnsfrmtn_script_path, 'r') as file:
        trnsfrmtn_script = file.read()

    trnsfrmtn_script = trnsfrmtn_script.replace("@input_datetime", "'" + input_datetime + "'" )
    tbl_script = tbl_script.replace("@version", str(tbl_version)) + ";"

    df1 = spark.sql(trnsfrmtn_script).toPandas()
    df2 = spark.sql(tbl_script).toPandas()

    df1 = df1.replace(np.NaN, 0).replace(0, None)
    df2 = df2.replace(np.NaN, 0).replace(0, None)
    df1.fillna("", inplace=True)
    df2.fillna("", inplace=True)

    compare = datacompy.Compare(df1, df2, join_columns=join_columns, abs_tol=0, rel_tol=0, df1_name='Source', df2_name='Target')

    if scd == 2:
        df_mismatch = compare.all_mismatch(ignore_matching_cols=False)
        is_deleted = len(df_mismatch[df_mismatch["_is_active_df2"] == "N"])

    filename = schema_name + '_' + table_name +  '_' + current_datetime.strftime('%Y%m%d%H%M%S') + '.txt'
    filepath = comparison_result_folder_path + schema_name + '_' + table_name  + '\\'
   
    with open(filepath + filename, "w") as f:
        f.write("Input Datetime: " + input_datetime)
        f.write("\n\n")
        f.write(compare.report(sample_count=10, column_count=10))

    if check_type == "Before Insert":
        df_result = pd.DataFrame({"table": table_name,
                                  "scd_type": scd,
                                  "current_version": tbl_version_dtl['version'][0],
                                  "RowToBeInserted": compare.df1_unq_rows.shape[0] + is_deleted,
                                  "RowToBeUpdated": compare.all_mismatch(ignore_matching_cols=False).shape[0] - is_deleted
                                  }, index=[0])
    else:
        df_result = pd.DataFrame({"table": table_name,
                                  "scd_type": scd,
                                  "current_version": tbl_version_dtl['current_version'][0],
                                  "RowToBeInserted": compare.df1_unq_rows.shape[0] + is_deleted,
                                  "RowToBeUpdated": compare.all_mismatch(ignore_matching_cols=False).shape[0] - is_deleted,
                                  "TblHisRowsInserted": tbl_version_dtl['RowsInserted'][0],
                                  "TblHisRowsUpdated": tbl_version_dtl['RowsUpdated'][0],
                                  "TblHisRowsDeleted": tbl_version_dtl['RowsDeleted'][0],
                                  "RowsInserted": tbl_row_count['rows_inserted'][0],
                                  "RowsUpdated": tbl_row_count['rows_updated'][0],
                                  }, index=[0])
    return df_result
