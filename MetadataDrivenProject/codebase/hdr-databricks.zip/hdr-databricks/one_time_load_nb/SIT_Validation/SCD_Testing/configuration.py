# Databricks notebook source
#Configuration path needs to be updated in below Notebooks
# 1. table_scd_validation notebook
# 2. data_validation notebook

#Last Load Date needs to be updated before load 
ip_cr_address_ledt              = "1900-01-01"
ip_dss_address_ledt             = "1900-01-01"
ip_nafp_address_ledt            = "1900-01-01"
ip_nscaf_address_ledt           = "1900-01-01"
ip_pr_address_ledt              = "1900-01-01"
ip_ed_person_ledt               = "1900-01-01"
ip_cr_person_ledt               = "1900-01-01"
ip_dad_person_ledt              = "1900-01-01"
ip_dis_person_ledt              = "1900-01-01"
ip_dss_person_ledt              = "1900-01-01"
ip_nafp_person_ledt             = "1900-01-01"
ip_dad_provider_ledt            = "1900-01-01"
ip_dis_provider_ledt            = "1900-01-01"
ip_dss_provider_ledt            = "1900-01-01"
ip_ed_provider_ledt             = "1900-01-01"
ip_pr_provider_ledt             = "1900-01-01"
ip_address_stg_ledt             = "1900-01-01"
ip_location_ledt                = "1900-01-01"
ip_person_stg_ledt              = "1900-01-01"
ip_person_xwalk_ext_ledt        = "1900-01-01"
ip_provider_stg_ledt            = "1900-01-01"
ip_provider_xwalk_ext_ledt      = "1900-01-01"
ip_location_history_ledt        = "1900-01-01"
ip_death_ledt                   = "1900-01-01"
ip_person_ledt                  = "1900-01-01"
ip_provider_ledt                = "1900-01-01"
ip_provider_license_ext_ledt    = "1900-01-01"
ip_provider_speciality_ext_ledt = "1900-01-01"

#File Path
#DEV
bfr_insrt_tbl_vrsn_scrpt_file_path = '/dbfs/mnt/sthdrcurzonedevtest/sit/python_scripts/before_run_version.txt'
aftr_insrt_tbl_vrsn_scrpt_file_path = '/dbfs/mnt/sthdrcurzonedevtest/sit/python_scripts/after_run_version.txt'
tbl_row_count_scrpt_file_path = '/dbfs/mnt/sthdrcurzonedevtest/sit/python_scripts/table_row_count.txt'
comparison_result_folder_path = '/dbfs/mnt/sthdrcurzonedevtest/sit/python_scripts/ComparisonResult/'

#PROD
"""
bfr_insrt_tbl_vrsn_scrpt_file_path = '/dbfs/mnt/sthdrcurzonedevtest/sit/python_scripts/before_run_version.txt'
aftr_insrt_tbl_vrsn_scrpt_file_path = '/dbfs/mnt/sthdrcurzonedevtest/sit/python_scripts/after_run_version.txt'
tbl_row_count_scrpt_file_path = '/dbfs/mnt/sthdrcurzonedevtest/sit/python_scripts/table_row_count.txt'
comparison_result_folder_path = '/dbfs/mnt/sthdrcurzonedevtest/sit/python_scripts/ComparisonResult/'
"""
