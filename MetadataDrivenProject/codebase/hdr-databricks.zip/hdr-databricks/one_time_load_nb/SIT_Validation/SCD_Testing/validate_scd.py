# Databricks notebook source
# DBTITLE 1,Declaration
DEV_FLAG=False
if DEV_FLAG:
    trnsfrmtn_script_base_path = r'/dbfs/mnt/sthdrcurzonedevtest/sit/python_scripts/'
else:
    trnsfrmtn_script_base_path = r'/dbfs/mnt/sthdrcurzoneprd/sit/python_scripts/'

# COMMAND ----------

# DBTITLE 1,Import Notebook
# MAGIC %run /Repos/repo/hdr-databricks/one_time_load_nb/SIT_Validation/SCD_Testing/data_validation

# COMMAND ----------

# DBTITLE 1,MZIN cr_address
def validate_cr_address_scd(check_type, input_datetime):
    tbl_script = f"SELECT source_keyattr, code, name, mailaddress1, mailaddress2, mailcity, mailprovince, " \
                 f"mailpostalcode, mailcountry, mdm_recordsource, isdeleted " \
                 f"FROM mzin.mzin_cr_address version as of @version "

    schema_name = "mzin"
    table_name = "mzin_cr_address"
    trnsfrmtn_script_path =  trnsfrmtn_script_base_path + 'mzin_cr_address.txt'
    join_columns = "source_keyattr"

    result = get_scd_validation(check_type, schema_name, table_name, trnsfrmtn_script_path, tbl_script, input_datetime, join_columns, 1)

    return result

# COMMAND ----------

# DBTITLE 1,MZIN dss_address
def validate_dss_address_scd(check_type, input_datetime):
    tbl_script = f"SELECT source_keyattr, code, name, address_line_1, address_line_2, city, province_code, " \
                 f"postal_code, country, mdm_recordsource, isdeleted " \
                 f"FROM mzin.mzin_dss_address version as of @version "

    schema_name = "mzin"
    table_name = "mzin_dss_address"
    trnsfrmtn_script_path =  trnsfrmtn_script_base_path + 'mzin_dss_address.txt'
    join_columns = "source_keyattr"

    result = get_scd_validation(check_type, schema_name, table_name, trnsfrmtn_script_path, tbl_script, input_datetime, join_columns, 1)

    return result

# COMMAND ----------

# DBTITLE 1,MZIN nafp_address
def validate_nafp_address_scd(check_type, input_datetime):
    tbl_script = f"SELECT source_keyattr, code, name, address, city, postalcode, zone_code, cluster_code, " \
                 f"network_code, mdm_recordsource, isdeleted " \
                 f"FROM mzin.mzin_nafp_address version as of @version "

    schema_name = "mzin"
    table_name = "mzin_nafp_address"
    trnsfrmtn_script_path =  trnsfrmtn_script_base_path + 'mzin_nafp_address.txt'
    join_columns = "source_keyattr"

    result = get_scd_validation(check_type, schema_name, table_name, trnsfrmtn_script_path, tbl_script, input_datetime, join_columns, 1)

    return result

# COMMAND ----------

# DBTITLE 1,MZIN nscaf_address
def validate_nscaf_address_scd(check_type, input_datetime):
    tbl_script = f"SELECT source_keyattr, code, name, zone_code, cluster_code, network_code, municipality_code, " \
                 f"civnid, mdm_RecordSource, mdm_stdaddressline1, comm, mdm_stdProvince, mdm_stdCountry, co_code, " \
                 f"postalcode, latitude, longitude, civicnum, strprefix, strname, strsuffix, strdir, unit_num, " \
                 f"mdm_verificationstatus, mdm_stdverificationresults, mdm_stdaddressverificationstatus, " \
                 f"mdm_StdMailingGeocodingStatus, isdeleted " \
                 f"FROM mzin.mzin_nscaf_address version as of @version "

    schema_name = "mzin"
    table_name = "mzin_nscaf_address"
    trnsfrmtn_script_path =  trnsfrmtn_script_base_path + 'mzin_nscaf_address.txt'
    join_columns = "source_keyattr"

    result = get_scd_validation(check_type, schema_name, table_name, trnsfrmtn_script_path, tbl_script, input_datetime, join_columns, 1)

    return result

# COMMAND ----------

# DBTITLE 1,MZIN pr_address
def validate_pr_address_scd(check_type, input_datetime):
    tbl_script = f"SELECT source_keyattr, code, name, addr_pr_stline1, addr_pr_stline2, addr_pr_stline3, " \
                 f"addr_pr_stline4, addr_pr_city, addr_pr_prov, addr_pr_postcd, addr_pr_ctry, mdm_recordsource, " \
                 f"isdeleted FROM mzin.mzin_pr_address version as of @version "

    schema_name = "mzin"
    table_name = "mzin_pr_address"
    trnsfrmtn_script_path =  trnsfrmtn_script_base_path + 'mzin_pr_address.txt'
    join_columns = "source_keyattr"

    result = get_scd_validation(check_type, schema_name, table_name, trnsfrmtn_script_path, tbl_script, input_datetime, join_columns, 1)

    return result

# COMMAND ----------

# DBTITLE 1,MZIN ed_person
def validate_ed_person_scd(check_type, input_datetime):
    tbl_script = f"SELECT source_keyattr, code, hcn, address_code, address_golden_record, addressline1, " \
                 f"addressline2, city, province, postalcode, `zone`, region, municipality, network, country, " \
                 f"gender_code, frailtyscore, hdr_primary_key, mdm_recordsource, isdeleted, " \
                 f"person_source_keyattr FROM mzin.mzin_ed_person version as of @version "

    schema_name = "mzin"
    table_name = "mzin_ed_person"
    trnsfrmtn_script_path =  trnsfrmtn_script_base_path + 'mzin_ed_person.txt'
    join_columns = "source_keyattr"

    result = get_scd_validation(check_type, schema_name, table_name, trnsfrmtn_script_path, tbl_script, input_datetime, join_columns, 1)

    return result

# COMMAND ----------

# DBTITLE 1,MZIN cr_person
def validate_cr_person_scd(check_type, input_datetime):
    tbl_script = f" SELECT source_keyattr, code, name, hcn, firstname, middlename, lastname, birthdate, address_code, address_golden_record, addressline1,   addressline2, city, province, postalcode, `zone`, region, municipality, network, country, gender_code, deathdate, hdr_primary_key, mdm_recordsource, isdeleted FROM mzin.mzin_cr_person version as of @version "

    schema_name = "mzin"
    table_name = "mzin_cr_person"
    trnsfrmtn_script_path =  trnsfrmtn_script_base_path + 'mzin_cr_person.txt'
    join_columns = "source_keyattr"

    result = get_scd_validation(check_type, schema_name, table_name, trnsfrmtn_script_path, tbl_script, input_datetime, join_columns, 1)

    return result

# COMMAND ----------

# DBTITLE 1,MZIN dad_person
def validate_dad_person_scd(check_type, input_datetime):
    tbl_script = f" SELECT source_keyattr, code, hcn, birth_date, postal_code, riw, racialized_groups, gender_code, hdr_primary_key, mdm_recordsource, isdeleted, person_source_keyattr FROM mzin.mzin_dad_person version as of @version "

    schema_name = "mzin"
    table_name = "mzin_dad_person"
    trnsfrmtn_script_path =  trnsfrmtn_script_base_path + 'mzin_dad_person.txt'
    join_columns = "source_keyattr"

    result = get_scd_validation(check_type, schema_name, table_name, trnsfrmtn_script_path, tbl_script, input_datetime, join_columns, 1)

    return result

# COMMAND ----------

# DBTITLE 1,MZIN dis_person
def validate_dis_person_scd(check_type, input_datetime):
    tbl_script = f"SELECT source_keyattr, code, name, identifier_value, first_name, middle_name, surname, date_of_birth, gender_code, hdr_primary_key, mdm_recordsource, isdeleted FROM mzin.mzin_dis_person version as of @version "

    schema_name = "mzin"
    table_name = "mzin_dis_person"
    trnsfrmtn_script_path =  trnsfrmtn_script_base_path + 'mzin_dis_person.txt'
    join_columns = "source_keyattr"

    result = get_scd_validation(check_type, schema_name, table_name, trnsfrmtn_script_path, tbl_script, input_datetime, join_columns, 1)

    return result

# COMMAND ----------

# DBTITLE 1,MZIN dss_person
def validate_dss_person_scd(check_type, input_datetime):
    tbl_script = f"SELECT source_keyattr, code, name, health_card_number, first_name, surname, date_of_birth, hcnexpirationdate, address_code, address_golden_record, addressline1, addressline2, city, province, postalcode, `zone`, region, municipality, network, country, gender_code, death_date, health_card_expiry_date, province_moved_from, province_moved_to, arrival_date, departure_date, addressdate, dssdate, hdr_primary_key, mdm_recordsource, isdeleted FROM mzin.mzin_dss_person version as of @version "

    schema_name = "mzin"
    table_name = "mzin_dss_person"
    trnsfrmtn_script_path =  trnsfrmtn_script_base_path + 'mzin_dss_person.txt'
    join_columns = "source_keyattr"

    result = get_scd_validation(check_type, schema_name, table_name, trnsfrmtn_script_path, tbl_script, input_datetime, join_columns, 1)

    return result

# COMMAND ----------

# DBTITLE 1,MZIN nafp_person
def validate_nafp_person_scd(check_type, input_datetime):
    tbl_script = f"SELECT source_keyattr, code, name, healthcardnumber, firstname, middlename, lastname, dateofbirth, address_code, address_golden_record, addressline1, addressline2, city, province, postalcode, `zone`, region, municipality, network, country, gender_code, hdr_primary_key, mdm_recordsource, isdeleted FROM mzin.mzin_nafp_person version as of @version "

    schema_name = "mzin"
    table_name = "mzin_nafp_person"
    trnsfrmtn_script_path =  trnsfrmtn_script_base_path + 'mzin_nafp_person.txt'
    join_columns = "source_keyattr"

    result = get_scd_validation(check_type, schema_name, table_name, trnsfrmtn_script_path, tbl_script, input_datetime, join_columns, 1)

    return result

# COMMAND ----------

# DBTITLE 1,MZIN dad_provider
def validate_dad_provider_scd(check_type, input_datetime):
    tbl_script = f" SELECT source_keyattr, code, provider_type_code, doctor, hdr_primary_key, mdm_recordsource, isdeleted, provider_source_keyattr FROM mzin.mzin_dad_provider version as of @version "

    schema_name = "mzin"
    table_name = "mzin_dad_provider"
    trnsfrmtn_script_path =  trnsfrmtn_script_base_path + 'mzin_dad_provider.txt'
    join_columns = "source_keyattr"

    result = get_scd_validation(check_type, schema_name, table_name, trnsfrmtn_script_path, tbl_script, input_datetime, join_columns, 1)

    return result

# COMMAND ----------

# DBTITLE 1,MZIN dis_provider
def validate_dis_provider_scd(check_type, input_datetime):
    tbl_script = f"SELECT source_keyattr, code, name, first_name, middle_name, license_name, provider_type_code, license_number, date_of_birth, gender_code, hdr_primary_key, mdm_recordsource, isdeleted FROM mzin.mzin_dis_provider version as of @version "

    schema_name = "mzin"
    table_name = "mzin_dis_provider"
    trnsfrmtn_script_path =  trnsfrmtn_script_base_path + 'mzin_dis_provider.txt'
    join_columns = "source_keyattr"

    result = get_scd_validation(check_type, schema_name, table_name, trnsfrmtn_script_path, tbl_script, input_datetime, join_columns, 1)

    return result

# COMMAND ----------

# DBTITLE 1,MZIN dss_provider
def validate_dss_provider_scd(check_type, input_datetime):
    tbl_script = f"SELECT source_keyattr, code, name, first_name, middle_name, last_name, provider_type_code, provider_license_number, birth_date, provider_number, specialty_code, gender_code, address_code, address_golden_record, addressline1, addressline2, city, province, postalcode, `zone`, region, municipality, network, country, phone_number, fax_number, hdr_primary_key, mdm_recordsource, isdeleted FROM mzin.mzin_dss_provider version as of @version "

    schema_name = "mzin"
    table_name = "mzin_dss_provider"
    trnsfrmtn_script_path =  trnsfrmtn_script_base_path + 'mzin_dss_provider.txt'
    join_columns = "source_keyattr"

    result = get_scd_validation(check_type, schema_name, table_name, trnsfrmtn_script_path, tbl_script, input_datetime, join_columns, 1)

    return result

# COMMAND ----------

# DBTITLE 1,MZIN ed_provider
def validate_ed_provider_scd(check_type, input_datetime):
    tbl_script = f"SELECT source_keyattr, code, name, firstname, middlename, lastname, provider_type_code, famprov, hdr_primary_key, mdm_recordsource, isdeleted, provider_source_keyattr FROM mzin.mzin_ed_provider version as of @version "

    schema_name = "mzin"
    table_name = "mzin_ed_provider"
    trnsfrmtn_script_path =  trnsfrmtn_script_base_path + 'mzin_ed_provider.txt'
    join_columns = "source_keyattr"

    result = get_scd_validation(check_type, schema_name, table_name, trnsfrmtn_script_path, tbl_script, input_datetime, join_columns, 1)

    return result

# COMMAND ----------

# DBTITLE 1,MZIN pr_provider
def validate_pr_provider_scd(check_type, input_datetime):
    tbl_script = f"SELECT source_keyattr, code, name, name_pr_fname, name_pr_mname, name_pr_lname, provider_type_code, lic_no, gender_code, address_code, address_golden_record, addressline1, addressline2, city, province, postalcode, `zone`, region, municipality, network, country, phonenumber, hdr_primary_key, mdm_recordsource, isdeleted FROM mzin.mzin_pr_provider version as of @version "

    schema_name = "mzin"
    table_name = "mzin_pr_provider"
    trnsfrmtn_script_path =  trnsfrmtn_script_base_path + 'mzin_pr_provider.txt'
    join_columns = "source_keyattr"

    result = get_scd_validation(check_type, schema_name, table_name, trnsfrmtn_script_path, tbl_script, input_datetime, join_columns, 1)

    return result

# COMMAND ----------

# DBTITLE 1,CZ address_stg
def validate_address_stg_scd(check_type, input_datetime):
    tbl_script = f"select * from ( SELECT  isdeleted, source_keyattr, golden_record_code, address_line1, " \
                 f"address_line2, address_line3, address_line4, postalcode, city, county, province, `zone`, " \
                 f"network, cluster, municipality, region, country, mdm_stdlatitude, mdm_stdlongitude, " \
                 f"mdm_verificationstatus, _is_active, " \
                 f"ROW_NUMBER() OVER(PARTITION BY golden_record_code ORDER BY `_modified_date` desc) AS rid " \
                 f"FROM czstg.cz_address_stg version as of @version )t  where t.rid = 1 " \
                 f"and _is_active = 'Y'"

    schema_name = "czstg"
    table_name = "cz_address_stg"
    trnsfrmtn_script_path =  trnsfrmtn_script_base_path + 'cz_address_stg.txt'
    join_columns = "source_keyattr"

    result = get_scd_validation(check_type, schema_name, table_name, trnsfrmtn_script_path, tbl_script, input_datetime, join_columns, 2)

    return result

# COMMAND ----------

# DBTITLE 1,CZ location_unverified
def validate_location_unverified_scd(check_type, input_datetime):
    tbl_script = f"SELECT isdeleted, location_id, source_keyattr, address_1, address_2, city, state, zip, county, " \
                 f"location_source_value, country_concept_id, country_source_value, lattitude, longitude " \
                 f"FROM cz.location version as of @version "

    schema_name = "cz"
    table_name = "location"
    trnsfrmtn_script_path =  trnsfrmtn_script_base_path + 'location_unverified_cz.txt'
    join_columns = "source_keyattr"

    result = get_scd_validation(check_type, schema_name, table_name, trnsfrmtn_script_path, tbl_script, input_datetime, join_columns, 1)

    return result

# COMMAND ----------

# DBTITLE 1,CZ location
def validate_location_scd(check_type, input_datetime):
    tbl_script =  f"SELECT isdeleted, location_id, source_keyattr, address_1, address_2, city, state, zip, county, " \
       f"location_source_value, country_concept_id, country_source_value, lattitude, longitude " \
       f"FROM cz.location version as of @version "

    schema_name = "cz"
    table_name = "location"
    trnsfrmtn_script_path =  trnsfrmtn_script_base_path + 'location.txt'
    join_columns = "location_source_value"

    result = get_scd_validation(check_type, schema_name, table_name, trnsfrmtn_script_path, tbl_script, input_datetime, join_columns, 1)

    return result

# COMMAND ----------

# DBTITLE 1,CZ person_stg
def validate_person_stg_scd(check_type, input_datetime):
    tbl_script = f"select * from ( SELECT isdeleted, source_keyattr, golden_record_code, health_card_number, " \
                 f"first_name, middle_name, last_name, name, gender, location_id, date_of_birth, death_date, " \
                 f"hcn_expiry_date, sex, sex_assigned_at_birth, income, ethnicity, education, marital_status, " \
                 f"health_plan_beneficiary_number, disability, primary_language, race, province_moved_from, " \
                 f"province_moved_to, arrival_date, departure_date, frailty_index, resource_intensity_weight, " \
                 f"alternate_identifier, _is_active, " \
                 f"ROW_NUMBER() OVER(PARTITION BY golden_record_code ORDER BY `_modified_date` desc) AS rid " \
                 f"FROM czstg.cz_person_stg version as of @version )t  where t.rid = 1 "

    schema_name = "czstg"
    table_name = "cz_person_stg"
    trnsfrmtn_script_path =  trnsfrmtn_script_base_path + 'cz_person_stg.txt'
    join_columns = ['source_keyattr']

    result = get_scd_validation(check_type, schema_name, table_name, trnsfrmtn_script_path, tbl_script, input_datetime, join_columns, 2)

    return result

# COMMAND ----------

# DBTITLE 1,CZ person_xwalk_ext
def validate_person_xwalk_ext_scd(check_type, input_datetime):
    tbl_script = f"SELECT isdeleted, source_keyattr, source_code, source_id, golden_record_code, health_card_number, " \
                 f"source_match_confidence, golden_record_match_confidence " \
                 f"FROM czstg.cz_person_xwalk_ext version as of @version "

    schema_name = "czstg"
    table_name = "cz_person_xwalk_ext"
    trnsfrmtn_script_path =  trnsfrmtn_script_base_path + 'cz_person_xwalk_ext.txt'
    join_columns = ['source_code', 'source_id']

    result = get_scd_validation(check_type, schema_name, table_name, trnsfrmtn_script_path, tbl_script, input_datetime, join_columns, 1)

    return result

# COMMAND ----------

# DBTITLE 1,CZ provider_stg
def validate_provider_stg_scd(check_type, input_datetime):
    tbl_script = f"select * from (SELECT isdeleted, source_keyattr, golden_record_code, first_name, " \
                 f"middle_name, last_name, provider_name, date_of_birth, gender, provider_type, primary_speciality, " \
                 f"license_number, effective_start_date, effective_end_date, location_id, phone_number, mobile_number, " \
                 f"fax_number, funding_structure, alternate_identifier, address_effective_date, _is_active, " \
                 f"ROW_NUMBER() OVER(PARTITION BY golden_record_code ORDER BY `_modified_date` desc) AS rid " \
                 f"FROM hive_metastore.czstg.cz_provider_stg version as of @version )t  where t.rid = 1 " \
                 f"and _is_active = 'Y'"

    schema_name = "czstg"
    table_name = "cz_provider_stg"
    trnsfrmtn_script_path =  trnsfrmtn_script_base_path + 'cz_provider_stg.txt'
    join_columns = "source_keyattr"

    result = get_scd_validation(check_type, schema_name, table_name, trnsfrmtn_script_path, tbl_script, input_datetime, join_columns, 2)

    return result

# COMMAND ----------

# DBTITLE 1,CZ provider_xwalk_ext
def validate_provider_xwalk_ext_scd(check_type, input_datetime):
    tbl_script = f"SELECT isdeleted, source_keyattr, source_code, source_id, golden_record_code, " \
                 f"source_match_confidence, golden_record_match_confidence " \
                 f"FROM czstg.cz_provider_xwalk_ext version as of @version "

    schema_name = "czstg"
    table_name = "cz_provider_xwalk_ext"
    trnsfrmtn_script_path =  trnsfrmtn_script_base_path + 'cz_provider_xwalk_ext.txt'
    join_columns = ['source_code', 'source_id']

    result = get_scd_validation(check_type, schema_name, table_name, trnsfrmtn_script_path, tbl_script, input_datetime, join_columns, 1)

    return result

# COMMAND ----------

# DBTITLE 1,CZ location_history
def validate_location_history_scd(check_type, input_datetime):
    tbl_script = f"select source_keyattr,  location_id,  relationship_type_concept_id, domain_id, entity_id, start_date, " \
       f"end_date, isdeleted from cz.location_history version as of @version "

    schema_name = "cz"
    table_name = "location_history"
    trnsfrmtn_script_path =  trnsfrmtn_script_base_path + 'location_history.txt'
    join_columns = "source_keyattr"

    result = get_scd_validation(check_type, schema_name, table_name, trnsfrmtn_script_path, tbl_script, input_datetime, join_columns, 1)

    return result

# COMMAND ----------

# DBTITLE 1,CZ death
def validate_death_scd(check_type, input_datetime):
    tbl_script = f"SELECT  isdeleted, person_id, death_date, death_datetime, death_type_concept_id, " \
                 f"cause_concept_id, cause_source_value, cause_source_concept_id " \
                 f"FROM cz.death version as of @version "

    schema_name = "cz"
    table_name = "death"
    trnsfrmtn_script_path =  trnsfrmtn_script_base_path + 'death.txt'
    join_columns = "person_id"

    result = get_scd_validation(check_type, schema_name, table_name, trnsfrmtn_script_path, tbl_script, input_datetime, join_columns, 1)

    return result

# COMMAND ----------

# DBTITLE 1,CZ person
def validate_person_scd(check_type, input_datetime):
    tbl_script = f"SELECT isdeleted, gender_concept_id, year_of_birth, month_of_birth, day_of_birth, birth_datetime, " \
                 f"race_concept_id, ethnicity_concept_id, location_id, provider_id, care_site_id, person_source_value, " \
                 f"gender_source_value, gender_source_concept_id, race_source_value, race_source_concept_id, " \
                 f"ethnicity_source_value, ethnicity_source_concept_id, person_id " \
                 f"FROM cz.person version as of @version "

    schema_name = "cz"
    table_name = "person"
    trnsfrmtn_script_path =  trnsfrmtn_script_base_path + 'person.txt'
    join_columns = "person_source_value"

    result = get_scd_validation(check_type, schema_name, table_name, trnsfrmtn_script_path, tbl_script, input_datetime, join_columns, 1)

    return result

# COMMAND ----------

# DBTITLE 1,CZ provider
def validate_provider_scd(check_type, input_datetime):
    tbl_script = f"SELECT isdeleted, provider_name, npi, dea, speciality_concept_id, care_site_id, year_of_birth, " \
       f"gender_concept_id, provider_source_value, speciality_source_value, speciality_source_concept_id, " \
       f"gender_source_value, gender_source_concept_id, provider_id FROM cz.provider version as of @version "

    schema_name = "cz"
    table_name = "provider"
    trnsfrmtn_script_path =  trnsfrmtn_script_base_path + 'provider.txt'
    join_columns = "provider_source_value"

    result = get_scd_validation(check_type, schema_name, table_name, trnsfrmtn_script_path, tbl_script, input_datetime, join_columns, 1)

    return result

# COMMAND ----------

# DBTITLE 1,CZ provider_license_ext
def validate_provider_license_ext_scd(check_type, input_datetime):
    tbl_script = f"select source_keyattr,  provider_id, licensenumber, providertype, effective_start_date, " \
       f"effective_end_date, is_primary, isdeleted from cz.provider_license_ext version as of @version "

    schema_name = "cz"
    table_name = "provider_license_ext"
    trnsfrmtn_script_path =  trnsfrmtn_script_base_path + 'provider_license_ext.txt'
    join_columns = "source_keyattr"

    result = get_scd_validation(check_type, schema_name, table_name, trnsfrmtn_script_path, tbl_script, input_datetime, join_columns, 1)

    return result

# COMMAND ----------

# DBTITLE 1,CZ provider_speciality_ext
def validate_provider_speciality_ext_scd(check_type, input_datetime):
    tbl_script = f"SELECT isdeleted, source_keyattr, provider_id, provider_type, speciality_code, effective_from_date, " \
       f"effective_to_date FROM cz.provider_speciality_ext version as of @version "

    schema_name = "cz"
    table_name = "provider_speciality_ext"
    trnsfrmtn_script_path =  trnsfrmtn_script_base_path + 'provider_speciality_ext.txt'
    join_columns = "source_keyattr"

    result = get_scd_validation(check_type, schema_name, table_name, trnsfrmtn_script_path, tbl_script, input_datetime, join_columns, 1)

    return result