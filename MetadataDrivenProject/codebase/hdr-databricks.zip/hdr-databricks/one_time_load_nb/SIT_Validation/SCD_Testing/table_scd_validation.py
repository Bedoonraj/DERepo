# Databricks notebook source
# DBTITLE 1,Install Libraries
pip install tabulate

# COMMAND ----------

# DBTITLE 1,Install Libraries
pip install numpy==1.23.1

# COMMAND ----------

# DBTITLE 1,Import Validation Notebook
# MAGIC %run /Repos/repo/hdr-databricks/one_time_load_nb/SIT_Validation/SCD_Testing/validate_scd

# COMMAND ----------

# DBTITLE 1,Import Configuration Notebook
# MAGIC %run /Repos/repo/hdr-databricks/one_time_load_nb/SIT_Validation/SCD_Testing/configuration

# COMMAND ----------

# DBTITLE 1,Import Libraries
import pandas as pd
from tabulate import tabulate

# COMMAND ----------

# DBTITLE 1,SZ - MZIN Address Before/After Insert SCD Validation
check_type = "After Insert"
df_result = pd.DataFrame()

df_cr_address = validate_cr_address_scd(check_type, ip_cr_address_ledt)
df_result = pd.concat([df_result, df_cr_address], ignore_index=True)

df_dss_address = validate_dss_address_scd(check_type, ip_dss_address_ledt)
df_result = pd.concat([df_result, df_dss_address], ignore_index=True)

df_nafp_address = validate_nafp_address_scd(check_type, ip_nafp_address_ledt)
df_result = pd.concat([df_result, df_nafp_address], ignore_index=True)

df_nscaf_address = validate_nscaf_address_scd(check_type, ip_nscaf_address_ledt)
df_result = pd.concat([df_result, df_nscaf_address], ignore_index=True)

df_pr_address = validate_pr_address_scd(check_type, ip_pr_address_ledt)
df_result = pd.concat([df_result, df_pr_address], ignore_index=True)

print(tabulate(df_result, headers='keys', tablefmt='github'))

# COMMAND ----------

# DBTITLE 1,SZ - MZIN Person Before/After Insert SCD Validation
check_type = "After Insert"
df_result = pd.DataFrame()

df_ed_person = validate_ed_person_scd(check_type, ip_ed_person_ledt)
df_result = pd.concat([df_result, df_ed_person], ignore_index=True)

df_cr_person = validate_cr_person_scd(check_type, ip_cr_person_ledt)
df_result = pd.concat([df_result, df_cr_person], ignore_index=True)

df_dad_person = validate_dad_person_scd(check_type, ip_dad_person_ledt)
df_result = pd.concat([df_result, df_dad_person], ignore_index=True)

df_dis_person = validate_dis_person_scd(check_type, ip_dis_person_ledt)
df_result = pd.concat([df_result, df_dis_person], ignore_index=True)

df_dss_person = validate_dss_person_scd(check_type, ip_dss_person_ledt)
df_result = pd.concat([df_result, df_dss_person], ignore_index=True)

df_nafp_person = validate_nafp_person_scd(check_type, ip_nafp_person_ledt)
df_result = pd.concat([df_result, df_nafp_person], ignore_index=True)

print(tabulate(df_result, headers='keys', tablefmt='github'))

# COMMAND ----------

# DBTITLE 1,SZ - MZIN Provider Before/After Insert SCD Validation
check_type = "Before Insert"
df_result = pd.DataFrame()

df_dad_provider = validate_dad_provider_scd(check_type, ip_dad_provider_ledt)
df_result = pd.concat([df_result, df_dad_provider], ignore_index=True)

df_dis_provider = validate_dis_provider_scd(check_type, ip_dis_provider_ledt)
df_result = pd.concat([df_result, df_dis_provider], ignore_index=True)

df_dss_provider = validate_dss_provider_scd(check_type, ip_dss_provider_ledt)
df_result = pd.concat([df_result, df_dss_provider], ignore_index=True)

df_ed_provider = validate_ed_provider_scd(check_type, ip_ed_provider_ledt)
df_result = pd.concat([df_result, df_ed_provider], ignore_index=True)

df_pr_provider = validate_pr_provider_scd(check_type, ip_pr_provider_ledt)
df_result = pd.concat([df_result, df_pr_provider], ignore_index=True)

print(tabulate(df_result, headers='keys', tablefmt='github'))

# COMMAND ----------

# DBTITLE 1,CZ Before Insert - stg_location SCD Validation
check_type = "Before Insert"
df_result = pd.DataFrame()

df_address_stg = validate_address_stg_scd(check_type, ip_address_stg_ledt)
df_result = pd.concat([df_result, df_address_stg], ignore_index=True)

print(tabulate(df_result, headers='keys', tablefmt='github'))

# COMMAND ----------

# DBTITLE 1,CZ Before Insert - cz_stage SCD Validation
check_type = "Before Insert"
df_result = pd.DataFrame()

df_location = validate_location_scd(check_type, ip_location_ledt)
df_result = pd.concat([df_result, df_location], ignore_index=True)

df_person_stg = validate_person_stg_scd(check_type, ip_person_stg_ledt)
df_result = pd.concat([df_result, df_person_stg], ignore_index=True)

df_person_xwalk_ext = validate_person_xwalk_ext_scd(check_type, ip_person_xwalk_ext_ledt)
df_result = pd.concat([df_result, df_person_xwalk_ext], ignore_index=True)

df_provider_stg = validate_provider_stg_scd(check_type, ip_provider_stg_ledt)
df_result = pd.concat([df_result, df_provider_stg], ignore_index=True)

df_provider_xwalk_ext = validate_provider_xwalk_ext_scd(check_type, ip_provider_xwalk_ext_ledt)
df_result = pd.concat([df_result, df_provider_xwalk_ext], ignore_index=True)

print(tabulate(df_result, headers='keys', tablefmt='github'))

# COMMAND ----------

# DBTITLE 1,CZ Before Insert - cz SCD Validation
check_type = "Before Insert"
df_result = pd.DataFrame()

df_location_history = validate_location_history_scd(check_type, ip_location_history_ledt)
df_result = pd.concat([df_result, df_location_history], ignore_index=True)

df_death = validate_death_scd(check_type, ip_death_ledt)
df_result = pd.concat([df_result, df_death], ignore_index=True)

df_person = validate_person_scd(check_type, ip_person_ledt)
df_result = pd.concat([df_result, df_person], ignore_index=True)

df_provider = validate_provider_scd(check_type, ip_provider_ledt)
df_result = pd.concat([df_result, df_provider], ignore_index=True)

df_provider_license_ext = validate_provider_license_ext_scd(check_type, ip_provider_license_ext_ledt)
df_result = pd.concat([df_result, df_provider_license_ext], ignore_index=True)

df_provider_speciality_ext = validate_provider_speciality_ext_scd(check_type, ip_provider_speciality_ext_ledt)
df_result = pd.concat([df_result, df_provider_speciality_ext], ignore_index=True)

print(tabulate(df_result, headers='keys', tablefmt='github'))


# COMMAND ----------

# DBTITLE 1,CZ After Insert SCD Validation
check_type = "After Insert"
df_result = pd.DataFrame()

df_address_stg = validate_address_stg_scd(check_type, ip_address_stg_ledt)
df_result = pd.concat([df_result, df_address_stg], ignore_index=True)

df_location = validate_location_scd(check_type, ip_location_ledt)
df_result = pd.concat([df_result, df_location], ignore_index=True)

#df_location_unverified = validate_location_unverified_scd(check_type, input_datetime)
#df_result = pd.concat([df_result, df_location_unverified], ignore_index=True)

df_person_stg = validate_person_stg_scd(check_type, ip_person_stg_ledt)
df_result = pd.concat([df_result, df_person_stg], ignore_index=True)

df_person_xwalk_ext = validate_person_xwalk_ext_scd(check_type, ip_person_xwalk_ext_ledt)
df_result = pd.concat([df_result, df_person_xwalk_ext], ignore_index=True)

df_provider_stg = validate_provider_stg_scd(check_type, ip_provider_stg_ledt)
df_result = pd.concat([df_result, df_provider_stg], ignore_index=True)

df_provider_xwalk_ext = validate_provider_xwalk_ext_scd(check_type, ip_provider_xwalk_ext_ledt)
df_result = pd.concat([df_result, df_provider_xwalk_ext], ignore_index=True)

df_location_history = validate_location_history_scd(check_type, ip_location_history_ledt)
df_result = pd.concat([df_result, df_location_history], ignore_index=True)

df_death = validate_death_scd(check_type, ip_death_ledt)
df_result = pd.concat([df_result, df_death], ignore_index=True)

df_person = validate_person_scd(check_type, ip_person_ledt)
df_result = pd.concat([df_result, df_person], ignore_index=True)

df_provider = validate_provider_scd(check_type, ip_provider_ledt)
df_result = pd.concat([df_result, df_provider], ignore_index=True)

df_provider_license_ext = validate_provider_license_ext_scd(check_type, ip_provider_license_ext_ledt)
df_result = pd.concat([df_result, df_provider_license_ext], ignore_index=True)

df_provider_speciality_ext = validate_provider_speciality_ext_scd(check_type, ip_provider_speciality_ext_ledt)
df_result = pd.concat([df_result, df_provider_speciality_ext], ignore_index=True)

print(tabulate(df_result, headers='keys', tablefmt='github'))