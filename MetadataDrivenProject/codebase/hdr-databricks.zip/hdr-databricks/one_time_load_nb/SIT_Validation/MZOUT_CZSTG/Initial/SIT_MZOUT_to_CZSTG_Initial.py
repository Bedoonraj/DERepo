# Databricks notebook source
import re
from pyspark.sql.types import BooleanType
from pyspark.sql.functions import col

# COMMAND ----------

dbutils.widgets.text('Environment','')
Environment=dbutils.widgets.get('Environment')

# COMMAND ----------

if Environment=='DEV':
    storage="sthdrcurzonedevtest"
else:
    storage="sthdrcurzoneprd"

# COMMAND ----------

# DBTITLE 1,Validation scripts for cz_address_stg
String2bReplaced=f"coalesce((select lastloaddatetime from adf_config.adf_datasetlog where upper(datasetname) = upper('cz_address_stg')), '1900-01-01')"
ReplacedString="'1900-01-01 00:00:00.000'"
with open(f"/dbfs/mnt/{storage}/trans_script/4_mzout_czstg/cz_address_stg.txt", "r") as trans_script:
        words = trans_script.read()
        words=words.replace(String2bReplaced, ReplacedString)
spark.sql(words).createOrReplaceTempView("InputDataTable")

# COMMAND ----------

##Count_Check
InputDataCount=spark.sql("select count(*) from InputDataTable ").collect()[0][0]
cz_address_stg_table=spark.sql("select count(*) from czstg.cz_address_stg").collect()[0][0]
print("Both the counts should match ",InputDataCount," ",cz_address_stg_table)

##Null check
NullCount=spark.sql("select count(*) from czstg.cz_address_stg where golden_record_code is null").collect()[0][0]
print("Null count is ",NullCount)

##Duplicate_Check
Duplicate_Check=spark.sql("select count(*) from czstg.cz_address_stg where _is_active='Y' group by golden_record_code having count(1)>1").count()
print("Duplicate is",Duplicate_Check)

# COMMAND ----------

# DBTITLE 1,Validation scripts for cz_person_stg
String2bReplaced=f"coalesce((select lastloaddatetime from adf_config.adf_datasetlog where upper(datasetname) = upper('cz_person_stg')), '1900-01-01')"
ReplacedString="'1900-01-01 00:00:00.000'"
with open(f"/dbfs/mnt/{storage}/trans_script/4_mzout_czstg/cz_person_stg_intial_load.txt", "r") as trans_script:
        words = trans_script.read()
        words=words.replace(String2bReplaced, ReplacedString)
spark.sql(words).createOrReplaceTempView("InputDataTable")

##Count_Check
InputDataCount=spark.sql("select count(*) from InputDataTable").collect()[0][0]
cz_person_stg=spark.sql("select count(*) from czstg.cz_person_stg").collect()[0][0]
print("Both the counts should match ",InputDataCount," ",cz_person_stg)

##Null check
NullCount=spark.sql("select count(*) from czstg.cz_person_stg where golden_record_code is null").collect()[0][0]
print("Null count is ",NullCount)

##Duplicate_Check
Duplicate_Check=spark.sql("select count(*) from czstg.cz_person_stg where _is_active='Y' group by golden_record_code having count(1)>1").count()
print("Duplicate is",Duplicate_Check)


# COMMAND ----------

# MAGIC %sql
# MAGIC select source_keyattr,count(*) from czstg.cz_person_stg where _is_active='Y' group by source_keyattr having count(1)>1

# COMMAND ----------

# DBTITLE 1,Validation scripts for cz_provider_stg
String2bReplaced=f"coalesce((select lastloaddatetime from adf_config.adf_datasetlog where upper(datasetname) = upper('cz_provider_stg')), '1900-01-01')"
ReplacedString="'1900-01-01 00:00:00.000'"
with open(f"/dbfs/mnt/{storage}/trans_script/4_mzout_czstg/cz_provider_stg_intial_load.txt", "r") as trans_script:
        words = trans_script.read()
        words=words.replace(String2bReplaced, ReplacedString)
spark.sql(words).createOrReplaceTempView("InputDataTable")

##Count_Check
InputDataCount=spark.sql("select count(*) from InputDataTable").collect()[0][0]
cz_provider_stg=spark.sql("select count(*) from czstg.cz_provider_stg").collect()[0][0]
print("Both the counts should match ",InputDataCount," ",cz_provider_stg)

##Null check
NullCount=spark.sql("select count(*) from czstg.cz_provider_stg where golden_record_code is null").collect()[0][0]
print("Null count is ",NullCount)

##Duplicate_Check
Duplicate_Check=spark.sql("select count(*) from czstg.cz_provider_stg where _is_active='Y' group by golden_record_code having count(1)>1").count()
print("Duplicate is",Duplicate_Check)


# COMMAND ----------

