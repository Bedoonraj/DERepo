# Databricks notebook source
# DBTITLE 1,Importing Libraries
import json
from pyspark.sql.functions import regexp_replace,monotonically_increasing_id,row_number,to_date,col
from pyspark.sql.window import Window
from pyspark.sql.types import DateType,IntegerType,TimestampType
import re
import datetime

# COMMAND ----------

# DBTITLE 1,Input Widgets are declared
dbutils.widgets.text('Environment','')
Environment=dbutils.widgets.get('Environment')

# COMMAND ----------

# DBTITLE 1,Environment and paths are defined
if Environment=='DEV':
    input_path="/mnt/sthdrstdzonedevtest/standardized/dhw/hap/"
    sz_tables_list_path="/dbfs/mnt/sthdrcurzonedevtest/ds_config/sz_tables.txt"
    input_dtlog_path='/mnt/sthdrcurzonedevtest/ds_config/adf_datasetlog_csv/'
    output_dtlog_path='/mnt/sthdrcurzonedevtest/ds_config/adf_datasetlog'
    location_one_time_script_path=f"/dbfs/mnt/sthdrcurzonedevtest/trans_script/6_czstg_cz/location_unverified_cz.txt"
    location_one_time_out_path=f"/mnt/sthdrcurzonedevtest/dhw/cz/location"
    location_his_unverfd_script_path=f"/dbfs/mnt/sthdrcurzonedevtest/trans_script/1_sz_mzin/mzin_location_history_unverified.txt"
    cr_location_his_unverfd_script_path=f"/dbfs/mnt/sthdrcurzonedevtest/trans_script/1_sz_mzin/mzin_cr_location_history_unverified.txt"
    location_his_unverfd_out_path=f"/mnt/sthdrcurzonedevtest/dhw/mzin/mzin_location_history_unverified"
    cr_location_his_unverfd_out_path=f"/mnt/sthdrcurzonedevtest/dhw/mzin/mzin_cr_location_history_unverified"
    nscaf_path='/mnt/sthdrstdzonedevtest/standardized/geo/nscaf/nscaf/NSCAF_MASTER.delta/'

else:
    input_path="/mnt/sthdrstdzoneprd/standardized/dhw/hap/"
    sz_tables_list_path="/dbfs/mnt/sthdrcurzoneprd/ds_config/sz_tables.txt"
    input_dtlog_path='/mnt/sthdrcurzoneprd/ds_config/adf_datasetlog_csv/'
    output_dtlog_path='/mnt/sthdrcurzoneprd/ds_config/adf_datasetlog'
    location_one_time_script_path=f"/dbfs/mnt/sthdrcurzoneprd/trans_script/6_czstg_cz/location_unverified_cz.txt"
    location_one_time_out_path=f"/mnt/sthdrcurzoneprd/dhw/cz/location"
    location_his_unverfd_script_path=f"/dbfs/mnt/sthdrcurzoneprd/trans_script/1_sz_mzin/mzin_location_history_unverified.txt"
    cr_location_his_unverfd_script_path=f"/dbfs/mnt/sthdrcurzoneprd/trans_script/1_sz_mzin/mzin_cr_location_history_unverified.txt"
    location_his_unverfd_out_path=f"/mnt/sthdrcurzoneprd/dhw/mzin/mzin_location_history_unverified"
    cr_location_his_unverfd_out_path=f"/mnt/sthdrcurzoneprd/dhw/mzin/mzin_cr_location_history_unverified"
    nscaf_path='/mnt/sthdrstdzoneprd/standardized/geo/nscaf/nscaf/NSCAF_MASTER.delta/'

# COMMAND ----------

# DBTITLE 1,Utility functions are called
# MAGIC %run ../common_functions/UtilityFunctions

# COMMAND ----------

# DBTITLE 1,Importing list of tables from json
try:
    result = read_config(sz_tables_list_path)
    env_config_data = json.loads(result)
    sz_list=env_config_data["SZ"]
    ref_list=env_config_data["ref"]["mzin_ref"]
    #print(ref_list)
except Exception as e:
    error_handling("unable to get the inputs",str(e))

# COMMAND ----------

# DBTITLE 1,Below code is to create SZ hive tables
try:
    for databasename,tables in sz_list.items():
        if databasename not in ['nscaf']:
            for tablename in tables:
                #spark.sql(f"alter table {databasename}.{tablename} SET TBLPROPERTIES (delta.enableChangeDataFeed=true)")
                spark.sql(f"create database if not exists {databasename}")
                spark.sql(f"create table if not exists {databasename}.{tablename} using delta location '{input_path}{databasename}/{tablename}.delta'")
                #spark.sql(f"alter table {databasename}.{tablename} SET TBLPROPERTIES (delta.enableChangeDataFeed=true)")
        else:
            for tablename in tables:
                spark.sql(f"create database if not exists {databasename}")
                spark.sql(f"create table if not exists {databasename}.{tablename} using delta location '{nscaf_path}'")
                #spark.sql(f"alter table {databasename}.{tablename} SET TBLPROPERTIES (delta.enableChangeDataFeed=true)")
except Exception as e:
    error_handling("Unable to load ", str(e))

# COMMAND ----------

# DBTITLE 1,Adhoc Tables
if Environment=='DEV':
    dis_prescription='/mnt/sthdrstdzonedevtest/standardized/dhw/hap/dis/DIS_PRESCRIPTION.delta'
else:
    dis_prescription='/mnt/sthdrstdzoneprd/standardized/dhw/hap/dis/DIS_PRESCRIPTION.delta'
spark.sql(f"create table if not exists dis.dis_prescription using delta location '{dis_prescription}'")

# COMMAND ----------

# DBTITLE 1,ADF DatasetLog creation
df_dtlog=spark.read.format('csv').option('header',True).load(input_dtlog_path)
df_dtlog=df_dtlog.withColumn('datasetId',col('datasetId').cast(IntegerType()))\
                .withColumn('LastLoadDateTime',col('LastLoadDateTime').cast(TimestampType()))\
                .withColumn('HDRLastLoadDateTime',col('HDRLastLoadDateTime').cast(TimestampType()))
df_dtlog.write.format('delta').save(output_dtlog_path)
spark.sql("create database if not exists adf_config")
spark.sql(f"create table if not exists adf_config.adf_datasetlog using delta location '{output_dtlog_path}'")
spark.sql(f"alter table adf_config.adf_datasetlog SET TBLPROPERTIES (delta.enableChangeDataFeed=true)")
spark.sql(f"ALTER TABLE delta.`{output_dtlog_path}` SET TBLPROPERTIES(delta.logRetentionDuration = 'interval 730 days')")

# COMMAND ----------

# DBTITLE 1,Execute mzin location history unverified
ct = datetime.datetime.now()
primary_key='source_keyattr'
pipelineid=''
TransformationType='SCD1'
fullloadind='False'
databasename='mzin'
tablename='mzin_location_history_unverified'
try:
    with open(location_his_unverfd_script_path, "r") as trans_script:
        words = trans_script.read()
    df=spark.sql(words)
except Exception as e:
    error_handling("Unable to process script file", str(e))
Write_SCD_Delta(df,location_his_unverfd_out_path,primary_key.split(','),pipelineid,ct,TransformationType,fullloadind)
spark.sql(f"create database if not exists {databasename}")
spark.sql(f"create table if not exists {databasename}.{tablename} using delta location '{location_his_unverfd_out_path}'")
spark.sql(f"alter table {databasename}.{tablename} SET TBLPROPERTIES (delta.enableChangeDataFeed=true)")
spark.sql(f"ALTER TABLE delta.`{location_his_unverfd_out_path}` SET TBLPROPERTIES(delta.logRetentionDuration = 'interval 730 days')")
spark.sql(f"ALTER TABLE {databasename}.{tablename} ALTER COLUMN {primary_key} SET NOT NULL")

# COMMAND ----------

# DBTITLE 1,Execute location onetime
ct = datetime.datetime.now()
primary_key='source_keyattr'
pipelineid=''
TransformationType='SCD1'
fullloadind='False'
databasename='cz'
tablename='location'
try:
    with open(location_one_time_script_path, "r") as trans_script:
        words = trans_script.read()
    df=spark.sql(words)
except Exception as e:
    error_handling("Unable to process script file", str(e))
df=df.withColumn("location_id", row_number().over(Window.orderBy('source_keyattr')))  
colname=df.columns
colname.remove('location_id')
colname.insert(0,'location_id')
df=df.select(*colname)
Write_SCD_Delta(df,location_one_time_out_path,primary_key.split(','),pipelineid,ct,TransformationType,fullloadind)
spark.sql(f"create database if not exists {databasename}")
spark.sql(f"create table if not exists {databasename}.{tablename} using delta location '{location_one_time_out_path}'")
spark.sql(f"alter table {databasename}.{tablename} SET TBLPROPERTIES (delta.enableChangeDataFeed=true)")
spark.sql(f"ALTER TABLE delta.`{location_one_time_out_path}` SET TBLPROPERTIES(delta.logRetentionDuration = 'interval 730 days')")
spark.sql(f"ALTER TABLE {databasename}.{tablename} ALTER COLUMN {primary_key} SET NOT NULL")

# COMMAND ----------

# DBTITLE 1,Execute mzin_cr_location_history_unverified
ct = datetime.datetime.now()
primary_key='source_keyattr'
pipelineid=''
TransformationType='SCD1'
fullloadind='False'
databasename='mzin'
tablename='mzin_cr_location_history_unverified'
try:
    with open(cr_location_his_unverfd_script_path, "r") as trans_script:
        words = trans_script.read()
    df=spark.sql(words)
except Exception as e:
    error_handling("Unable to process script file", str(e))
Write_SCD_Delta(df,cr_location_his_unverfd_out_path,primary_key.split(','),pipelineid,ct,TransformationType,fullloadind)
spark.sql(f"create database if not exists {databasename}")
spark.sql(f"create table if not exists {databasename}.{tablename} using delta location '{cr_location_his_unverfd_out_path}'")
spark.sql(f"alter table {databasename}.{tablename} SET TBLPROPERTIES (delta.enableChangeDataFeed=true)")
spark.sql(f"ALTER TABLE delta.`{cr_location_his_unverfd_out_path}` SET TBLPROPERTIES(delta.logRetentionDuration = 'interval 730 days')")
spark.sql(f"ALTER TABLE {databasename}.{tablename} ALTER COLUMN {primary_key} SET NOT NULL")

# COMMAND ----------

# DBTITLE 1,Execute location onetime new
ct = datetime.datetime.now()
primary_key='source_keyattr'
pipelineid=''
TransformationType='SCD1'
fullloadind='False'
databasename='cz'
tablename='location'
generate_id_ind='True'
generate_id_col='location_id'
try:
    with open(location_one_time_script_path, "r") as trans_script:
        words = trans_script.read()
    df=spark.sql(words)
except Exception as e:
    error_handling("Unable to process script file", str(e))
if generate_id_ind=='True':
    df=Generate_IDColumn(df,location_one_time_out_path,primary_key,generate_id_col)
Write_SCD_Delta(df,location_one_time_out_path,primary_key.split(','),pipelineid,ct,TransformationType,fullloadind)
try:
    table_existance=spark.sql(f"show tables in {databasename} like '{tablename}'").count()
except:
    table_existance=0
if table_existance==0:
    spark.sql(f"create database if not exists {databasename}")
    spark.sql(f"create table if not exists {databasename}.{tablename} using delta location '{location_one_time_out_path}'")
    spark.sql(f"alter table {databasename}.{tablename} SET TBLPROPERTIES (delta.enableChangeDataFeed=true)")
    spark.sql(f"ALTER TABLE delta.`{location_one_time_out_path}` SET TBLPROPERTIES(delta.logRetentionDuration = 'interval 730 days')")
    spark.sql(f"ALTER TABLE {databasename}.{tablename} ALTER COLUMN {primary_key} SET NOT NULL")

# COMMAND ----------

